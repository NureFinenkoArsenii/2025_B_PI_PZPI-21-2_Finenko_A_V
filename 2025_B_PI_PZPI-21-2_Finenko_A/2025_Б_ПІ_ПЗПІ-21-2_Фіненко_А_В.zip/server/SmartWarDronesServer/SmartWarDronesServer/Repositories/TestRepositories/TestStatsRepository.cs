﻿using MongoDB.Driver;
using SmartWarDronesServer.Models.MapModels.TestMapModels;
using MongoDB.Bson;

namespace SmartWarDronesServer.Repositories.TestRepositories
{
    public class TestStatsRepository
    {
        private readonly IMongoCollection<TestStats> _collection;

        public TestStatsRepository(IMongoClient client)
        {
            var db = client.GetDatabase("SmartWarDrones");
            _collection = db.GetCollection<TestStats>("test-stats");
        }

        public async Task<TestStats> InsertAsync(TestStats state)
        {
            await _collection.InsertOneAsync(state);
            return state;
        }

        public async Task<TestStats?> GetByIdAsync(string id)
        {
            return await _collection.Find(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<TestStats>> GetByDroneIdAsync(string droneId)
        {
            return await _collection.Find(x => x.DroneId == droneId).ToListAsync();
        }

        public async Task<TestStats?> GetByDroneIdAndStatsTypeAsync(string droneId, string statsType)
        {
            return await _collection.Find(x => x.DroneId == droneId && x.StatsType == statsType).FirstOrDefaultAsync();
        }

        public async Task DeleteAsync(string id)
        {
            await _collection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task UpdateAsync(TestStats state)
        {
            await _collection.ReplaceOneAsync(x => x.Id == state.Id, state);
        }

        public async Task CreateIndexesAsync()
        {
            var indexKeys = Builders<TestStats>.IndexKeys;
            var models = new List<CreateIndexModel<TestStats>>
            {
                new CreateIndexModel<TestStats>(indexKeys.Ascending(x => x.Id)),
                new CreateIndexModel<TestStats>(indexKeys.Ascending(x => x.DroneId))
            };
            await _collection.Indexes.CreateManyAsync(models);
        }
    }
}
