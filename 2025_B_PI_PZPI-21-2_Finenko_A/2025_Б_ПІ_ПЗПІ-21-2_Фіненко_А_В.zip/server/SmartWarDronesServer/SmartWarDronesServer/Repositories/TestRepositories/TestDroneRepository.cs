﻿using MongoDB.Driver;
using SmartWarDronesServer.Models.MapModels.TestMapModels;
using MongoDB.Bson;

namespace SmartWarDronesServer.Repositories.TestRepositories
{
    public class TestDroneRepository
    {
        private readonly IMongoCollection<TestDrone> _collection;

        public TestDroneRepository(IMongoClient client)
        {
            var db = client.GetDatabase("SmartWarDrones");
            _collection = db.GetCollection<TestDrone>("test-drones");
        }

        public async Task<TestDrone> InsertAsync(TestDrone drone)
        {
            await _collection.InsertOneAsync(drone);
            return drone;
        }

        public async Task<List<TestDrone>> GetByPersonIdAsync(string personId)
        {
            var filter = Builders<TestDrone>.Filter.Eq(d => d.PersonId, personId);
            return await _collection.Find(filter).ToListAsync();
        }

        public async Task<List<TestDrone>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<List<TestDrone>> GetAllByDroneTypeAsync(string droneType)
        {
            return await _collection.Find(x => x.DroneType == droneType).ToListAsync();
        }

        public async Task<TestDrone?> GetByIdAsync(string id)
        {
            return await _collection.Find(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<TestDrone?> GetByDroneNameAsync(string droneName)
        {
            return await _collection.Find(x => x.DroneName == droneName).FirstOrDefaultAsync();
        }

        public async Task<TestDrone?> GetByDroneNameAndSafetyCodeAsync(string droneName, string safetyCode)
        {
            return await _collection.Find(x => x.DroneName == droneName && x.SafetyCode == safetyCode).FirstOrDefaultAsync();
        }

        public async Task<TestDrone?> GetByDroneNameAndDroneTypeAsync(string droneName, string droneType)
        {
            return await _collection.Find(x => x.DroneName == droneName && x.DroneType == droneType).FirstOrDefaultAsync();
        }

        public async Task UpdateAsync(TestDrone drone)
        {
            await _collection.ReplaceOneAsync(x => x.Id == drone.Id, drone);
        }

        public async Task DeleteByNameAsync(string droneName)
        {
            await _collection.DeleteOneAsync(x => x.DroneName == droneName);
        }

        public async Task CreateIndexesAsync()
        {
            var indexKeys = Builders<TestDrone>.IndexKeys;
            var models = new List<CreateIndexModel<TestDrone>>
            {
                new CreateIndexModel<TestDrone>(indexKeys.Ascending(x => x.Id)),
                new CreateIndexModel<TestDrone>(indexKeys.Ascending(x => x.DroneName))
            };
            await _collection.Indexes.CreateManyAsync(models);
        }
    }
}
