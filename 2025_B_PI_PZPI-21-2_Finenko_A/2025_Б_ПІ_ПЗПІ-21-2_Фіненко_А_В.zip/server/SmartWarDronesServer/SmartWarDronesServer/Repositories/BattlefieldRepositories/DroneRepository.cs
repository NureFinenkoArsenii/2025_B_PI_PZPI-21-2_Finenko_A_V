﻿using MongoDB.Driver;
using SmartWarDronesServer.Models.MapModels.BattlefieldModels;
using MongoDB.Bson;

namespace SmartWarDronesServer.Repositories.BattlefieldRepositories
{
    public class DroneRepository
    {
        private readonly IMongoCollection<Drone> _collection;

        public DroneRepository(IMongoClient client)
        {
            var db = client.GetDatabase("SmartWarDrones");
            _collection = db.GetCollection<Drone>("drones");
        }

        public async Task<Drone> InsertAsync(Drone drone)
        {
            await _collection.InsertOneAsync(drone);
            return drone;
        }

        public async Task<List<Drone>> GetByPersonIdAsync(string operatorId)
        {
            var filter = Builders<Drone>.Filter.Eq(d => d.OperatorId, operatorId);
            return await _collection.Find(filter).ToListAsync();
        }

        public async Task<List<Drone>> GetAllAsync()
        {
            return await _collection.Find(_ => true).ToListAsync();
        }

        public async Task<List<Drone>> GetAllByDroneTypeAsync(string droneType)
        {
            return await _collection.Find(x => x.DroneType == droneType).ToListAsync();
        }

        public async Task<Drone?> GetBySafetyCodeAsync(string safetyCode)
        {
            return await _collection.Find(x => x.SafetyCode == safetyCode).FirstOrDefaultAsync();
        }

        public async Task<Drone?> GetByIdAsync(string id)
        {
            return await _collection.Find(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<Drone?> GetByDroneNameAsync(string encryptedDroneName)
        {
            return await _collection.Find(x => x.DroneName == encryptedDroneName).FirstOrDefaultAsync();
        }


        public async Task<Drone?> GetByDroneNameAndSafetyCodeAsync(string droneName, string safetyCode)
        {
            return await _collection.Find(x => x.DroneName == droneName && x.SafetyCode == safetyCode).FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateDroneInfoAsync(string id, string encryptedName, string encryptedType, string encryptedBand)
        {
            var update = Builders<Drone>.Update
                .Set(d => d.DroneName, encryptedName)
                .Set(d => d.DroneType, encryptedType)
                .Set(d => d.FrequencyBand, encryptedBand);

            var result = await _collection.UpdateOneAsync(
                d => d.Id == id,
                update
            );

            return result.ModifiedCount > 0;
        }

        public async Task<bool> DeleteByIdAsync(string id)
        {
            var result = await _collection.DeleteOneAsync(x => x.Id == id);
            return result.DeletedCount > 0;
        }

        public async Task<Drone?> GetByDroneNameAndDroneTypeAsync(string droneName, string droneType)
        {
            return await _collection.Find(x => x.DroneName == droneName && x.DroneType == droneType).FirstOrDefaultAsync();
        }

        public async Task UpdateAsync(Drone drone)
        {
            await _collection.ReplaceOneAsync(x => x.Id == drone.Id, drone);
        }

        public async Task DeleteByNameAsync(string droneName)
        {
            await _collection.DeleteOneAsync(x => x.DroneName == droneName);
        }

        public async Task CreateIndexesAsync()
        {
            var indexKeys = Builders<Drone>.IndexKeys;
            var models = new List<CreateIndexModel<Drone>>
            {
                new CreateIndexModel<Drone>(indexKeys.Ascending(x => x.Id)),
                new CreateIndexModel<Drone>(indexKeys.Ascending(x => x.DroneName))
            };
            await _collection.Indexes.CreateManyAsync(models);
        }
    }
}
