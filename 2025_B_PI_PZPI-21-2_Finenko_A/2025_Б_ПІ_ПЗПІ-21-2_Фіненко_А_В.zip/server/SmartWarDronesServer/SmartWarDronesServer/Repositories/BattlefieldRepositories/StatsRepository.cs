﻿using MongoDB.Driver;
using SmartWarDronesServer.Models.MapModels.BattlefieldModels;
using MongoDB.Bson;

namespace SmartWarDronesServer.Repositories.BattlefieldRepositories
{
    public class StatsRepository
    {
        private readonly IMongoCollection<Stats> _collection;

        public StatsRepository(IMongoClient client)
        {
            var db = client.GetDatabase("SmartWarDrones");
            _collection = db.GetCollection<Stats>("stats");
        }

        public async Task<Stats> InsertAsync(Stats state)
        {
            await _collection.InsertOneAsync(state);
            return state;
        }

        public async Task<Stats?> GetByIdAsync(string id)
        {
            return await _collection.Find(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<List<Stats>> GetByDroneIdAsync(string droneId)
        {
            return await _collection.Find(x => x.DroneId == droneId).ToListAsync();
        }

        public async Task<Stats?> GetByDroneIdAndStatsTypeAsync(string droneId, string statsType)
        {
            return await _collection.Find(x => x.DroneId == droneId && x.StatsType == statsType).FirstOrDefaultAsync();
        }

        public async Task<long> DeleteByDroneIdAsync(string encryptedDroneId)
        {
            var result = await _collection.DeleteManyAsync(x => x.DroneId == encryptedDroneId);
            return result.DeletedCount;
        }

        public async Task DeleteAsync(string id)
        {
            await _collection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task UpdateAsync(Stats state)
        {
            await _collection.ReplaceOneAsync(x => x.Id == state.Id, state);
        }

        public async Task CreateIndexesAsync()
        {
            var indexKeys = Builders<Stats>.IndexKeys;
            var models = new List<CreateIndexModel<Stats>>
            {
                new CreateIndexModel<Stats>(indexKeys.Ascending(x => x.Id)),
                new CreateIndexModel<Stats>(indexKeys.Ascending(x => x.DroneId))
            };
            await _collection.Indexes.CreateManyAsync(models);
        }
    }
}
