﻿using System.Security.Cryptography;

namespace SmartWarDrones.Server.Services
{
    public class GlobalChatDhKeyService
    {
        private readonly string _dhAesKey;

        public GlobalChatDhKeyService(IConfiguration config)
        {
            _dhAesKey = config["DhEncryption:Key"]!;
        }

        // 1. Формуємо shared secret для клієнта (private user + public chat)
        public byte[] GetSharedSecretForClient(string privateUserDhEncrypted, string chatPublicDhBase64)
        {
            // Дешифруємо приватний ключ користувача
            var privParts = privateUserDhEncrypted.Split(':');
            if (privParts.Length != 2)
                throw new Exception("Corrupted private DH key (user).");

            var ivUserDh = Convert.FromBase64String(privParts[0]);
            var cipherUserDh = Convert.FromBase64String(privParts[1]);

            byte[] privateUserDhBytes;
            using (var aes = Aes.Create())
            {
                aes.Key = Convert.FromBase64String(_dhAesKey);
                aes.IV = ivUserDh;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                privateUserDhBytes = decryptor.TransformFinalBlock(cipherUserDh, 0, cipherUserDh.Length);
            }

            using var userDh = ECDiffieHellman.Create();
            userDh.ImportECPrivateKey(privateUserDhBytes, out _);

            var chatPubDhBytes = Convert.FromBase64String(chatPublicDhBase64);
            using var chatPubDh = ECDiffieHellman.Create();
            chatPubDh.ImportSubjectPublicKeyInfo(chatPubDhBytes, out _);

            var sharedSecret = userDh.DeriveKeyMaterial(chatPubDh.PublicKey);
            return sharedSecret;
        }

        // 2. Формуємо shared secret для сервера (private chat + public user)
        public byte[] GetSharedSecretForServer(string privateChatDhEncrypted, string userPublicDhBase64)
        {
            var privParts = privateChatDhEncrypted.Split(':');
            if (privParts.Length != 2)
                throw new Exception("Corrupted private DH key (chat).");

            var ivChatDh = Convert.FromBase64String(privParts[0]);
            var cipherChatDh = Convert.FromBase64String(privParts[1]);

            byte[] privateChatDhBytes;
            using (var aes = Aes.Create())
            {
                aes.Key = Convert.FromBase64String(_dhAesKey);
                aes.IV = ivChatDh;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                privateChatDhBytes = decryptor.TransformFinalBlock(cipherChatDh, 0, cipherChatDh.Length);
            }

            using var chatDh = ECDiffieHellman.Create();
            chatDh.ImportECPrivateKey(privateChatDhBytes, out _);

            var userPubDhBytes = Convert.FromBase64String(userPublicDhBase64);
            using var userPubDh = ECDiffieHellman.Create();
            userPubDh.ImportSubjectPublicKeyInfo(userPubDhBytes, out _);

            var sharedSecret = chatDh.DeriveKeyMaterial(userPubDh.PublicKey);
            return sharedSecret;
        }
    }
}
