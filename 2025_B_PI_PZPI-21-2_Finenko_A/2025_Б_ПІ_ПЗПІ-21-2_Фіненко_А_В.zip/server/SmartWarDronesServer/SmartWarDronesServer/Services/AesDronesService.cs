﻿using System.Text;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;

namespace SmartWarDronesServer.Services
{
    public class AesDronesService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesDronesService(IConfiguration config)
        {
            var keyStr = config["AesDrones:Key"];
            var ivStr = config["AesDrones:IV"];

            if (string.IsNullOrWhiteSpace(keyStr))
                throw new ArgumentException("AesDrones:Key is missing or empty in configuration.");

            if (string.IsNullOrWhiteSpace(ivStr))
                throw new ArgumentException("AesDrones:IV is missing or empty in configuration.");

            _key = Encoding.UTF8.GetBytes(keyStr);
            _iv = Convert.FromBase64String(ivStr);
        }

        public string Encrypt(string plainText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var plainBytes = Encoding.UTF8.GetBytes(plainText);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            return Convert.ToBase64String(cipherBytes);
        }

        public string Decrypt(string base64Cipher)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var cipherBytes = Convert.FromBase64String(base64Cipher);
            using var decryptor = aes.CreateDecryptor();
            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);

            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
