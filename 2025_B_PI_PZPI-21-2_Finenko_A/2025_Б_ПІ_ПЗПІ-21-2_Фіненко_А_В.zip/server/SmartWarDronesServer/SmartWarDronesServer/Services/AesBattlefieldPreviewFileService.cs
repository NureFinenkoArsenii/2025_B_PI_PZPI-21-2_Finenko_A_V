﻿using System.Security.Cryptography;
using System.Text;

namespace SmartWarDronesServer.Services
{
    public class AesBattlefieldPreviewFileService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesBattlefieldPreviewFileService(IConfiguration config)
        {
            var key = config["AesBattlefieldPreviewFile:Key"];
            var iv = config["AesBattlefieldPreviewFile:IV"];
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("AesBattlefieldPreviewFile:Key is missing or empty in configuration.");
            if (string.IsNullOrWhiteSpace(iv))
                throw new ArgumentException("AesBattlefieldPreviewFile:IV is missing or empty in configuration.");

            _key = Encoding.UTF8.GetBytes(key);
            _iv = Encoding.UTF8.GetBytes(iv);
        }

        public byte[] Encrypt(byte[] plain)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using var encryptor = aes.CreateEncryptor();
            return encryptor.TransformFinalBlock(plain, 0, plain.Length);
        }

        public byte[] Decrypt(byte[] cipher)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using var decryptor = aes.CreateDecryptor();
            return decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
        }
    }
}
