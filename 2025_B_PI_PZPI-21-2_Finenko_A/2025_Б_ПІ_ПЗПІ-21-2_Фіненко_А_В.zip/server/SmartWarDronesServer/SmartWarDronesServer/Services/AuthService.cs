﻿using SmartWarDrones.Server.Models;
using Konscious.Security.Cryptography;
using MongoDB.Driver;
using System.Text;
using System.Security.Cryptography;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Services;

namespace SmartWarDrones.Server.Services
{
    public class AuthService
    {
        private readonly IMongoCollection<Person> _people;
        private readonly IConfiguration _config;
        private readonly IdentifierCryptoService _crypto;

        public AuthService(IConfiguration config, IMongoClient mongoClient, IdentifierCryptoService crypto)
        {
            _config = config;
            _crypto = crypto;
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _people = db.GetCollection<Person>("persons");
        }

        public async Task<(bool Success, string Message)> RegisterAsync(RegisterData request)
        {
            var existing = await _people.Find(p => p.Name == request.Login).FirstOrDefaultAsync();
            if (existing != null)
                return (false, "User already exists");

            var salt = RandomNumberGenerator.GetBytes(16);
            var passwordHash = HashPassword(request.Password, salt);

            var aesKey = _config["DhEncryption:Key"]!;
            var dh1 = DiffieHellmanKeyPair.Generate(aesKey);
            var dh2 = DiffieHellmanKeyPair.Generate(aesKey);

            var random = new Random();
            var avatarNumber = random.Next(1, 11);
            var avatarPath = $"/avatars/avatar{avatarNumber}.png";
            var encryptedAvatarPath = new AvatarUrlCryptoService(_config).Encrypt(avatarPath);

            // ⬇ Генеруємо і шифруємо ідентифікатор
            var plainIdentifier = IdentifierService.GenerateIdentifier();
            var encryptedIdentifier = _crypto.Encrypt(plainIdentifier);

            var newUser = new Person
            {
                Name = request.Login,
                PasswordHash = Convert.ToBase64String(passwordHash),
                Role = request.Role,
                Identifier = encryptedIdentifier,
                PreviousIdentifier = "",
                AvatarUrl = encryptedAvatarPath,
                PublicDhPrivate = dh1.PublicKey,
                PrivateDhPrivateEncrypted = dh1.EncryptedPrivateKey,
                PublicDhGroup = dh2.PublicKey,
                PrivateDhGroupEncrypted = dh2.EncryptedPrivateKey,
            };

            await _people.InsertOneAsync(newUser);
            return (true, "Registered successfully");
        }

        public async Task<(bool Success, string RefreshToken, string AccessToken)> LoginAsync(string login, string password, JwtService jwt)
        {
            var user = await _people.Find(p => p.Name == login).FirstOrDefaultAsync();
            if (user == null) return (false, "", "");

            var hashWithSalt = Convert.FromBase64String(user.PasswordHash);
            var salt = hashWithSalt[..16];
            var storedHash = hashWithSalt[16..];

            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = salt,
                DegreeOfParallelism = 8,
                Iterations = 4,
                MemorySize = 65536
            };

            var computedHash = argon2.GetBytes(32);
            if (!computedHash.SequenceEqual(storedHash))
                return (false, "", "");

            var refreshToken = GenerateSecureToken(64);
            var refreshTokenHash = HashToken(refreshToken);

            var update = Builders<Person>.Update.Set(p => p.RefreshTokenHash, refreshTokenHash);
            await _people.UpdateOneAsync(p => p.Id == user.Id, update);

            var accessToken = jwt.GenerateToken(user.Id, user.Role);
            return (true, refreshToken, accessToken);
        }

        public async Task<(bool Success, string AccessToken)> RefreshAccessTokenAsync(string refreshToken, JwtService jwt)
        {
            var allUsers = await _people.Find(_ => true).ToListAsync();

            foreach (var user in allUsers)
            {
                if (VerifyTokenHash(refreshToken, user.RefreshTokenHash))
                {
                    var newAccessToken = jwt.GenerateToken(user.Id, user.Role);
                    return (true, newAccessToken);
                }
            }

            return (false, "");
        }

        public async Task<bool> RevokeRefreshTokenAsync(string refreshToken)
        {
            var allUsers = await _people.Find(_ => true).ToListAsync();

            foreach (var user in allUsers)
            {
                if (VerifyTokenHash(refreshToken, user.RefreshTokenHash))
                {
                    var update = Builders<Person>.Update.Set(p => p.RefreshTokenHash, "");
                    await _people.UpdateOneAsync(p => p.Id == user.Id, update);
                    return true;
                }
            }

            return false;
        }

        private static byte[] HashPassword(string password, byte[] salt)
        {
            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = salt,
                DegreeOfParallelism = 8,
                Iterations = 4,
                MemorySize = 65536
            };

            var hash = argon2.GetBytes(32);
            var combined = new byte[salt.Length + hash.Length];
            Buffer.BlockCopy(salt, 0, combined, 0, salt.Length);
            Buffer.BlockCopy(hash, 0, combined, salt.Length, hash.Length);
            return combined;
        }

        private static string GenerateSecureToken(int length)
        {
            var bytes = RandomNumberGenerator.GetBytes(length);
            return Convert.ToBase64String(bytes);
        }

        private static string HashToken(string token)
        {
            var salt = RandomNumberGenerator.GetBytes(16);
            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(token))
            {
                Salt = salt,
                DegreeOfParallelism = 4,
                Iterations = 3,
                MemorySize = 32768
            };
            var hash = argon2.GetBytes(32);
            return $"{Convert.ToBase64String(salt)}:{Convert.ToBase64String(hash)}";
        }

        private static bool VerifyTokenHash(string token, string stored)
        {
            var parts = stored.Split(':');
            if (parts.Length != 2) return false;

            var salt = Convert.FromBase64String(parts[0]);
            var expectedHash = Convert.FromBase64String(parts[1]);

            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(token))
            {
                Salt = salt,
                DegreeOfParallelism = 4,
                Iterations = 3,
                MemorySize = 32768
            };

            var computedHash = argon2.GetBytes(32);
            return computedHash.SequenceEqual(expectedHash);
        }
    }

    public class DiffieHellmanKeyPair
    {
        public string PublicKey { get; set; } = "";
        public string EncryptedPrivateKey { get; set; } = "";

        public static DiffieHellmanKeyPair Generate(string aesBase64Key)
        {
            using var dh = ECDiffieHellman.Create(ECCurve.NamedCurves.nistP256);

            var publicKey = Convert.ToBase64String(dh.PublicKey.ExportSubjectPublicKeyInfo());
            var privateKey = dh.ExportECPrivateKey();

            var aesKey = Convert.FromBase64String(aesBase64Key);
            var iv = RandomNumberGenerator.GetBytes(16);

            using var aes = Aes.Create();
            aes.Key = aesKey;
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var encryptor = aes.CreateEncryptor();
            using var ms = new MemoryStream();
            using var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
            cs.Write(privateKey, 0, privateKey.Length);
            cs.FlushFinalBlock();

            var encrypted = Convert.ToBase64String(ms.ToArray());
            var ivBase64 = Convert.ToBase64String(iv);

            return new DiffieHellmanKeyPair
            {
                PublicKey = publicKey,
                EncryptedPrivateKey = $"{ivBase64}:{encrypted}"
            };
        }
    }
}
