﻿using System.Text;
using System.Security.Cryptography;

namespace SmartWarDronesServer.Services
{
    public class AesUserIdService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesUserIdService(IConfiguration config)
        {
            var keyStr = config["AesIdentifier:Key"];
            var ivStr = config["AesIdentifier:IV"];

            if (string.IsNullOrWhiteSpace(keyStr))
                throw new ArgumentException("AesIdentifier:Key is missing or empty in configuration.");

            if (string.IsNullOrWhiteSpace(ivStr))
                throw new ArgumentException("AesIdentifier:IV is missing or empty in configuration.");

            _key = Encoding.UTF8.GetBytes(keyStr);
            _iv = Convert.FromBase64String(ivStr);
        }

        public string Encrypt(string userId)
        {
            Console.WriteLine($"[AesUserIdService.Encrypt] Plain userId: {userId}");
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var plainBytes = Encoding.UTF8.GetBytes(userId);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            var cipherBase64 = Convert.ToBase64String(cipherBytes);
            Console.WriteLine($"[AesUserIdService.Encrypt] Cipher (base64): {cipherBase64}");
            return cipherBase64;
        }


        public string Decrypt(string base64Cipher)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var cipherBytes = Convert.FromBase64String(base64Cipher);
            using var decryptor = aes.CreateDecryptor();
            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);

            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
