﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace SmartWarDrones.Server.Services
{
    public class IdentifierCryptoService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public IdentifierCryptoService(IConfiguration config)
        {
            var keyBase64 = config["AesIdentifier:Key"];
            var ivBase64 = config["AesIdentifier:IV"];
            _iv = Convert.FromBase64String(ivBase64!);
            _key = Encoding.UTF8.GetBytes(keyBase64!);
        }

        public string Encrypt(string plainText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var encryptor = aes.CreateEncryptor();
            var plainBytes = Encoding.UTF8.GetBytes(plainText);
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            var ivBase64 = Convert.ToBase64String(_iv);
            var cipherBase64 = Convert.ToBase64String(cipherBytes);
            return $"{ivBase64}:{cipherBase64}";
        }

        public string Decrypt(string encrypted)
        {
            var parts = encrypted.Split(':');
            if (parts.Length != 2) throw new ArgumentException("Invalid encrypted identifier format.");

            var cipherBytes = Convert.FromBase64String(parts[1]);

            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var decryptor = aes.CreateDecryptor();
            var decryptedBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            return Encoding.UTF8.GetString(decryptedBytes);
        }
    }
}
