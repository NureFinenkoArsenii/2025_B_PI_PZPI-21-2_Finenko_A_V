﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace SmartWarDrones.Server.Services
{
    public class AesBattlefieldsService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesBattlefieldsService(IConfiguration configuration)
        {
            var key = configuration["AesBattlefields:Key"];
            var iv = configuration["AesBattlefields:IV"];
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("AesBattlefields:Key is not set in configuration.");
            if (string.IsNullOrWhiteSpace(iv))
                throw new ArgumentException("AesBattlefields:IV is not set in configuration.");

            _key = Encoding.UTF8.GetBytes(key);
            _iv = Convert.FromBase64String(iv);
        }

        public string Encrypt(string plainText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var encryptor = aes.CreateEncryptor();
            var bytes = Encoding.UTF8.GetBytes(plainText);
            var encrypted = encryptor.TransformFinalBlock(bytes, 0, bytes.Length);
            return Convert.ToBase64String(encrypted);
        }

        public string Decrypt(string cipherText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var decryptor = aes.CreateDecryptor();
            var bytes = Convert.FromBase64String(cipherText);
            var decrypted = decryptor.TransformFinalBlock(bytes, 0, bytes.Length);
            return Encoding.UTF8.GetString(decrypted);
        }
    }
}
