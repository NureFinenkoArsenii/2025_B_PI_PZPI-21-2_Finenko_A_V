﻿using System.Security.Cryptography;
using System.Text;

namespace SmartWarDronesServer.Services
{
    public class AesBattlefieldOwnerIdService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesBattlefieldOwnerIdService(IConfiguration config)
        {
            var key = config["AesBattlefieldOwnerId:Key"];
            var iv = config["AesBattlefieldOwnerId:IV"];
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("AesBattlefieldOwnerId:Key is missing or empty in configuration.");
            if (string.IsNullOrWhiteSpace(iv))
                throw new ArgumentException("AesBattlefieldOwnerId:IV is missing or empty in configuration.");

            _key = Encoding.UTF8.GetBytes(key);
            _iv = Encoding.UTF8.GetBytes(iv);
        }

        public string Encrypt(string plainText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using var encryptor = aes.CreateEncryptor();
            var plainBytes = Encoding.UTF8.GetBytes(plainText);
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
            return Convert.ToBase64String(cipherBytes);
        }

        public string Decrypt(string cipherText)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using var decryptor = aes.CreateDecryptor();
            var cipherBytes = Convert.FromBase64String(cipherText);
            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
