﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace SmartWarDrones.Server.Services
{
    public class BioCryptoService
    {
        private readonly byte[] _aesKey;

        public BioCryptoService(IConfiguration configuration)
        {
            var base64Key = configuration["AesKeys:Bio"];
            if (string.IsNullOrWhiteSpace(base64Key))
                throw new ArgumentException("AES key for Bio is missing in configuration.");

            _aesKey = Convert.FromBase64String(base64Key);
        }

        public string Encrypt(string plainText)
        {
            try
            {
                using var aes = Aes.Create();
                aes.Key = _aesKey;
                aes.GenerateIV();
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor();
                var plainBytes = Encoding.UTF8.GetBytes(plainText); // Використовуємо UTF-8 кодування
                var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var result = new byte[aes.IV.Length + encryptedBytes.Length];
                Buffer.BlockCopy(aes.IV, 0, result, 0, aes.IV.Length);
                Buffer.BlockCopy(encryptedBytes, 0, result, aes.IV.Length, encryptedBytes.Length);

                // Логування зашифрованих даних
                Console.WriteLine("🔒 Encrypted Bio (Base64): " + Convert.ToBase64String(result));

                return Convert.ToBase64String(result);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error during encryption: {ex.Message}");
                throw new InvalidOperationException("AES encryption failed.");
            }
        }

        public string Decrypt(string base64CipherTextWithIv)
        {
            try
            {
                var fullCipher = Convert.FromBase64String(base64CipherTextWithIv);
                using var aes = Aes.Create();
                aes.Key = _aesKey;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                var iv = new byte[16];
                var cipherBytes = new byte[fullCipher.Length - 16];
                Buffer.BlockCopy(fullCipher, 0, iv, 0, 16);
                Buffer.BlockCopy(fullCipher, 16, cipherBytes, 0, cipherBytes.Length);
                aes.IV = iv;

                using var decryptor = aes.CreateDecryptor();
                var decryptedBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);

                var decryptedText = Encoding.UTF8.GetString(decryptedBytes);

                // Логування розшифрованих даних
                Console.WriteLine("🔓 Decrypted Bio: " + decryptedText);

                return decryptedText;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error during decryption: {ex.Message}");
                throw new InvalidOperationException("AES decryption failed.");
            }
        }


    }
}
