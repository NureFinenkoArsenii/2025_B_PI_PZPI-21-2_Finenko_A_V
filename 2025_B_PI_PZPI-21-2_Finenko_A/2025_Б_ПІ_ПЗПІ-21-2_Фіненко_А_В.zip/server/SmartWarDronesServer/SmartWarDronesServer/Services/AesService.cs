﻿using System.Security.Cryptography;
using System.Text;
using SmartWarDrones.Server.Models;

namespace SmartWarDrones.Server.Services
{
    public class AesService
    {
        private readonly RsaKeyService _rsaKeyService;

        public AesService(RsaKeyService rsaKeyService)
        {
            _rsaKeyService = rsaKeyService;
        }

        public string DecryptToJson(EncryptedMessage encrypted, string keyTag)
        {
            try
            {
                var aesKeyBytes = _rsaKeyService.Decrypt(keyTag, Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);

                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var decryptor = aes.CreateDecryptor();
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);

                var json = sr.ReadToEnd();

                // Логування дешифрованого JSON
                Console.WriteLine("🔓 Decrypted JSON: " + json);

                return json;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ AES Decryption failed for '{keyTag}': {ex.Message}");
                throw new InvalidOperationException("AES decryption failed.");
            }
        }

        public object EncryptJson(object payload, EncryptedMessage original, string keyTag)
        {
            // Отримуємо ключ та IV так само як при розшифруванні
            var aesKeyBytes = _rsaKeyService.Decrypt(keyTag, Convert.FromBase64String(original.EncryptedKey));
            var ivBytes = Convert.FromBase64String(original.Iv);

            // Серіалізуємо payload у JSON
            var json = System.Text.Json.JsonSerializer.Serialize(payload);

            using var aes = Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            var plainBytes = Encoding.UTF8.GetBytes(json);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            // Повертаємо відповідь у форматі { ciphertext, iv }
            return new
            {
                ciphertext = Convert.ToBase64String(cipherBytes),
                iv = original.Iv // можна залишити той самий, бо фронт його знає
            };
        }



        public byte[] DecryptAESKey(string encryptedKeyBase64, string tag)
        {
            var encryptedKey = Convert.FromBase64String(encryptedKeyBase64);
            return _rsaKeyService.Decrypt(tag, encryptedKey);
        }
    }
}
