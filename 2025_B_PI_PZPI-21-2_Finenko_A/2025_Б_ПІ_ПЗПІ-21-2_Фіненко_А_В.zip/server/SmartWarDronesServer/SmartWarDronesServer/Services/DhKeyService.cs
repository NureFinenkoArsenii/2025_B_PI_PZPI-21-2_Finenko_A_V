﻿using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;

namespace SmartWarDrones.Server.Services
{
    public class DhKeyService
{
    private readonly byte[] _aesKey;

    public DhKeyService(IConfiguration config)
    {
        var keyBase64 = config["DhEncryption:Key"];
        if (string.IsNullOrWhiteSpace(keyBase64))
            throw new Exception("Missing DH AES Key in config");
        _aesKey = Convert.FromBase64String(keyBase64);
    }

    // Розшифрувати приватний DH (userA)
    public ECDiffieHellman ImportUserPrivateKey(string privateDhPrivateEncrypted)
    {
        var parts = privateDhPrivateEncrypted.Split(':');
        if (parts.Length != 2) throw new Exception("Invalid DH format");
        var iv = Convert.FromBase64String(parts[0]);
        var encrypted = Convert.FromBase64String(parts[1]);

        using var aes = Aes.Create();
        aes.Key = _aesKey;
        aes.IV = iv;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;

        using var decryptor = aes.CreateDecryptor();
        using var ms = new MemoryStream(encrypted);
        using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
        using var msOut = new MemoryStream();
        cs.CopyTo(msOut);
        var privateKey = msOut.ToArray();

        // Імпортуємо EC приватний ключ
        var ec = ECDiffieHellman.Create();
        ec.ImportECPrivateKey(privateKey, out _);
        return ec;
    }

        // Імпортувати публічний DH-ключ (userB)
        public ECDiffieHellmanPublicKey ImportPublicKey(string publicDhBase64)
        {
            var bytes = Convert.FromBase64String(publicDhBase64);
            using var ec = ECDiffieHellman.Create();
            ec.ImportSubjectPublicKeyInfo(bytes, out _);
            return ec.PublicKey;
        }

        public byte[] CalculateSharedSecret(string privateDhPrivateEncrypted, string publicDhBase64)
    {
        using var userAPriv = ImportUserPrivateKey(privateDhPrivateEncrypted);
        var userBPub = ImportPublicKey(publicDhBase64);

        return userAPriv.DeriveKeyMaterial(userBPub);
    }
    }
}
