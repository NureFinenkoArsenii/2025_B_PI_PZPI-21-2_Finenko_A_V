﻿using SmartWarDrones.Server.Models;
using Konscious.Security.Cryptography;
using MongoDB.Driver;
using System.Text;
using SmartWarDrones.Server.Services;
using System.Security.Cryptography;
using System.Text.Json;

namespace SmartWarDrones.Server.Services
{
    public class PasswordService
    {
        private readonly IMongoCollection<Person> _people;
        private readonly AesService _aesService;

        public PasswordService(IMongoClient mongoClient, IConfiguration config, AesService aesService)
        {
            _aesService = aesService;
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _people = db.GetCollection<Person>("persons");
        }

        public async Task<(bool Success, string Message)> ChangePasswordAsync(string userId, EncryptedMessage encrypted)
        {
            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return (false, "User not found");

            try
            {
                var decryptedJson = _aesService.DecryptToJson(encrypted, "change-password");
                var parsed = JsonSerializer.Deserialize<ChangePasswordRequest>(decryptedJson);
                if (parsed == null)
                    return (false, "Invalid data");
                Console.WriteLine($"✅ Parsed request: Old={parsed.OldPassword}, New={parsed.NewPassword}, Confirm={parsed.ConfirmPassword}");

                // Перевірка старого паролю
                var storedBytes = Convert.FromBase64String(user.PasswordHash);
                var salt = storedBytes[..16];
                var storedHash = storedBytes[16..];

                var argon2 = new Argon2id(Encoding.UTF8.GetBytes(parsed.OldPassword))
                {
                    Salt = salt,
                    DegreeOfParallelism = 8,
                    Iterations = 4,
                    MemorySize = 65536
                };

                var oldHash = argon2.GetBytes(32);
                if (!oldHash.SequenceEqual(storedHash))
                    return (false, "Old password is incorrect");

                if (parsed.NewPassword != parsed.ConfirmPassword)
                    return (false, "Passwords do not match");

                // Генеруємо новий хеш
                var newSalt = RandomNumberGenerator.GetBytes(16);
                var newHash = HashPassword(parsed.NewPassword, newSalt);
                var newHashBase64 = Convert.ToBase64String(newHash);

                var update = Builders<Person>.Update.Set(p => p.PasswordHash, newHashBase64);
                await _people.UpdateOneAsync(p => p.Id == user.Id, update);

                return (true, "Password updated successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Password update failed: {ex.Message}");
                return (false, "Decryption or update failed");
            }
        }

        private static byte[] HashPassword(string password, byte[] salt)
        {
            var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = salt,
                DegreeOfParallelism = 8,
                Iterations = 4,
                MemorySize = 65536
            };

            var hash = argon2.GetBytes(32);
            var result = new byte[salt.Length + hash.Length];
            Buffer.BlockCopy(salt, 0, result, 0, salt.Length);
            Buffer.BlockCopy(hash, 0, result, salt.Length, hash.Length);
            return result;
        }
    }
}
