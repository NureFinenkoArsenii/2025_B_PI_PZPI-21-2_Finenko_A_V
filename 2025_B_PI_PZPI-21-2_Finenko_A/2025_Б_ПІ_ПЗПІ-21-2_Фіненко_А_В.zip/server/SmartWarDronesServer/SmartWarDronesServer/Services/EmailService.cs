﻿using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;

namespace SmartWarDrones.Server.Services
{
    public class EmailService
    {
        private readonly string _smtpServer = "smtp.gmail.com";
        private readonly int _port = 587;
        private readonly string _fromEmail;
        private readonly string _password;

        public EmailService(IConfiguration configuration)
        {
            _fromEmail = configuration["EmailSettings:Sender"]!;
            _password = configuration["EmailSettings:Password"]!;
        }

        public async Task<bool> SendEmailAsync(string fromName, string fromEmail, string subject, string message)
        {
            try
            {
                var body = $"<b>From:</b> {fromName} ({fromEmail})<br/><b>Subject:</b> {subject}<br/><br/><b>Message:</b><br/>{message}";

                var mail = new MailMessage
                {
                    From = new MailAddress(_fromEmail),
                    Subject = $"Contact Form: {subject}",
                    Body = body,
                    IsBodyHtml = true
                };
                mail.To.Add(_fromEmail);
                mail.ReplyToList.Add(new MailAddress(fromEmail));

                using var smtp = new SmtpClient(_smtpServer, _port)
                {
                    Credentials = new NetworkCredential(_fromEmail, _password),
                    EnableSsl = true
                };

                await smtp.SendMailAsync(mail);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
