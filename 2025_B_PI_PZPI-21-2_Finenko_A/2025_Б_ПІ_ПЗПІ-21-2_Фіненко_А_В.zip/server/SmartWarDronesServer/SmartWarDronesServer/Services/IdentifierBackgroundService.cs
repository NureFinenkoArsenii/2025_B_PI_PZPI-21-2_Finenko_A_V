﻿using Microsoft.Extensions.Hosting;

namespace SmartWarDrones.Server.Services
{
    public class IdentifierBackgroundService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<IdentifierBackgroundService> _logger;

        public IdentifierBackgroundService(IServiceProvider serviceProvider, ILogger<IdentifierBackgroundService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                using var scope = _serviceProvider.CreateScope();
                var identifierService = scope.ServiceProvider.GetRequiredService<IdentifierService>();

                try
                {
                    _logger.LogInformation("🔁 Updating all identifiers (global refresh)...");
                    await identifierService.UpdateAllIdentifiersAsync();
                }
                catch (Exception ex)
                {
                    _logger.LogError($"❌ Failed to update identifiers: {ex.Message}");
                }

                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }
    }
}
