﻿using MongoDB.Bson;
using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDronesServer.Models;
using SmartWarDronesServer.Services;


namespace SmartWarDrones.Server.Services
{
    public class MessageService
    {
        private readonly IMongoCollection<PrivateMessage> _messages;
        private readonly IMongoCollection<PrivateChat> _privateChats;
        private readonly AesUserIdService _userIdCrypto;
        private readonly AesMessageIdService _messageIdCrypto;
        private readonly IMongoCollection<Person> _people;
        private readonly DhKeyService _dhKeyService;
        private readonly AesMessageIdService _aesMessageIdService;

        public MessageService(IConfiguration config,
            IMongoClient mongoClient,
            AesUserIdService userIdCrypto,
            AesMessageIdService messageIdCrypto,
            DhKeyService dhKeyService,
            AesMessageIdService aesMessageIdService)
        {
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _messages = db.GetCollection<PrivateMessage>("private_messages");
            _privateChats = db.GetCollection<PrivateChat>("private_chats");
            _people = db.GetCollection<Person>("people"); // Додай колекцію Person!
            _userIdCrypto = userIdCrypto;
            _messageIdCrypto = messageIdCrypto;
            _dhKeyService = dhKeyService;
            _aesMessageIdService = aesMessageIdService;
        }

        // Отримати список повідомлень за списком айді
        public async Task<List<PrivateMessage>> GetMessagesByIdsAsync(List<string> messageIds, int limit = 50)
        {
            var filter = Builders<PrivateMessage>.Filter.In(m => m.Id, messageIds);
            return await _messages.Find(filter)
                .SortByDescending(m => m.CreatedAt)
                .Limit(limit)
                .ToListAsync();
        }

        public async Task<List<PrivateChat>> GetPrivateChatsByUserAsync(string encryptedUserId, int limit)
        {
            var filter = Builders<PrivateChat>.Filter.Or(
                Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUserId),
                Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUserId)
            );
            return await _privateChats.Find(filter).Limit(limit).ToListAsync();
        }

        // Отримати масив айдішок для двох користувачів (шифруємо сталим AES)
        public async Task<List<string>> GetPrivateChatMessageIdsAsync(string userId, string friendId)
        {
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(friendId);

            var filter = Builders<PrivateChat>.Filter.Or(
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUserId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedFriendId)
                ),
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedFriendId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUserId)
                )
            );

            var chat = await _privateChats.Find(filter).FirstOrDefaultAsync();
            if (chat == null) return new List<string>();

            // Дешифруємо кожен id
            return chat.PrivateMessagesIds
                .Select(encId => _messageIdCrypto.Decrypt(encId))
                .ToList();
        }

        // Додаємо у метод AddMessageToPrivateChat:
        public async Task AddMessageToPrivateChat(string userId, string friendId, string messageId)
        {
            Console.WriteLine($"[AddMessageToPrivateChat] userId (plaintext): {userId}");
            Console.WriteLine($"[AddMessageToPrivateChat] friendId (plaintext): {friendId}");

            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(friendId);
            var encryptedMessageId = _messageIdCrypto.Encrypt(messageId);

            Console.WriteLine($"[AddMessageToPrivateChat] encryptedUserId: {encryptedUserId}");
            Console.WriteLine($"[AddMessageToPrivateChat] encryptedFriendId: {encryptedFriendId}");
            Console.WriteLine($"[AddMessageToPrivateChat] encryptedMessageId: {encryptedMessageId}");

            var filter = Builders<PrivateChat>.Filter.Or(
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUserId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedFriendId)
                ),
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedFriendId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUserId)
                )
            );
            Console.WriteLine("[AddMessageToPrivateChat] Mongo Filter (base64):");
            Console.WriteLine($"  person1 = {encryptedUserId} && person2 = {encryptedFriendId}");
            Console.WriteLine($"  OR person1 = {encryptedFriendId} && person2 = {encryptedUserId}");

            var chat = await _privateChats.Find(filter).FirstOrDefaultAsync();

            if (chat == null)
            {
                Console.WriteLine($"[MessageService] Creating new PrivateChat for: {userId} <-> {friendId}");
                var newChat = new PrivateChat
                {
                    Person1 = encryptedUserId,
                    Person2 = encryptedFriendId,
                    PrivateMessagesIds = new List<string> { encryptedMessageId }
                };
                await _privateChats.InsertOneAsync(newChat);
            }
            else
            {
                Console.WriteLine($"[MessageService] Adding encrypted message {encryptedMessageId} to existing chat {chat.Id}");
                var update = Builders<PrivateChat>.Update.Push(c => c.PrivateMessagesIds, encryptedMessageId);
                await _privateChats.UpdateOneAsync(filter, update);
            }
        }


        public async Task<PrivateMessage> CreateMessageAsync(PrivateMessage message)
        {
            Console.WriteLine("[CreateMessageAsync] Перед вставкою в базу. Attachments (JSON): " +
        System.Text.Json.JsonSerializer.Serialize(message.Attachments));
            await _messages.InsertOneAsync(message);
            return message;
        }

        // Оновлений метод!
        public async Task EditMessageAsync(string messageId, string newCiphertext, string newIv, string newIsEdited)
        {
            var update = Builders<PrivateMessage>.Update
                .Set(m => m.Ciphertext, newCiphertext)
                .Set(m => m.Iv, newIv)
                .Set(m => m.IsEdited, newIsEdited); // string!

            await _messages.UpdateOneAsync(m => m.Id == messageId, update);
        }

        public async Task<PrivateChat?> GetPrivateChatBetweenAsync(string encryptedUser1, string encryptedUser2)
        {
            var filter = Builders<PrivateChat>.Filter.Or(
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUser1),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUser2)
                ),
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUser2),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUser1)
                )
            );
            return await _privateChats.Find(filter).FirstOrDefaultAsync();
        }


        public async Task DeleteChatByIdAsync(string chatId)
        {
            await _privateChats.DeleteOneAsync(chat => chat.Id == chatId);
        }


        public async Task DeleteMessagesByIdsAsync(List<string> messageIds)
        {
            await _messages.DeleteManyAsync(msg => messageIds.Contains(msg.Id));
        }


        public async Task SetChatDeletedForAsync(string chatId, string encryptedUserId)
        {
            var update = Builders<PrivateChat>.Update.Set(c => c.DeletedFor, encryptedUserId);
            await _privateChats.UpdateOneAsync(c => c.Id == chatId, update);
        }


        public async Task SetMessagesDeletedForAsync(List<string> messageIds, string encryptedUserId)
        {
            var filter = Builders<PrivateMessage>.Filter.In(m => m.Id, messageIds);
            var update = Builders<PrivateMessage>.Update.Set(m => m.DeletedFor, encryptedUserId);
            await _messages.UpdateManyAsync(filter, update);
        }

        public async Task DeleteMessageForUserAsync(string messageId, string encryptedUserId)
        {
            var message = await _messages.Find(m => m.Id == messageId).FirstOrDefaultAsync();
            if (message == null) return;

            if (string.IsNullOrEmpty(message.DeletedFor))
            {
                // Перший користувач видалив — просто ставимо своє id
                var update = Builders<PrivateMessage>.Update.Set(m => m.DeletedFor, encryptedUserId);
                await _messages.UpdateOneAsync(m => m.Id == messageId, update);
            }
            else if (message.DeletedFor != encryptedUserId)
            {
                // Якщо другий користувач вже видалив — видаляємо з бази
                await _messages.DeleteOneAsync(m => m.Id == messageId);
            }
            // Якщо вже стоїть наш id — нічого не робимо
        }

        public async Task ResetChatDeletedForAsync(string userId, string friendId)
        {
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(friendId);

            var filter = Builders<PrivateChat>.Filter.Or(
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedUserId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedFriendId)
                ),
                Builders<PrivateChat>.Filter.And(
                    Builders<PrivateChat>.Filter.Eq(c => c.Person1, encryptedFriendId),
                    Builders<PrivateChat>.Filter.Eq(c => c.Person2, encryptedUserId)
                )
            );
            var update = Builders<PrivateChat>.Update.Set(c => c.DeletedFor, null);
            await _privateChats.UpdateOneAsync(filter, update);
        }


        public async Task RemoveMessageIdFromChatsAsync(string messageId)
        {
            var encryptedMessageId = _messageIdCrypto.Encrypt(messageId);
            var filter = Builders<PrivateChat>.Filter.AnyEq(c => c.PrivateMessagesIds, encryptedMessageId);
            var update = Builders<PrivateChat>.Update.Pull(c => c.PrivateMessagesIds, encryptedMessageId);
            await _privateChats.UpdateManyAsync(filter, update);
        }
        public async Task SetMessageCheckedAsync(string messageId, string newIsChecked)
        {
            var update = Builders<PrivateMessage>.Update
                .Set(m => m.IsChecked, newIsChecked);
            await _messages.UpdateOneAsync(m => m.Id == messageId, update);
        }

        public async Task<PrivateMessage?> GetMessageByIdAsync(string messageId)
        {
            return await _messages.Find(m => m.Id == messageId).FirstOrDefaultAsync();
        }

        public async Task DeleteMessageByIdAsync(string messageId)
        {
            await _messages.DeleteOneAsync(m => m.Id == messageId);
        }

        public async Task SetMessageDeletedForAsync(string messageId, string encryptedUserId)
        {
            var update = Builders<PrivateMessage>.Update.Set(m => m.DeletedFor, encryptedUserId);
            await _messages.UpdateOneAsync(m => m.Id == messageId, update);
        }

        public async Task<int> CountUnreadMessagesForChatAsync(string userId, string friendId)
        {
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(friendId);

            var chat = await _privateChats.Find(c =>
                (c.Person1 == encryptedUserId && c.Person2 == encryptedFriendId) ||
                (c.Person1 == encryptedFriendId && c.Person2 == encryptedUserId)
            ).FirstOrDefaultAsync();

            if (chat == null || chat.PrivateMessagesIds == null) return 0;

            // Завантажити всі повідомлення цього чату
            var realMessageIds = chat.PrivateMessagesIds.Select(id => _aesMessageIdService.Decrypt(id)).ToList();
            var messages = await GetMessagesByIdsAsync(realMessageIds);

            int count = 0;
            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            var friend = await _people.Find(p => p.Id == friendId).FirstOrDefaultAsync();
            if (user == null || friend == null) return 0;
            var dhSecret = _dhKeyService.CalculateSharedSecret(user.PrivateDhPrivateEncrypted, friend.PublicDhPrivate);

            foreach (var msg in messages)
            {
                // Фільтруємо видалені для цього userId
                if (!string.IsNullOrEmpty(msg.DeletedFor) && msg.DeletedFor == encryptedUserId)
                    continue;

                string senderIdPlain, isCheckedPlain;
                try
                {
                    senderIdPlain = AesDecrypt(msg.SenderId, dhSecret, Convert.FromBase64String(msg.Iv));
                    isCheckedPlain = AesDecrypt(msg.IsChecked ?? "", dhSecret, Convert.FromBase64String(msg.Iv));
                }
                catch
                {
                    continue;
                }
                if (senderIdPlain != userId && isCheckedPlain == "false")
                    count++;
            }
            return count;
        }

        public string AesDecrypt(string base64, byte[] key, byte[] iv)
        {
            var bytes = Convert.FromBase64String(base64);
            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = key;
            aes.IV = iv;
            aes.Mode = System.Security.Cryptography.CipherMode.CBC;
            aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;
            using var decryptor = aes.CreateDecryptor();
            var plainBytes = decryptor.TransformFinalBlock(bytes, 0, bytes.Length);
            return System.Text.Encoding.UTF8.GetString(plainBytes);
        }

    }
}
