﻿using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using System.Text;

namespace SmartWarDrones.Server.Services
{
    public class IdentifierService
    {
        private readonly IMongoCollection<Person> _people;
        private readonly ILogger<IdentifierService> _logger;
        private readonly IdentifierCryptoService _crypto;
        private static DateTime _lastGlobalUpdate = DateTime.UtcNow;

        public IdentifierService(
            IMongoClient mongoClient,
            IConfiguration config,
            ILogger<IdentifierService> logger,
            IdentifierCryptoService crypto)
        {
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _people = db.GetCollection<Person>("persons");
            _logger = logger;
            _crypto = crypto;
        }

        public async Task UpdateAllIdentifiersAsync()
        {
            var users = await _people.Find(_ => true).ToListAsync();

            foreach (var user in users)
            {
                try
                {
                    var oldPlain = _crypto.Decrypt(user.Identifier);

                    var newPlain = GenerateIdentifier();
                    var newEncrypted = _crypto.Encrypt(newPlain);

                    var update = Builders<Person>.Update
                        .Set(p => p.PreviousIdentifier, user.Identifier) 
                        .Set(p => p.Identifier, newEncrypted);

                    await _people.UpdateOneAsync(p => p.Id == user.Id, update);

                    _logger.LogInformation($"🔄 Identifier updated for {user.Name}: {oldPlain} → {newPlain}");
                }
                catch (Exception ex)
                {
                    _logger.LogError($"❌ Error updating identifier for user {user.Name}: {ex.Message}");
                }
            }

            _lastGlobalUpdate = DateTime.UtcNow;
        }

        public static string GenerateIdentifier()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            var sb = new StringBuilder(6);
            for (int i = 0; i < 6; i++)
                sb.Append(chars[random.Next(chars.Length)]);
            return sb.ToString();
        }

        public DateTime GetLastGlobalUpdateTime() => _lastGlobalUpdate;
    }
}
