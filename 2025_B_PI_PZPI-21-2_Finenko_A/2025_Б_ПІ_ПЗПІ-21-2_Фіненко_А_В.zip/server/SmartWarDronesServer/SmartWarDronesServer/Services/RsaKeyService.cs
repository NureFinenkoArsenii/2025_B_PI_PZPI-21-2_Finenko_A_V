﻿using System.Security.Cryptography;
using System.Text;

namespace SmartWarDrones.Server.Services
{
    public class RsaKeyService
    {
        private readonly Dictionary<string, RSA> _keyPairs = new();

        public RsaKeyService()
        {
            _keyPairs["email"] = RSA.Create(2048);
            _keyPairs["register"] = RSA.Create(2048);
            _keyPairs["login"] = RSA.Create(2048);
            _keyPairs["change-password"] = RSA.Create(2048);
            _keyPairs["update-bio"] = RSA.Create(2048);
            _keyPairs["upload-avatar"] = RSA.Create(2048);
            _keyPairs["profile"] = RSA.Create(2048);
            _keyPairs["avatar-image"] = RSA.Create(2048);
            _keyPairs["contacts"] = RSA.Create(2048);
            _keyPairs["messages"] = RSA.Create(2048);
            _keyPairs["test-map"] = RSA.Create(2048);
            _keyPairs["drones"] = RSA.Create(2048);
            _keyPairs["battlefields"] = RSA.Create(2048);
            _keyPairs["global-chat"] = RSA.Create(2048);
        }

        public string GetPublicKey(string tag)
        {
            if (!_keyPairs.ContainsKey(tag))
                throw new ArgumentException($"RSA key with tag '{tag}' does not exist.");

            var rsa = _keyPairs[tag];
            var publicKey = rsa.ExportSubjectPublicKeyInfo();
            return Convert.ToBase64String(publicKey);
        }

        public byte[] Decrypt(string tag, byte[] encryptedData)
        {
            if (!_keyPairs.ContainsKey(tag))
                throw new ArgumentException($"RSA key with tag '{tag}' does not exist.");

            var rsa = _keyPairs[tag];
            var decrypted = rsa.Decrypt(encryptedData, RSAEncryptionPadding.Pkcs1);
            var base64 = Encoding.UTF8.GetString(decrypted);
            return Convert.FromBase64String(base64);
        }
    }
}