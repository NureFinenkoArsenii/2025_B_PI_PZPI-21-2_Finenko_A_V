﻿using System.Security.Cryptography;
using System.Text;

namespace SmartWarDronesServer.Services
{
    public class AesMessageIdService
    {
        private readonly byte[] _key;
        private readonly byte[] _iv;

        public AesMessageIdService(IConfiguration config)
        {
            var keyStr = config["AesMessageId:Key"];
            var ivStr = config["AesMessageId:IV"];
            if (string.IsNullOrWhiteSpace(keyStr)) throw new ArgumentException("AesMessageId:Key is missing.");
            if (string.IsNullOrWhiteSpace(ivStr)) throw new ArgumentException("AesMessageId:IV is missing.");

            _key = Encoding.UTF8.GetBytes(keyStr);
            _iv = Convert.FromBase64String(ivStr);
        }

        public string Encrypt(string objectId)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var plainBytes = Encoding.UTF8.GetBytes(objectId);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            return Convert.ToBase64String(cipherBytes);
        }

        public string Decrypt(string base64Cipher)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            aes.IV = _iv;

            var cipherBytes = Convert.FromBase64String(base64Cipher);
            using var decryptor = aes.CreateDecryptor();
            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);

            var id = Encoding.UTF8.GetString(plainBytes);

            // Check that this is a valid 24-character hex string (ObjectId)
            if (id.Length != 24 || !System.Text.RegularExpressions.Regex.IsMatch(id, @"^[a-fA-F0-9]{24}$"))
                throw new FormatException($"MessageId after decryption is not valid ObjectId: {id}");

            return id;
        }

    }
}
