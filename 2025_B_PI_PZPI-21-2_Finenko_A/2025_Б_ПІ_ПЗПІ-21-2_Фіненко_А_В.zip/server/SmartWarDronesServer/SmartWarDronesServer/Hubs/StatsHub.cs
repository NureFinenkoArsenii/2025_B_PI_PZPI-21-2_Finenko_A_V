﻿using Microsoft.AspNetCore.SignalR;

namespace SmartWarDronesServer.Hubs
{
    public class StatsHub : Hub
    {
        // Определите методы для взаимодействия с клиентами
    }
}
