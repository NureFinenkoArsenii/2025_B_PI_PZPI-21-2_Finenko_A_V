﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models
{
    public class PrivateChat
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("person1")]
        public string Person1 { get; set; } = string.Empty;

        [BsonElement("person2")]
        public string Person2 { get; set; } = string.Empty;

        [BsonElement("privateMessagesIds")]
        public List<string> PrivateMessagesIds { get; set; } = new List<string>();

        [BsonElement("deletedFor")]
        public string DeletedFor { get; set; } = string.Empty;
    }

}
