﻿using System.Text.Json.Serialization;

namespace SmartWarDrones.Server.Models
{
    public class RegisterData
    {
        [JsonPropertyName("login")]
        public string Login { get; set; } = "";

        [JsonPropertyName("password")]
        public string Password { get; set; } = "";

        [JsonPropertyName("role")]
        public string Role { get; set; } = "";
    }
}
