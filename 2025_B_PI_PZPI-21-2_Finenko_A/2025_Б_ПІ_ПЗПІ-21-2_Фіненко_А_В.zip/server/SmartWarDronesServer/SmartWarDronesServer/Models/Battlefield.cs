﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace SmartWarDrones.Server.Models
{
    public class Battlefield
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("name")]
        public string Name { get; set; } = string.Empty;

        [BsonElement("about")]
        public string About { get; set; } = string.Empty;

        [BsonElement("mapFocus")]
        public string MapFocus { get; set; } = string.Empty;

        [BsonElement("mapSize")]
        public string MapSize { get; set; } = string.Empty;

        [BsonElement("mapStyle")]
        public string MapStyle { get; set; } = string.Empty;

        [BsonElement("mapAvatarUrl")]
        public string MapAvatarUrl { get; set; } = string.Empty;

        [BsonElement("dronesIds")]
        public List<string> DronesIds { get; set; } = new List<string>();

        [BsonElement("ownerId")]
        public string OwnerId { get; set; } = string.Empty;
    }
}
