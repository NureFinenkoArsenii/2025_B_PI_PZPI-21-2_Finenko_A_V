﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SmartWarDrones.Server.Models
{
    public class GlobalChat
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("globalMessagesIds")]
        public List<string> GlobalMessagesIds { get; set; } = new();

        [BsonElement("battlefieldId")]
        public string BattlefieldId { get; set; } = string.Empty; // зашифрований id напряму

        [BsonElement("chatPublicDhGroup")]
        public string ChatPublicDhGroup { get; set; } = string.Empty; // публічний DH ключ

        [BsonElement("chatPrivateDhGroupEncrypted")]
        public string ChatPrivateDhGroupEncrypted { get; set; } = string.Empty; // зашифрований приватний DH ключ
    }
}
