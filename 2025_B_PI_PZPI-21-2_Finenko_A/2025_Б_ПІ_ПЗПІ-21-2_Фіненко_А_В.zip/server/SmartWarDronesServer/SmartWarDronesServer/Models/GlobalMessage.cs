﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Text.Json.Serialization;

namespace SmartWarDrones.Server.Models
{

    public class GlobalMessage
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("senderId")]
        [JsonPropertyName("senderId")]
        public string SenderId { get; set; } = string.Empty;

        [BsonElement("ciphertext")]
        [JsonPropertyName("ciphertext")]
        public string Ciphertext { get; set; } = string.Empty;

        [BsonElement("iv")]
        [JsonPropertyName("iv")]
        public string Iv { get; set; } = string.Empty;

        [BsonElement("createdAt")]
        [JsonPropertyName("createdAt")]
        public string CreatedAt { get; set; } = string.Empty;

        [BsonElement("isEdited")]
        [JsonPropertyName("isEdited")]
        public string IsEdited { get; set; } = string.Empty;

        [BsonElement("attachments")]
        [JsonPropertyName("attachments")]
        public string Attachments { get; set; } = string.Empty;

        [BsonElement("replyId")]
        [JsonPropertyName("replyId")]
        public string ReplyId { get; set; } = string.Empty;

        [BsonElement("whoChecked")]
        [JsonPropertyName("whoChecked")]
        public string WhoChecked { get; set; } = string.Empty;
    }

}
