﻿using System.Text.Json.Serialization;

namespace SmartWarDrones.Server.Models
{
    public class ChangePasswordRequest
    {
        [JsonPropertyName("oldPassword")]
        public string OldPassword { get; set; } = "";

        [JsonPropertyName("newPassword")]
        public string NewPassword { get; set; } = "";

        [JsonPropertyName("confirmPassword")]
        public string ConfirmPassword { get; set; } = "";
    }
}
