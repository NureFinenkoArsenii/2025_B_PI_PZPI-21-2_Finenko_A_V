﻿namespace SmartWarDronesServer.Models
{
    public class ProfileData
    {
        public string Name { get; set; } = "";
        public string Role { get; set; } = "";
        public string AvatarUrl { get; set; } = "";
        public string Bio { get; set; } = "";
        public string Identifier { get; set; } = "";
    }
}
