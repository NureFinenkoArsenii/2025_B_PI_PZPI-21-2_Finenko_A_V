﻿namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestStatsResponseModel
    {
        public string StatsType { get; set; } = string.Empty;
        public string StatsInformation { get; set; } = string.Empty;
    }
}
