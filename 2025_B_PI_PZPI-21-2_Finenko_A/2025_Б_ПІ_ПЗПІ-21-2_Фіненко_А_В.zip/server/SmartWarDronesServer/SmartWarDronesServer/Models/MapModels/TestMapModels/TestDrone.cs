﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestDrone
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("droneName")]
        public string DroneName { get; set; } = string.Empty;

        [BsonElement("droneType")]
        public string DroneType { get; set; } = string.Empty;

        [BsonElement("testSafetyCode")]
        public string SafetyCode { get; set; } = string.Empty;

        [BsonElement("personId")]
        public string PersonId { get; set; } = string.Empty;
    }
}
