﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestStats
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("statsType")]
        public string StatsType { get; set; } = string.Empty;

        [BsonElement("statsInformation")]
        public string StatsInformation { get; set; } = string.Empty;

        [BsonElement("DroneId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string DroneId { get; set; } = string.Empty;

        [BsonElement("lastUpd")]
        public DateTime? LastUpdate { get; set; }
    }
}
