﻿namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestStatsApiModel
    {
        public string StatsType { get; set; } = string.Empty;
        public string StatsInformation { get; set; } = string.Empty;
    }
}
