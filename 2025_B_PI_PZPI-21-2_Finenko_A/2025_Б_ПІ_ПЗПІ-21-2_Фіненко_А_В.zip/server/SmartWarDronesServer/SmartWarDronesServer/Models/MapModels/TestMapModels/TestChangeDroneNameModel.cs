﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestChangeDroneNameModel
    {
        [BsonElement("DroneId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string DroneId { get; set; } = string.Empty;

        public string NewDroneName { get; set; } = string.Empty;
    }
}
