﻿namespace SmartWarDronesServer.Models.MapModels.TestMapModels
{
    public class TestDroneApiModel
    {
        public string DroneName { get; set; } = string.Empty;
        public string DroneType { get; set; } = string.Empty;
        public string SafetyCode { get; set; } = string.Empty;
    }
}
