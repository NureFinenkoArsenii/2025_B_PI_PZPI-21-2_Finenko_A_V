﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class Drone
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("droneName")]
        public string DroneName { get; set; } = string.Empty;

        [BsonElement("droneType")]
        public string DroneType { get; set; } = string.Empty;

        [BsonElement("frequencyBand")]
        public string FrequencyBand { get; set; } = string.Empty;

        [BsonElement("avatarUrl")]
        public string AvatarUrl { get; set; } = "";

        [BsonElement("SafetyCode")]
        public string SafetyCode { get; set; } = string.Empty;

        [BsonElement("operatorId")]
        public string OperatorId { get; set; } = string.Empty;
    }
}
