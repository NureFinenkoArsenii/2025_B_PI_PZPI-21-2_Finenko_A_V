﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class DroneResponseModel
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;
        public string DroneName { get; set; } = string.Empty;
        public string DroneType { get; set; } = string.Empty;
    }
}
