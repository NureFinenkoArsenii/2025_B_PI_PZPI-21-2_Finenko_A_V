﻿namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class DroneApiModel
    {
        public string DroneName { get; set; } = string.Empty;
        public string DroneType { get; set; } = string.Empty;
        public string SafetyCode { get; set; } = string.Empty;
    }
}
