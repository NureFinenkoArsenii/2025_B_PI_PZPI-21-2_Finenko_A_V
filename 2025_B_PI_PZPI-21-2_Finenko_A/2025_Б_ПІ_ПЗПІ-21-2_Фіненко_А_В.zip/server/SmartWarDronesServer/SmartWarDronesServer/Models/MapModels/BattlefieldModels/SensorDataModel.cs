﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class SensorDataModel
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string DroneId { get; set; } = string.Empty;
        public double Temperature { get; set; }
        public double Humidity { get; set; }
        public double WindSpeed { get; set; }
        public string WindDirection { get; set; } = string.Empty;
        public double BatteryLevel { get; set; }
        public bool REBPresence { get; set; }
    }
}
