﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class ChangeDroneTypeModel
    {
        [BsonElement("DroneId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string DroneId { get; set; } = string.Empty;

        public string NewDroneType { get; set; } = string.Empty;
    }
}
