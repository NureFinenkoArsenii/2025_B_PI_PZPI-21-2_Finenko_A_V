﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models.MapModels.BattlefieldModels
{
    public class Stats
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("statsType")]
        public string StatsType { get; set; } = string.Empty;

        [BsonElement("statsInformation")]
        public string StatsInformation { get; set; } = string.Empty;

        [BsonElement("DroneId")]
        public string DroneId { get; set; } = string.Empty;

        [BsonElement("lastUpd")]
        public DateTime? LastUpdate { get; set; }
    }
}
