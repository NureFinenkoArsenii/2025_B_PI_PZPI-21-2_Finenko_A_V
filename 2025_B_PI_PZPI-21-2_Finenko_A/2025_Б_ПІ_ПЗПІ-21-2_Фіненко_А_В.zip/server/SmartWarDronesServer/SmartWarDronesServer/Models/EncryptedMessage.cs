﻿namespace SmartWarDrones.Server.Models
{
    public class EncryptedMessage
    {
        public string EncryptedKey { get; set; } = string.Empty;
        public string Iv { get; set; } = string.Empty;
        public string Ciphertext { get; set; } = string.Empty;
    }
}
