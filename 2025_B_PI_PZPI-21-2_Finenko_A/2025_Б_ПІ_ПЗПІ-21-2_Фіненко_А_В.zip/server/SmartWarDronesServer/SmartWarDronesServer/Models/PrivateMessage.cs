﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Text.Json.Serialization;

namespace SmartWarDrones.Server.Models
{
    public class PrivateMessage
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [JsonPropertyName("_id")]
        public string Id { get; set; } = string.Empty;

        [BsonElement("senderId")]
        [JsonPropertyName("senderId")]
        public string SenderId { get; set; } = string.Empty;

        [BsonElement("receiverId")]
        [JsonPropertyName("receiverId")]
        public string ReceiverId { get; set; } = string.Empty;

        [BsonElement("ciphertext")]
        [JsonPropertyName("ciphertext")]
        public string Ciphertext { get; set; } = string.Empty;

        [BsonElement("iv")]
        [JsonPropertyName("iv")]
        public string Iv { get; set; } = string.Empty;

        [BsonElement("createdAt")]
        [JsonPropertyName("createdAt")]
        public string CreatedAt { get; set; } = string.Empty;

        [BsonElement("isEdited")]
        [JsonPropertyName("isEdited")]
        public string IsEdited { get; set; } = string.Empty;

        [BsonElement("messageType")]
        [JsonPropertyName("messageType")]
        public string MessageType { get; set; } = string.Empty;

        [BsonElement("deletedFor")]
        [JsonPropertyName("deletedFor")]
        public string DeletedFor { get; set; } = string.Empty;

        // --- Ось тут головна зміна! ---
        [BsonElement("attachments")]
        [JsonPropertyName("attachments")]
        public string Attachments { get; set; } = string.Empty;

        [BsonElement("replyId")]
        [JsonPropertyName("replyId")]
        public string ReplyId { get; set; } = string.Empty;

        [BsonElement("isChecked")]
        [JsonPropertyName("isChecked")]
        public string IsChecked { get; set; } = string.Empty;
    }


    public class MessageAttachment
    {
        public string FileName { get; set; } = string.Empty;      // Зашифровано
        public string FileType { get; set; } = string.Empty;      // Зашифровано
        public string FileUrl { get; set; } = string.Empty;       // Зашифровано (посилання/шлях)
        public string ThumbnailUrl { get; set; } = string.Empty;  // Зашифровано (для preview)
        public string Size { get; set; } = string.Empty;          // Зашифровано (байти)
        // Можна додати hash, інше
    }
}
