﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SmartWarDrones.Server.Models
{
    public class Person
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("name")]
        public string Name { get; set; } = string.Empty;

        [BsonElement("passwordHash")]
        public string PasswordHash { get; set; } = string.Empty;

        [BsonElement("role")]
        public string Role { get; set; } = string.Empty;

        [BsonElement("identifier")]
        public string Identifier { get; set; } = string.Empty;

        [BsonElement("previousIdentifier")]
        public string PreviousIdentifier { get; set; } = string.Empty;

        [BsonElement("avatarUrl")]
        public string AvatarUrl { get; set; } = "";

        [BsonElement("bio")]
        public string Bio { get; set; } = "";

        [BsonElement("friends")]
        public List<string> Friends { get; set; } = [];

        [BsonElement("blockedUsers")]
        public List<string> BlockedUsers { get; set; } = [];

        [BsonElement("battlefields")]
        public List<string> Battlefields { get; set; } = new List<string>();


        [BsonElement("publicDhPrivate")]
        public string PublicDhPrivate { get; set; } = "";

        [BsonElement("privateDhPrivateEncrypted")]
        public string PrivateDhPrivateEncrypted { get; set; } = "";

        [BsonElement("publicDhGroup")]
        public string PublicDhGroup { get; set; } = "";

        [BsonElement("privateDhGroupEncrypted")]
        public string PrivateDhGroupEncrypted { get; set; } = "";

        [BsonElement("refreshTokenHash")]
        public string RefreshTokenHash { get; set; } = "";
    }
}
