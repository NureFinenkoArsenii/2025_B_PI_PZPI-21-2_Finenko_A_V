﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace SmartWarDronesServer.Models
{
    public class FriendRequest
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("senderId")]
        public string SenderId { get; set; } = null!;

        [BsonElement("receiverId")]
        public string ReceiverId { get; set; } = null!;
    }
}
