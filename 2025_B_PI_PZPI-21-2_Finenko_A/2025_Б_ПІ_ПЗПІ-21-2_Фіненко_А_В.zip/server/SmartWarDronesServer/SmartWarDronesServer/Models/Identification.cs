﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SmartWarDrones.Server.Models
{
    public class Identification
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        [BsonElement("messageOwnerId")]
        public string MessageOwnerId { get; set; } = string.Empty; // Зашифрований userId

        [BsonElement("messageId")]
        public string MessageId { get; set; } = string.Empty; // Зашифрований messageId
    }
}
