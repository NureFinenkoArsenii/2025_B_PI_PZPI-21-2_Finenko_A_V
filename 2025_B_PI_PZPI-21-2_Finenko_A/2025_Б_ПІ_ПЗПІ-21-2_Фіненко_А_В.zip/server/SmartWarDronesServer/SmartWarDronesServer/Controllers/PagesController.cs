﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Services;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/pages")]
    public class PagesController : ControllerBase
    {
        [HttpGet("home")]
        public IActionResult Home() => Ok("Welcome to SmartWarDrones!");

        [HttpGet("mobile")]
        public IActionResult Mobile() => Ok("Mobile app page (App Store / Play Market links)");

        [HttpGet("about")]
        public IActionResult About() => Ok("About the project and screenshots");

        [HttpGet("contact")]
        public IActionResult Contact() => Ok("Contact form / feedback email");


        [HttpGet("workplace")]
        [Authorize]
        public async Task<IActionResult> Workplace([FromServices] IMongoClient mongoClient, [FromServices] AvatarUrlCryptoService avatarUrlCryptoService)
        {
            var db = mongoClient.GetDatabase("SmartWarDrones");
            var users = db.GetCollection<Person>("persons");

            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var user = await users.Find(u => u.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return NotFound("User not found");

            // Дешифруємо шлях аватарки
            var avatarPath = string.IsNullOrEmpty(user.AvatarUrl)
                ? ""
                : avatarUrlCryptoService.Decrypt(user.AvatarUrl);

            string avatarType;
            string? avatarUrlForFrontend;

            if (avatarPath.StartsWith("/protected-avatars/"))
            {
                avatarType = "custom";
                avatarUrlForFrontend = null;
            }
            else
            {
                avatarType = "default";
                avatarUrlForFrontend = avatarPath;
            }

            return Ok(new
            {
                userId = user.Id,
                name = user.Name,
                role = user.Role,
                avatarType,
                avatarUrl = avatarUrlForFrontend
            });
        }


    }
}
