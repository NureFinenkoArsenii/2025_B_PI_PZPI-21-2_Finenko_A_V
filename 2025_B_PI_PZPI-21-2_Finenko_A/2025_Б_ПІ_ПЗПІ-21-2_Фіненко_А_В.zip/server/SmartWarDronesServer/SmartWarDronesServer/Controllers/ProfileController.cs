﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Models;
using SmartWarDronesServer.Services;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/profile")]
    public class ProfileController : ControllerBase
    {
        private readonly IMongoCollection<Person> _people;
        private readonly IdentifierService _identifierService;
        private readonly IdentifierCryptoService _crypto;
        private readonly AesService _aesService;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AvatarUrlCryptoService _avatarUrlCryptoService;

        public ProfileController(
            IMongoClient mongoClient,
            IConfiguration config,
            IdentifierService identifierService,
            IdentifierCryptoService crypto,
            AesService aesService,
            RsaKeyService rsaKeyService,
            AvatarUrlCryptoService avatarUrlCryptoService
        )
        {
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _people = db.GetCollection<Person>("persons");
            _identifierService = identifierService;
            _crypto = crypto;
            _aesService = aesService;
            _rsaKeyService = rsaKeyService;
            _avatarUrlCryptoService = avatarUrlCryptoService;
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetProfilePublicKey([FromServices] RsaKeyService rsaKeyService)
        {
            return Ok(rsaKeyService.GetPublicKey("profile"));
        }

        [Authorize]
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetProfile(string userId)
        {
            try
            {
                var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
                if (user == null)
                    return NotFound("User not found.");

                if (!Request.Headers.TryGetValue("X-Client-AES-Key", out var encryptedAesKeyBase64) ||
                    string.IsNullOrWhiteSpace(encryptedAesKeyBase64.ToString()))
                {
                    return BadRequest("Missing X-Client-AES-Key header.");
                }

                // Дешифрувати AES ключ
                var base64Key = encryptedAesKeyBase64.ToString()!;
                var aesKeyBytes = _rsaKeyService.Decrypt("profile", Convert.FromBase64String(base64Key));
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.GenerateIV();
                var iv = aes.IV;

                // Дешифрувати шлях
                var avatarPath = string.IsNullOrEmpty(user.AvatarUrl)
                    ? ""
                    : _avatarUrlCryptoService.Decrypt(user.AvatarUrl);

                string avatarType;
                string? avatarUrlForFrontend;

                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                var profile = new
                {
                    avatarType,
                    avatarUrl = avatarUrlForFrontend,
                    name = user.Name,
                    role = user.Role,
                    bio = string.IsNullOrEmpty(user.Bio)
                        ? ""
                        : new BioCryptoService(HttpContext.RequestServices.GetService<IConfiguration>()!).Decrypt(user.Bio),
                    identifier = _crypto.Decrypt(user.Identifier),
                    lastIdentifierUpdate = _identifierService.GetLastGlobalUpdateTime().ToUniversalTime()
                };

                var json = JsonSerializer.Serialize(profile);
                var plaintextBytes = Encoding.UTF8.GetBytes(json);

                using var encryptor = aes.CreateEncryptor(aes.Key, iv);
                var cipherBytes = encryptor.TransformFinalBlock(plaintextBytes, 0, plaintextBytes.Length);

                var responseObj = new
                {
                    Iv = Convert.ToBase64String(iv),
                    Ciphertext = Convert.ToBase64String(cipherBytes)
                };

                var responseJson = JsonSerializer.Serialize(responseObj);

                return Ok(responseJson);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to encrypt profile data: {ex.Message}");
                return StatusCode(500, "Encryption error.");
            }
        }

        [Authorize]
        [HttpGet("public-key/avatar-image")]
        public IActionResult GetAvatarImagePublicKey([FromServices] RsaKeyService rsaKeyService)
        {
            // Видаємо публічний RSA-ключ для шифрування запиту на отримання AES custom аватарки
            return Ok(rsaKeyService.GetPublicKey("avatar-image"));
        }

        // Запит: в тілі надсилається AES-ключ, зашифрований RSA ("avatar-image")
        // Повертає AES-ключ у base64 тільки для власника акаунта
        [Authorize]
        [HttpPost("get-avatar-image-key/{userId}")]
        public IActionResult GetAvatarImageKey(string userId, [FromBody] GetKeyRequest body)
        {
            if (string.IsNullOrWhiteSpace(body.EncryptedSessionAesKey))
                return BadRequest("Missing EncryptedSessionAesKey.");

            var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
            var base64Key = config["AesKeys:AvatarImage"];
            if (string.IsNullOrWhiteSpace(base64Key))
                return StatusCode(500, "Missing AvatarImage AES key.");

            // Дешифруємо AES ключ сесії клієнта
            byte[] sessionAesKey;
            try
            {
                sessionAesKey = _rsaKeyService.Decrypt("avatar-image", Convert.FromBase64String(body.EncryptedSessionAesKey));
            }
            catch
            {
                return BadRequest("Failed to decrypt client message.");
            }

            using var aes = Aes.Create();
            aes.Key = sessionAesKey;
            aes.GenerateIV();
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            var avatarAesKeyBytes = Convert.FromBase64String(base64Key);
            using var encryptor = aes.CreateEncryptor();
            var cipher = encryptor.TransformFinalBlock(avatarAesKeyBytes, 0, avatarAesKeyBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipher)
            });
        }


        public class GetKeyRequest
        {
            public string? EncryptedSessionAesKey { get; set; }
        }

        // Новий ендпоінт для отримання кастомної аватарки:
        [Authorize]
        [HttpGet("avatar-file/{userId}")]
        public async Task<IActionResult> GetCustomAvatarFile(string userId)
        {
            // Тут можна звірити userId == userId з токена, або дозволити тільки собі/друзям.
            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return NotFound("User not found.");

            var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
            var protectedDir = config["AvatarsStorage:ProtectedFolder"];
            if (string.IsNullOrWhiteSpace(protectedDir))
                return StatusCode(500, "Missing AvatarImages directory setting.");

            var avatarPath = string.IsNullOrEmpty(user.AvatarUrl) ? "" : _avatarUrlCryptoService.Decrypt(user.AvatarUrl);

            if (!avatarPath.StartsWith("/protected-avatars/"))
                return BadRequest("No custom avatar set.");

            var fileName = avatarPath.Split('/').Last();
            var filePath = Path.Combine(protectedDir, fileName);

            if (!System.IO.File.Exists(filePath))
                return NotFound("Avatar file not found.");

            var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);

            // Повертаємо IV+cipher як є (у base64, наприклад)
            return File(fileBytes, "application/octet-stream");
        }

        [Authorize]
        [HttpGet("public-key/change-password")]
        public IActionResult GetPasswordPublicKey([FromServices] RsaKeyService rsaKeyService)
            => Ok(rsaKeyService.GetPublicKey("change-password"));

        [Authorize]
        [HttpPost("change-password")]
        public async Task<IActionResult> ChangePassword(
            [FromBody] EncryptedMessage encrypted,
            [FromServices] PasswordService passwordService)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId)) return Unauthorized("Missing user ID");

            var result = await passwordService.ChangePasswordAsync(userId, encrypted);
            return result.Success ? Ok(result.Message) : BadRequest(result.Message);
        }

        [Authorize]
        [HttpGet("public-key/update-bio")]
        public IActionResult GetBioPublicKey([FromServices] RsaKeyService rsaKeyService)
            => Ok(rsaKeyService.GetPublicKey("update-bio"));

        [Authorize]
        [HttpPost("update-bio")]
        public async Task<IActionResult> UpdateBio(
            [FromBody] EncryptedMessage encrypted,
            [FromServices] AesService aesService,
            [FromServices] BioCryptoService bioCryptoService,
            [FromServices] RsaKeyService rsaKeyService)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized("Missing user ID");

            try
            {
                // Розшифровуємо AES ключ з RSA
                var aesKeyBytes = rsaKeyService.Decrypt("update-bio", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);

                // Розшифровуємо біо AES ключем з клієнта
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var decryptor = aes.CreateDecryptor();
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);
                var decryptedBio = await sr.ReadToEndAsync();

                if (string.IsNullOrWhiteSpace(decryptedBio))
                    return BadRequest("Missing or empty bio.");

                // Тепер шифруємо біо серверним фіксованим AES ключем (BioCryptoService)
                var encryptedBio = bioCryptoService.Encrypt(decryptedBio);

                // Логування
                Console.WriteLine("🔒 Encrypted Bio (to DB): " + encryptedBio);

                var update = Builders<Person>.Update.Set(p => p.Bio, encryptedBio);
                var result = await _people.UpdateOneAsync(p => p.Id == userId, update);

                if (result.MatchedCount == 0)
                    return NotFound("User not found.");

                return Ok("Bio updated and encrypted successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to update bio: {ex.Message}");
                return StatusCode(500, "Bio update failed.");
            }
        }

        private string GetUserIdFromToken()
        {
            return User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
                ?? throw new Exception("User ID not found in token.");
        }

        [Authorize]
        [HttpGet("public-key/upload-avatar")]
        public IActionResult GetAvatarPublicKey([FromServices] RsaKeyService rsaKeyService)
            => Ok(rsaKeyService.GetPublicKey("upload-avatar"));

        [Authorize]
        [HttpPost("upload-avatar-encrypted")]
        public async Task<IActionResult> UploadEncryptedAvatar([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserIdFromToken();
            if (string.IsNullOrEmpty(userId))
                return Unauthorized("Missing user ID");

            try
            {
                var json = _aesService.DecryptToJson(encrypted, "upload-avatar");
                var obj = JsonNode.Parse(json);
                var path = obj?["path"]?.ToString();

                if (string.IsNullOrWhiteSpace(path))
                    return BadRequest("Missing path");

                // Шифруємо шлях перед збереженням у БД!
                var encryptedPath = _avatarUrlCryptoService.Encrypt(path);

                var update = Builders<Person>.Update.Set(p => p.AvatarUrl, encryptedPath);
                var result = await _people.UpdateOneAsync(p => p.Id == userId, update);

                if (result.MatchedCount == 0)
                    return NotFound("User not found.");

                // Повертаємо НЕзашифрований шлях для фронту (йому буде простіше підставити прев'ю)
                return Ok(new { avatarUrl = path });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to save avatar path: {ex.Message}");
                return StatusCode(500, "Avatar path save failed.");
            }
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [Authorize]
        [HttpPost("upload-avatar-file")]
        public async Task<IActionResult> UploadAvatarFile([FromForm] IFormFile file)
        {
            var userId = GetUserIdFromToken();
            if (string.IsNullOrEmpty(userId))
                return Unauthorized("Missing user ID");

            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            try
            {
                // 1. Прочитати файл у байти
                byte[] imageBytes;
                using (var ms = new MemoryStream())
                {
                    await file.CopyToAsync(ms);
                    imageBytes = ms.ToArray();
                }

                // 2. Зашифрувати байти AES (ключ беремо з appsettings.json)
                var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
                var base64Key = config["AesKeys:AvatarImage"];
                if (string.IsNullOrWhiteSpace(base64Key))
                    return StatusCode(500, "Missing AvatarImage AES key.");
                var aesKey = Convert.FromBase64String(base64Key);

                using var aes = Aes.Create();
                aes.Key = aesKey;
                aes.GenerateIV();
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor();
                var encryptedImageBytes = encryptor.TransformFinalBlock(imageBytes, 0, imageBytes.Length);

                // 3. Зберегти у захищену папку (наприклад, /protected-avatars/userId_avatar.enc)
                var protectedDir = config["AvatarsStorage:ProtectedFolder"];
                if (string.IsNullOrWhiteSpace(protectedDir))
                    return StatusCode(500, "Missing AvatarImages directory setting.");

                if (!Directory.Exists(protectedDir))
                    Directory.CreateDirectory(protectedDir);

                var fileName = $"{userId}_avatar.enc";
                var filePath = Path.Combine(protectedDir, fileName);

                // Зберігаємо IV + encryptedBytes одним файлом
                var toSave = new byte[aes.IV.Length + encryptedImageBytes.Length];
                Buffer.BlockCopy(aes.IV, 0, toSave, 0, aes.IV.Length);
                Buffer.BlockCopy(encryptedImageBytes, 0, toSave, aes.IV.Length, encryptedImageBytes.Length);
                await System.IO.File.WriteAllBytesAsync(filePath, toSave);

                // 4. Шифруємо шлях до зображення
                var relativePath = $"/protected-avatars/{fileName}";
                var encryptedPath = _avatarUrlCryptoService.Encrypt(relativePath);

                // 5. Оновити шлях у користувача в БД
                var update = Builders<Person>.Update.Set(p => p.AvatarUrl, encryptedPath);
                var result = await _people.UpdateOneAsync(p => p.Id == userId, update);

                if (result.MatchedCount == 0)
                    return NotFound("User not found.");

                // Повертаємо НЕзашифрований шлях (для клієнта)
                return Ok(new { avatarUrl = relativePath });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to save avatar file: {ex.Message}");
                return StatusCode(500, "Avatar file upload failed.");
            }
        }

        [Authorize]
        [HttpPost("get-role")]
        public IActionResult GetUserRole([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userId))
                    return Unauthorized("Missing user ID");

                var user = _people.Find(p => p.Id == userId).FirstOrDefault();
                if (user == null)
                    return NotFound("User not found");

                var aesKeyBytes = _rsaKeyService.Decrypt("profile", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);

                var responseObj = new { role = user.Role };

                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                var plaintext = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(responseObj));
                using var encryptor = aes.CreateEncryptor();
                var cipher = encryptor.TransformFinalBlock(plaintext, 0, plaintext.Length);

                var response = new
                {
                    Iv = encrypted.Iv,
                    Ciphertext = Convert.ToBase64String(cipher)
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to get user role: {ex.Message}");
                return StatusCode(500, "Failed to get user role.");
            }
        }



    }
}
