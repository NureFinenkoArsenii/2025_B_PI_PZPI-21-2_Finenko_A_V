﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Services;
using System.Security.Claims;
using System.Text;
using System.Security.Cryptography;
using SmartWarDronesServer.Models;
using Microsoft.AspNetCore.SignalR;
using SmartWarDrones.Server.Hubs;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/messages")]
    public class MessagesController : ControllerBase
    {
        private readonly MessageService _messageService;
        private readonly AesUserIdService _userIdCrypto;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly IMongoCollection<Person> _people;
        private readonly DhKeyService _dhKeyService;
        private readonly AesMessageIdService _aesMessageIdService;
        private readonly IHubContext<FriendsHub> _friendsHub;

        public MessagesController(
            MessageService messageService,
            AesUserIdService userIdCrypto,
            RsaKeyService rsaKeyService,
            IMongoClient mongoClient,
            IConfiguration config,
            DhKeyService dhKeyService,
            AesService aesService,
            AesMessageIdService aesMessageIdService,
            IHubContext<FriendsHub> friendsHub)
        {
            _messageService = messageService;
            _userIdCrypto = userIdCrypto;
            _rsaKeyService = rsaKeyService;
            _people = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"])
                                 .GetCollection<Person>("persons");
            _dhKeyService = dhKeyService;
            _aesService = aesService;
            _aesMessageIdService = aesMessageIdService;
            _friendsHub = friendsHub;
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetMessagesPublicKey()
        {
            return Ok(_rsaKeyService.GetPublicKey("messages"));
        }

        [Authorize]
        [HttpPost("chat")]
        public async Task<IActionResult> Chat([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            // Дешифрувати friendId з ciphertext
            string json = _aesService.DecryptToJson(encrypted, "messages");
            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var friendId = node?["friendId"]?.ToString();

            if (string.IsNullOrWhiteSpace(friendId))
                return BadRequest("Missing friendId.");

            // Знайти себе й друга
            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            var friend = await _people.Find(p => p.Id == friendId).FirstOrDefaultAsync();
            if (user == null || friend == null)
                return NotFound("User not found.");

            // Calculate DH secret
            var secret = _dhKeyService.CalculateSharedSecret(user.PrivateDhPrivateEncrypted, friend.PublicDhPrivate);

            // Додаткова інфа
            var avatarPath = string.IsNullOrEmpty(friend.AvatarUrl)
                ? ""
                : new AvatarUrlCryptoService(HttpContext.RequestServices.GetService<IConfiguration>()!).Decrypt(friend.AvatarUrl);

            string avatarType;
            string? avatarUrlForFrontend;
            if (avatarPath.StartsWith("/protected-avatars/"))
            {
                avatarType = "custom";
                avatarUrlForFrontend = null;
            }
            else
            {
                avatarType = "default";
                avatarUrlForFrontend = avatarPath;
            }

            // Перевіряємо існування чату (в обидві сторони)
            var messageIds = await _messageService.GetPrivateChatMessageIdsAsync(userId, friendId);

            var messages = (messageIds.Count == 0)
                ? new List<PrivateMessage>()
                : await _messageService.GetMessagesByIdsAsync(messageIds);

            // --- Фільтрація повідомлень по DeletedFor ---
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            messages = messages
                .Where(msg => string.IsNullOrEmpty(msg.DeletedFor) || msg.DeletedFor != encryptedUserId)
                .ToList();

            var responseObj = new
            {
                friendId = friend.Id,
                friendName = friend.Name,
                friendAvatarType = avatarType,
                friendAvatarUrl = avatarUrlForFrontend,
                friendRole = friend.Role,
                secret = Convert.ToBase64String(secret),
                messages,
                status = (messages.Count == 0) ? "No messages yet in the chat" : null
            };

            // Шифруємо AES (ключ+IV з клієнта)
            using var aes = Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;
            var respJson = System.Text.Json.JsonSerializer.Serialize(responseObj);
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aes.CreateEncryptor();
            var cipher = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipher)
            });
        }

        [Authorize]
        [HttpPost("get-chats")]
        public async Task<IActionResult> GetChats([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            // Декодування ключа і IV
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch
            {
                return BadRequest("Invalid AES key or IV.");
            }

            // Дешифрування payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "messages");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var limit = node?["limit"]?.GetValue<int?>();

            // Шифруємо userId для пошуку
            string encryptedUserId;
            try
            {
                encryptedUserId = _userIdCrypto.Encrypt(userId);
            }
            catch
            {
                return BadRequest("UserId encryption error.");
            }

            // Mongo: знайти чати (де person1 або person2 == encryptedUserId)
            List<PrivateChat> chats;
            try
            {
                chats = await _messageService.GetPrivateChatsByUserAsync(encryptedUserId, limit ?? 50);

                foreach (var chat in chats.ToList())
                {
                    if (!string.IsNullOrEmpty(chat.DeletedFor) && chat.DeletedFor == encryptedUserId)
                        continue;

                    if (chat.PrivateMessagesIds == null || chat.PrivateMessagesIds.Count == 0)
                    {
                        await _messageService.DeleteChatByIdAsync(chat.Id);
                        chats.Remove(chat);
                        continue;
                    }

                    var realMessageIds = chat.PrivateMessagesIds.Select(id => _aesMessageIdService.Decrypt(id)).ToList();
                    var messages = await _messageService.GetMessagesByIdsAsync(realMessageIds);

                    if (messages.Count > 0 && messages.All(m => m.DeletedFor == encryptedUserId))
                    {
                        await _messageService.SetChatDeletedForAsync(chat.Id, encryptedUserId);
                        chat.DeletedFor = encryptedUserId;
                    }
                }

                chats = chats
                    .Where(chat => string.IsNullOrEmpty(chat.DeletedFor) || chat.DeletedFor != encryptedUserId)
                    .ToList();

            }
            catch
            {
                return StatusCode(500, "Mongo query error.");
            }

            if (chats.Count == 0)
            {
                var noChatsObj = new { chats = new List<object>(), status = "No chats yet" };
                var respJson = System.Text.Json.JsonSerializer.Serialize(noChatsObj);
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                var respBytes = Encoding.UTF8.GetBytes(respJson);
                using var encryptor = aes.CreateEncryptor();
                var cipher = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);
                return Ok(new
                {
                    iv = Convert.ToBase64String(aes.IV),
                    ciphertext = Convert.ToBase64String(cipher)
                });
            }

            // 1. Знайти friendIds (encrypted)
            var friendEncryptedIds = chats
                .Select(chat => chat.Person1 == encryptedUserId ? chat.Person2 : chat.Person1)
                .Distinct()
                .ToList();

            // 2. Завантажити всіх можливих Person (users)
            var allPeople = await _people.Find(_ => true).ToListAsync();

            var encryptedIdToPerson = new Dictionary<string, Person>();
            foreach (var person in allPeople)
            {
                var encId = _userIdCrypto.Encrypt(person.Id);
                if (friendEncryptedIds.Contains(encId))
                    encryptedIdToPerson[encId] = person;
            }

            // 3. Зібрати info про чати (з unreadCount)
            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return StatusCode(500, "Current user not found");

            List<object> chatInfos = new();
            foreach (var chat in chats)
            {
                var friendEncId = chat.Person1 == encryptedUserId ? chat.Person2 : chat.Person1;
                if (!encryptedIdToPerson.ContainsKey(friendEncId))
                    continue;

                var friend = encryptedIdToPerson[friendEncId];

                // --- Аватарки та інше ---
                string avatarPath;
                try
                {
                    avatarPath = string.IsNullOrEmpty(friend.AvatarUrl)
                        ? ""
                        : new AvatarUrlCryptoService(HttpContext.RequestServices.GetService<IConfiguration>()!).Decrypt(friend.AvatarUrl);
                }
                catch
                {
                    avatarPath = "";
                }
                string avatarType;
                string? avatarUrlForFrontend;
                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                // --- Рахуємо unreadCount ---
                int unreadCount = 0;
                try
                {
                    // DH секрет для цього чату
                    var dhSecret = _dhKeyService.CalculateSharedSecret(user.PrivateDhPrivateEncrypted, friend.PublicDhPrivate);

                    var realMessageIds = chat.PrivateMessagesIds.Select(id => _aesMessageIdService.Decrypt(id)).ToList();
                    var messages = await _messageService.GetMessagesByIdsAsync(realMessageIds);

                    foreach (var msg in messages)
                    {
                        // Перевіряємо DeletedFor
                        if (!string.IsNullOrEmpty(msg.DeletedFor) && msg.DeletedFor == encryptedUserId)
                            continue;

                        string senderIdPlain, isCheckedPlain;
                        try
                        {
                            senderIdPlain = AesDecrypt(msg.SenderId, dhSecret, Convert.FromBase64String(msg.Iv));
                            isCheckedPlain = AesDecrypt(msg.IsChecked ?? "", dhSecret, Convert.FromBase64String(msg.Iv));
                        }
                        catch
                        {
                            continue; // якщо помилка — пропускаємо це повідомлення
                        }
                        if (senderIdPlain != userId && isCheckedPlain == "false")
                        {
                            unreadCount++;
                        }
                    }
                }
                catch
                {
                    unreadCount = 0;
                }

                chatInfos.Add(new
                {
                    id = friend.Id,
                    name = friend.Name,
                    avatarType,
                    avatarUrl = avatarUrlForFrontend,
                    role = friend.Role,
                    unreadCount
                });
            }

            // --- Повертаємо ---
            var respObj = new { chats = chatInfos };
            var respJsonFinal = System.Text.Json.JsonSerializer.Serialize(respObj);
            using var aesResp = Aes.Create();
            aesResp.Key = aesKeyBytes;
            aesResp.IV = ivBytes;
            var respBytesFinal = Encoding.UTF8.GetBytes(respJsonFinal);
            using var encryptorResp = aesResp.CreateEncryptor();
            var cipherFinal = encryptorResp.TransformFinalBlock(respBytesFinal, 0, respBytesFinal.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aesResp.IV),
                ciphertext = Convert.ToBase64String(cipherFinal)
            });
        }

        // AES дешифрація (CBC, PKCS7)
        private string AesDecrypt(string base64, byte[] key, byte[] iv)
        {
            var bytes = Convert.FromBase64String(base64);
            using var aes = Aes.Create();
            aes.Key = key;
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using var decryptor = aes.CreateDecryptor();
            var plainBytes = decryptor.TransformFinalBlock(bytes, 0, bytes.Length);
            return Encoding.UTF8.GetString(plainBytes);
        }


        [Authorize]
        [HttpPost("delete-chat")]
        public async Task<IActionResult> DeleteChat([FromBody] DeleteChatRequest req)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(req.FriendId);

            var chat = await _messageService.GetPrivateChatBetweenAsync(encryptedUserId, encryptedFriendId);

            if (chat == null)
                return NotFound("Chat not found.");

            var encryptedMessageIds = chat.PrivateMessagesIds;
            var realMessageIds = encryptedMessageIds.Select(id => _aesMessageIdService.Decrypt(id)).ToList();

            if (req.DeleteForBoth)
            {
                await _messageService.DeleteChatByIdAsync(chat.Id);
                await _messageService.DeleteMessagesByIdsAsync(realMessageIds);
                foreach (var msgId in realMessageIds)
                    await _messageService.RemoveMessageIdFromChatsAsync(msgId);

                // === SignalR: обом ===
                await _friendsHub.Clients.Group(req.FriendId).SendAsync("ChatDeleted", new
                {
                    chatId = req.FriendId
                });
                await _friendsHub.Clients.Group(userId).SendAsync("ChatDeleted", new
                {
                    chatId = req.FriendId
                });

                return Ok(new { deleted = true });
            }
            else
            {
                if (chat.DeletedFor == encryptedFriendId)
                {
                    await _messageService.DeleteChatByIdAsync(chat.Id);
                    await _messageService.DeleteMessagesByIdsAsync(realMessageIds);
                    foreach (var msgId in realMessageIds)
                        await _messageService.RemoveMessageIdFromChatsAsync(msgId);

                    // === SignalR: обом ===
                    await _friendsHub.Clients.Group(req.FriendId).SendAsync("ChatDeleted", new
                    {
                        chatId = req.FriendId
                    });
                    await _friendsHub.Clients.Group(userId).SendAsync("ChatDeleted", new
                    {
                        chatId = req.FriendId
                    });

                    return Ok(new { deleted = true });
                }
                else
                {
                    await _messageService.SetChatDeletedForAsync(chat.Id, encryptedUserId);

                    var messages = await _messageService.GetMessagesByIdsAsync(realMessageIds);
                    foreach (var msg in messages)
                    {
                        if (msg.DeletedFor == encryptedFriendId)
                        {
                            await _messageService.DeleteMessagesByIdsAsync(new List<string> { msg.Id });
                            await _messageService.RemoveMessageIdFromChatsAsync(msg.Id);
                        }
                        else
                        {
                            await _messageService.SetMessagesDeletedForAsync(new List<string> { msg.Id }, encryptedUserId);
                        }
                    }

                    // SignalR: лише для себе
                    await _friendsHub.Clients.Group(userId).SendAsync("ChatDeleted", new
                    {
                        chatId = req.FriendId
                    });

                    return Ok(new { deleted = false });
                }
            }
        }



        [Authorize]
        [HttpPost("delete-message")]
        public async Task<IActionResult> DeleteMessage([FromBody] DeleteSingleMessageRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.MessageId))
                return BadRequest("MessageId is required.");

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(req.FriendId);

            var message = await _messageService.GetMessageByIdAsync(req.MessageId);
            if (message == null)
                return NotFound("Message not found.");

            if (req.DeleteForBoth)
            {
                await _messageService.DeleteMessageByIdAsync(req.MessageId);
                await _messageService.RemoveMessageIdFromChatsAsync(req.MessageId);

                // === SignalR: обом учасникам ===
                await _friendsHub.Clients.Group(req.FriendId).SendAsync("MessageDeleted", new
                {
                    messageId = req.MessageId,
                    chatId = req.FriendId
                });
                await _friendsHub.Clients.Group(userId).SendAsync("MessageDeleted", new
                {
                    messageId = req.MessageId,
                    chatId = req.FriendId
                });

                return Ok(new { deleted = true });
            }
            else
            {
                if (message.DeletedFor == encryptedFriendId)
                {
                    await _messageService.DeleteMessageByIdAsync(req.MessageId);
                    await _messageService.RemoveMessageIdFromChatsAsync(req.MessageId);

                    // === SignalR: обом учасникам ===
                    await _friendsHub.Clients.Group(req.FriendId).SendAsync("MessageDeleted", new
                    {
                        messageId = req.MessageId,
                        chatId = req.FriendId
                    });
                    await _friendsHub.Clients.Group(userId).SendAsync("MessageDeleted", new
                    {
                        messageId = req.MessageId,
                        chatId = req.FriendId
                    });

                    return Ok(new { deleted = true });
                }
                else
                {
                    await _messageService.SetMessageDeletedForAsync(req.MessageId, encryptedUserId);

                    // SignalR: лише для поточного користувача (оновлення локально)
                    await _friendsHub.Clients.Group(userId).SendAsync("MessageDeleted", new
                    {
                        messageId = req.MessageId,
                        chatId = req.FriendId
                    });

                    return Ok(new { deleted = false });
                }
            }
        }



        [Authorize]
        [HttpPost("send")]
        public async Task<IActionResult> SendMessage([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            // 1. Дешифрування сесійного AES ключа через RSA
            var aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            if (ivBytes.Length != 16)
            {
                return BadRequest("Invalid IV length for AES (must be 16 bytes).");
            }
            var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);

            using var aes = Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var decryptor = aes.CreateDecryptor();
            using var ms = new MemoryStream(cipherBytes);
            using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
            using var sr = new StreamReader(cs, Encoding.UTF8);

            var json = sr.ReadToEnd();

            // Витягуємо поля senderIdPlain, receiverIdPlain для чату
            var msgNode = System.Text.Json.Nodes.JsonNode.Parse(json);
            var senderIdPlain = msgNode?["senderIdPlain"]?.ToString();
            var receiverIdPlain = msgNode?["receiverIdPlain"]?.ToString();

            if (string.IsNullOrWhiteSpace(senderIdPlain) || string.IsNullOrWhiteSpace(receiverIdPlain))
            {
                return BadRequest("senderIdPlain or receiverIdPlain missing in payload.");
            }

            // Тепер десеріалізуємо сам об'єкт повідомлення (де senderId/receiverId — зашифровані DH секретом)
            var privateMessage = System.Text.Json.JsonSerializer.Deserialize<PrivateMessage>(json);

            if (privateMessage == null)
            {
                return BadRequest("Invalid message payload.");
            }

            // Додаємо повідомлення
            await _messageService.CreateMessageAsync(privateMessage);

            // Додаємо айді повідомлення у чат з ПРАВИЛЬНИМИ plain mongo id:
            await _messageService.AddMessageToPrivateChat(
                senderIdPlain,
                receiverIdPlain,
                privateMessage.Id
            );

            // Скидаємо DeletedFor для обох (і відправника, і отримувача)
            await _messageService.ResetChatDeletedForAsync(senderIdPlain, receiverIdPlain);

            // === SignalR ===
            // Для отримувача — про нове повідомлення:
            await _friendsHub.Clients.Group(receiverIdPlain).SendAsync("ReceivePrivateMessage", new
            {
                messageId = privateMessage.Id,
                chatId = senderIdPlain // чи receiverIdPlain, якщо чати формуються інакше
                                       // додаєш що треба
            });

            // Для відправника (оновлення UI, якщо потрібно)
            await _friendsHub.Clients.Group(senderIdPlain).SendAsync("MessageSent", new
            {
                messageId = privateMessage.Id,
                chatId = receiverIdPlain
            });

            return Ok();
        }


        [Authorize]
        [HttpPost("get-message-iv")]
        public async Task<IActionResult> GetMessageIv([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "messages");
            }
            catch
            {
                return BadRequest("Invalid encrypted payload.");
            }

            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var messageId = node?["messageId"]?.ToString();
            if (string.IsNullOrWhiteSpace(messageId))
                return BadRequest("messageId is required.");

            var message = await _messageService.GetMessageByIdAsync(messageId);
            if (message == null)
                return NotFound("Message not found.");

            // Просто повертаємо IV повідомлення як є (він вже в base64)
            var respObj = new { iv = message.Iv };

            // Шифруємо відповідь session AES як завжди
            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;
            var respJson = System.Text.Json.JsonSerializer.Serialize(respObj);
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aes.CreateEncryptor();
            var cipher = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipher)
            });
        }

        [Authorize]
        [HttpPost("edit-message")]
        public async Task<IActionResult> EditMessage([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "messages");
            }
            catch
            {
                return BadRequest("Invalid encrypted payload.");
            }

            var node = System.Text.Json.Nodes.JsonNode.Parse(json);

            var messageId = node?["messageId"]?.ToString();
            var newCiphertext = node?["newCiphertext"]?.ToString();
            var newIv = node?["newIv"]?.ToString();
            var newIsEdited = node?["newIsEdited"]?.ToString();

            if (string.IsNullOrWhiteSpace(messageId) ||
                string.IsNullOrWhiteSpace(newCiphertext) ||
                string.IsNullOrWhiteSpace(newIv) ||
                string.IsNullOrWhiteSpace(newIsEdited))
            {
                return BadRequest("Some required fields are missing.");
            }

            var message = await _messageService.GetMessageByIdAsync(messageId);
            if (message == null)
                return NotFound("Message not found.");

            await _messageService.EditMessageAsync(messageId, newCiphertext, newIv, newIsEdited);

            // === SignalR: повідомити співрозмовника
            await _friendsHub.Clients.Group(message.ReceiverId).SendAsync("MessageEdited", new
            {
                messageId,
                newCiphertext,
                newIv,
                newIsEdited
            });

            // (За бажанням) — можна дублювати й для себе:
            await _friendsHub.Clients.Group(userId).SendAsync("MessageEdited", new
            {
                messageId,
                newCiphertext,
                newIv,
                newIsEdited
            });

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("set-checked")]
        public async Task<IActionResult> SetMessageChecked([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "messages");
            }
            catch
            {
                return BadRequest("Invalid encrypted payload.");
            }

            var node = System.Text.Json.Nodes.JsonNode.Parse(json);

            var messageId = node?["messageId"]?.ToString();
            var newIsChecked = node?["newIsChecked"]?.ToString();

            if (string.IsNullOrWhiteSpace(messageId) || string.IsNullOrWhiteSpace(newIsChecked))
                return BadRequest("Some required fields are missing.");

            var message = await _messageService.GetMessageByIdAsync(messageId);
            if (message == null)
                return NotFound("Message not found.");

            // Оновлюємо статус
            await _messageService.SetMessageCheckedAsync(messageId, newIsChecked);

            // ======== Визначаємо справжні senderId та receiverId (дешифруємо) =========
            // 1. Знайдемо учасників чату (user, friend) через прив'язку до повідомлення
            // 2. Отримаємо секрет Diffie-Hellman для дешифрування
            // 3. Дешифруємо поля senderId, receiverId

            // --- Додаткові сервіси (отримай їх через DI або ServiceProvider):
            var dhKeyService = HttpContext.RequestServices.GetService<DhKeyService>();

            // Увага! Якщо твій message має SenderId/ReceiverId **зашифровані** (типово), їх треба розшифрувати:
            // Спочатку шукаємо всіх людей (якщо треба, зроби Find(p => true) але краще окремий find за id):
            var allPeople = await _people.Find(_ => true).ToListAsync();

            // Далі перебираємо всіх, щоб знайти хто з них відправник/отримувач у цьому повідомленні
            // (Можна оптимізувати, але для безпеки тут залишаємо)
            string? senderId = null;
            string? receiverId = null;

            foreach (var possibleSender in allPeople)
            {
                if (string.IsNullOrEmpty(possibleSender?.PrivateDhPrivateEncrypted))
                    continue;

                foreach (var possibleReceiver in allPeople)
                {
                    if (string.IsNullOrEmpty(possibleReceiver?.PublicDhPrivate))
                        continue;

                    try
                    {
                        // Ось тут .PrivateDhPrivateEncrypted та .PublicDhPrivate гарантовано НЕ null
                        var dhSecret = dhKeyService.CalculateSharedSecret(
                            possibleSender.PrivateDhPrivateEncrypted!, // <--- "!" тут каже компілятору "не null"
                            possibleReceiver.PublicDhPrivate!           // <--- і тут теж
                        );

                        var trySenderId = AesDecrypt(message.SenderId, dhSecret, Convert.FromBase64String(message.Iv));
                        var tryReceiverId = AesDecrypt(message.ReceiverId, dhSecret, Convert.FromBase64String(message.Iv));

                        if (allPeople.Any(p => p.Id == trySenderId) && allPeople.Any(p => p.Id == tryReceiverId))
                        {
                            senderId = trySenderId;
                            receiverId = tryReceiverId;
                            break;
                        }
                    }
                    catch { /* ignore and continue */ }
                }
                if (senderId != null && receiverId != null)
                    break;
            }

            if (string.IsNullOrEmpty(senderId) || string.IsNullOrEmpty(receiverId))
                return StatusCode(500, "Failed to decrypt sender/receiver id.");

            // --- SignalR: оновлюємо статус повідомлення для обох учасників ---
            await _friendsHub.Clients.Group(receiverId).SendAsync("MessageChecked", new
            {
                messageId,
                newIsChecked
            });
            await _friendsHub.Clients.Group(userId).SendAsync("MessageChecked", new
            {
                messageId,
                newIsChecked
            });

            // ======== Підрахунок та відправка unreadCount обом =========
            // Визначаємо friendId (з ким саме ти ведеш діалог)
            string friendId = senderId == userId ? receiverId : senderId;

            int unreadForCurrent = await _messageService.CountUnreadMessagesForChatAsync(userId, friendId);
            int unreadForFriend = await _messageService.CountUnreadMessagesForChatAsync(friendId, userId);

            await _friendsHub.Clients.Group(userId)
                .SendAsync("UnreadCountChanged", new { chatId = friendId, unreadCount = unreadForCurrent });
            await _friendsHub.Clients.Group(friendId)
                .SendAsync("UnreadCountChanged", new { chatId = userId, unreadCount = unreadForFriend });

            return Ok(new { success = true });
        }


        [Authorize]
        [HttpPost("upload-attachment")]
        public async Task<IActionResult> UploadAttachment()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            var form = await Request.ReadFormAsync();
            var file = form.Files["encryptedFile"];
            var thumbnail = form.Files["encryptedThumbnail"]; // Додаємо прев’ю
            var encryptedKey = form["encryptedKey"].ToString();
            var ivBase64 = form["iv"].ToString();
            var metaEnc = form["meta"].ToString();
            string fileName = "";
            string fileType = "";
            string size = "";

            // --- КРОК 1: Дешифрувати session AES ключ через приватний RSA ---
            if (string.IsNullOrEmpty(encryptedKey) || string.IsNullOrEmpty(ivBase64))
                return BadRequest("Missing keys.");

            byte[] sessionAesKey, ivBytes;
            try
            {
                sessionAesKey = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encryptedKey));
                ivBytes = Convert.FromBase64String(ivBase64);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[UploadAttachment] Key/IV decryption error: " + ex.Message);
                return BadRequest("Key/IV decryption error.");
            }

            // --- КРОК 2: Якщо metaEnc є — дешифрувати meta ---
            if (!string.IsNullOrEmpty(metaEnc))
            {
                try
                {
                    using var metaAesDec = Aes.Create();
                    metaAesDec.Key = sessionAesKey;
                    metaAesDec.IV = ivBytes;
                    metaAesDec.Mode = CipherMode.CBC;
                    metaAesDec.Padding = PaddingMode.PKCS7;
                    var metaBytesDec = Convert.FromBase64String(metaEnc);
                    using var decryptor = metaAesDec.CreateDecryptor();
                    var metaPlain = decryptor.TransformFinalBlock(metaBytesDec, 0, metaBytesDec.Length);
                    var metaStr = Encoding.UTF8.GetString(metaPlain);
                    var meta = System.Text.Json.JsonSerializer.Deserialize<MetaStruct>(metaStr);
                    if (meta == null)
                        return BadRequest("Invalid meta structure.");

                    fileName = meta.fileName;
                    fileType = meta.fileType;
                    size = meta.size;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[UploadAttachment] Meta decryption error: " + ex.Message);
                    return BadRequest("Meta decryption error.");
                }
            }

            // --- КРОК 3: Перевірка файлу ---
            if (file == null || file.Length == 0)
                return BadRequest("Missing file.");

            // --- КРОК 4: Дешифрувати файл session AES ---
            byte[] encryptedFileBytes;
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                encryptedFileBytes = ms.ToArray();
            }

            byte[] plainFileBytes;
            using (var aes = Aes.Create())
            {
                aes.Key = sessionAesKey;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                plainFileBytes = decryptor.TransformFinalBlock(encryptedFileBytes, 0, encryptedFileBytes.Length);
            }

            // 5. Зашифрувати файл AES ключем серверу (як раніше)
            var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
            var base64Key = config["AesKeys:AttachmentFile"];
            if (string.IsNullOrWhiteSpace(base64Key))
                return StatusCode(500, "Missing AttachmentFile AES key.");
            var aesKey = Convert.FromBase64String(base64Key);

            using var aesSrv = Aes.Create();
            aesSrv.Key = aesKey;
            aesSrv.GenerateIV();
            aesSrv.Mode = CipherMode.CBC;
            aesSrv.Padding = PaddingMode.PKCS7;
            using var encryptor = aesSrv.CreateEncryptor();
            var encryptedForStorage = encryptor.TransformFinalBlock(plainFileBytes, 0, plainFileBytes.Length);

            // 6. Зберегти у папку
            var protectedDir = config["AttachmentsStorage:ProtectedFolder"];
            if (string.IsNullOrWhiteSpace(protectedDir))
                return StatusCode(500, "Missing Attachments directory setting.");

            if (!Directory.Exists(protectedDir))
                Directory.CreateDirectory(protectedDir);

            var ext = Path.GetExtension(fileName) ?? "";
            var fileStorageName = $"{Guid.NewGuid():N}{ext}.enc";
            var filePath = Path.Combine(protectedDir, fileStorageName);

            var toSave = new byte[aesSrv.IV.Length + encryptedForStorage.Length];
            Buffer.BlockCopy(aesSrv.IV, 0, toSave, 0, aesSrv.IV.Length);
            Buffer.BlockCopy(encryptedForStorage, 0, toSave, aesSrv.IV.Length, encryptedForStorage.Length);
            await System.IO.File.WriteAllBytesAsync(filePath, toSave);

            // ========== НОВЕ: обробка прев’ю ==============
            var urlCrypto = HttpContext.RequestServices.GetService<AttachmentUrlCryptoService>()!;
            string thumbnailUrl = "";
            if (thumbnail != null && thumbnail.Length > 0)
            {
                // дешифрувати прев’ю аналогічно
                byte[] encryptedThumbBytes;
                using (var ms = new MemoryStream())
                {
                    await thumbnail.CopyToAsync(ms);
                    encryptedThumbBytes = ms.ToArray();
                }
                byte[] plainThumbBytes;
                using (var aesThumb = Aes.Create())
                {
                    aesThumb.Key = sessionAesKey;
                    aesThumb.IV = ivBytes;
                    aesThumb.Mode = CipherMode.CBC;
                    aesThumb.Padding = PaddingMode.PKCS7;
                    using var decryptor = aesThumb.CreateDecryptor();
                    plainThumbBytes = decryptor.TransformFinalBlock(encryptedThumbBytes, 0, encryptedThumbBytes.Length);
                }
                // Зашифрувати прев’ю для зберігання
                using var aesSrvThumb = Aes.Create();
                aesSrvThumb.Key = aesKey;
                aesSrvThumb.GenerateIV();
                aesSrvThumb.Mode = CipherMode.CBC;
                aesSrvThumb.Padding = PaddingMode.PKCS7;
                using var encryptorThumb = aesSrvThumb.CreateEncryptor();
                var encryptedThumbForStorage = encryptorThumb.TransformFinalBlock(plainThumbBytes, 0, plainThumbBytes.Length);

                var thumbFileName = $"{Guid.NewGuid():N}_thumb.jpg.enc";
                var thumbPath = Path.Combine(protectedDir, thumbFileName);

                var toSaveThumb = new byte[aesSrvThumb.IV.Length + encryptedThumbForStorage.Length];
                Buffer.BlockCopy(aesSrvThumb.IV, 0, toSaveThumb, 0, aesSrvThumb.IV.Length);
                Buffer.BlockCopy(encryptedThumbForStorage, 0, toSaveThumb, aesSrvThumb.IV.Length, encryptedThumbForStorage.Length);
                await System.IO.File.WriteAllBytesAsync(thumbPath, toSaveThumb);

                // Зашифрувати url
                var relativeThumbPath = $"/protected-attachments/{thumbFileName}";
                thumbnailUrl = urlCrypto.Encrypt(relativeThumbPath);
            }

            // --- КРОК 7: Зашифрувати шлях до файлу та метадані (urlCrypto = окремий AES з appsettings)
            var relativePath = $"/protected-attachments/{fileStorageName}";
            var encryptedPath = urlCrypto.Encrypt(relativePath);

            // --- КРОК 8: Метадані шифруємо session AES (або одразу серверним — на твій вибір)
            byte[] metaKey = sessionAesKey;
            using var metaAesEnc = Aes.Create();
            metaAesEnc.Key = metaKey;
            metaAesEnc.IV = ivBytes;
            metaAesEnc.Mode = CipherMode.CBC;
            metaAesEnc.Padding = PaddingMode.PKCS7;

            var metaObj = new
            {
                fileName,
                fileType,
                size,
                fileUrl = encryptedPath,
                thumbnailUrl = thumbnailUrl // тут тепер посилання на прев’ю!
            };
            var metaJson = System.Text.Json.JsonSerializer.Serialize(metaObj);
            var metaBytesEnc = Encoding.UTF8.GetBytes(metaJson);
            using var metaEncryptor = metaAesEnc.CreateEncryptor();
            var metaCipher = metaEncryptor.TransformFinalBlock(metaBytesEnc, 0, metaBytesEnc.Length);

            // --- КРОК 9: Повертаємо метадані клієнту
            return Ok(new
            {
                attachment = Convert.ToBase64String(metaCipher)
            });
        }

        [Authorize]
        [HttpGet("preview-attachment")]
        public async Task<IActionResult> GetAttachmentThumbnail([FromQuery] string file)
        {

            // 1. Декодуємо та дешифруємо url
            if (string.IsNullOrWhiteSpace(file))
            {
                return BadRequest("Missing file param");
            }


            var urlCrypto = HttpContext.RequestServices.GetService<AttachmentUrlCryptoService>()!;
            string relativePath;
            try
            {
                relativePath = urlCrypto.Decrypt(file);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[THUMB] ERROR: Invalid file param ({ex.Message})");
                return BadRequest("Invalid file param");
            }

            // 2. Перевіряємо, що це превʼю, а не довільний файл (додатковий захист)
            if (!relativePath.Contains("_thumb.") || !relativePath.EndsWith(".enc"))
            {
                return Forbid("Not a thumbnail");
            }

            var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
            var protectedDir = config["AttachmentsStorage:ProtectedFolder"];
            if (string.IsNullOrWhiteSpace(protectedDir))
            {
                return StatusCode(500, "Missing Attachments directory setting.");
            }

            var fileName = Path.GetFileName(relativePath);

            var filePath = Path.Combine(protectedDir, fileName);

            if (!System.IO.File.Exists(filePath))
            {
                return NotFound("Thumbnail not found");
            }

            // 3. Зчитуємо і дешифруємо файл
            var encrypted = await System.IO.File.ReadAllBytesAsync(filePath);
            if (encrypted.Length < 16)
            {
                return BadRequest("Corrupted file");
            }
            var iv = encrypted.Take(16).ToArray();
            var data = encrypted.Skip(16).ToArray();

            // Дістаємо AES-ключ з appsettings (той самий, що й для файлів)
            var base64Key = config["AesKeys:AttachmentFile"];
            if (string.IsNullOrWhiteSpace(base64Key))
            {
                return StatusCode(500, "Missing AttachmentFile AES key.");
            }
            var aesKey = Convert.FromBase64String(base64Key);

            byte[] plain;
            try
            {
                using (var aes = Aes.Create())
                {
                    aes.Key = aesKey;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using var decryptor = aes.CreateDecryptor();
                    plain = decryptor.TransformFinalBlock(data, 0, data.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[THUMB] ERROR: Не вдалося дешифрувати прев'ю: {ex.Message}");
                return StatusCode(500, "Failed to decrypt thumbnail");
            }

            // 4. Віддаємо файл із потрібним Content-Type (image/jpeg або image/png)
            return File(plain, "image/jpeg");
        }

        [Authorize]
        [HttpGet("download-attachment")]
        public async Task<IActionResult> DownloadAttachment([FromQuery] string file)
        {
            Console.WriteLine("=== [DL] Вхідний запит download-attachment ===");

            if (string.IsNullOrWhiteSpace(file))
            {
                Console.WriteLine("[DL] ERROR: Missing file param");
                return BadRequest("Missing file param");
            }

            Console.WriteLine($"[DL] Отриманий параметр file: {file}");

            var urlCrypto = HttpContext.RequestServices.GetService<AttachmentUrlCryptoService>()!;
            string relativePath;
            try
            {
                relativePath = urlCrypto.Decrypt(file);
                Console.WriteLine($"[DL] Дешифрований relativePath: {relativePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DL] ERROR: Invalid file param ({ex.Message})");
                return BadRequest("Invalid file param");
            }

            // Захист: лише файли з правильної папки і розширення .enc
            if (!relativePath.StartsWith("/protected-attachments/") || !relativePath.EndsWith(".enc"))
            {
                Console.WriteLine($"[DL] FORBID: Not a valid protected file [{relativePath}]");
                return Forbid("Not a valid attachment file");
            }

            var config = HttpContext.RequestServices.GetService<IConfiguration>()!;
            var protectedDir = config["AttachmentsStorage:ProtectedFolder"];
            if (string.IsNullOrWhiteSpace(protectedDir))
            {
                Console.WriteLine("[DL] ERROR: Missing Attachments directory setting.");
                return StatusCode(500, "Missing Attachments directory setting.");
            }

            var fileName = Path.GetFileName(relativePath);
            var filePath = Path.Combine(protectedDir, fileName);
            Console.WriteLine($"[DL] fileName: {fileName}");
            Console.WriteLine($"[DL] filePath: {filePath}");

            if (!System.IO.File.Exists(filePath))
            {
                Console.WriteLine($"[DL] ERROR: File not found at {filePath}");
                return NotFound("File not found");
            }

            // Читання meta
            var metaPath = Path.Combine(protectedDir, Path.GetFileNameWithoutExtension(fileName) + ".meta.json");
            string origFileName = "file.bin";
            string origFileType = "application/octet-stream";
            if (System.IO.File.Exists(metaPath))
            {
                try
                {
                    var metaJson = await System.IO.File.ReadAllTextAsync(metaPath);
                    var meta = System.Text.Json.JsonDocument.Parse(metaJson).RootElement;
                    origFileName = meta.GetProperty("fileName").GetString() ?? origFileName;
                    origFileType = meta.GetProperty("fileType").GetString() ?? origFileType;
                    Console.WriteLine($"[DL] Meta: origFileName={origFileName}, origFileType={origFileType}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[DL] Warning: Failed to parse meta file: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine($"[DL] Meta-файл не знайдено: {metaPath}");
            }

            // Зчитуємо і дешифруємо файл
            byte[] encrypted;
            try
            {
                encrypted = await System.IO.File.ReadAllBytesAsync(filePath);
                Console.WriteLine($"[DL] Прочитано {encrypted.Length} байт із файлу.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("[DL] ERROR: Не вдалося зчитати файл: " + ex.Message);
                return StatusCode(500, "Failed to read file");
            }

            if (encrypted.Length < 16)
            {
                Console.WriteLine("[DL] ERROR: Corrupted file (занадто короткий)");
                return BadRequest("Corrupted file");
            }
            var iv = encrypted.Take(16).ToArray();
            var data = encrypted.Skip(16).ToArray();

            var base64Key = config["AesKeys:AttachmentFile"];
            if (string.IsNullOrWhiteSpace(base64Key))
            {
                Console.WriteLine("[DL] ERROR: Missing AttachmentFile AES key.");
                return StatusCode(500, "Missing AttachmentFile AES key.");
            }
            byte[] aesKey;
            try
            {
                aesKey = Convert.FromBase64String(base64Key);
                Console.WriteLine("[DL] AES-ключ зчитано.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("[DL] ERROR: Неможливо декодувати AES ключ: " + ex.Message);
                return StatusCode(500, "Invalid AES key");
            }

            byte[] plain;
            try
            {
                using (var aes = Aes.Create())
                {
                    aes.Key = aesKey;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using var decryptor = aes.CreateDecryptor();
                    plain = decryptor.TransformFinalBlock(data, 0, data.Length);
                }
                Console.WriteLine($"[DL] Файл дешифровано, розмір plain: {plain.Length} байт");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DL] ERROR: Не вдалося дешифрувати файл: {ex.Message}");
                return StatusCode(500, "Failed to decrypt attachment");
            }

            // Видаємо файл із оригінальним ім'ям та типом
            Console.WriteLine($"[DL] Віддаємо файл {origFileName} ({origFileType}), розмір {plain.Length} байт");
            return File(plain, origFileType, origFileName);
        }

        [Authorize]
        [HttpPost("unread-count")]
        public async Task<IActionResult> GetUnreadChatsCount([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            // Декодування ключа і IV
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("messages", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch
            {
                return BadRequest("Invalid AES key or IV.");
            }

            // Дешифрування payload (по аналогії з іншими)
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "messages");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            // Отримуємо зашифрований userId для пошуку
            string encryptedUserId;
            try
            {
                encryptedUserId = _userIdCrypto.Encrypt(userId);
            }
            catch
            {
                return BadRequest("UserId encryption error.");
            }

            // Mongo: знайти всі чати (де person1 або person2 == encryptedUserId)
            List<PrivateChat> chats;
            try
            {
                chats = await _messageService.GetPrivateChatsByUserAsync(encryptedUserId, 1000);
                // Відкидаємо видалені
                chats = chats.Where(chat => string.IsNullOrEmpty(chat.DeletedFor) || chat.DeletedFor != encryptedUserId).ToList();
            }
            catch
            {
                return StatusCode(500, "Mongo query error.");
            }

            // Підгрузити всіх userів для дешифрування DH секрету
            var allPeople = await _people.Find(_ => true).ToListAsync();
            var user = allPeople.FirstOrDefault(p => p.Id == userId);
            if (user == null)
                return StatusCode(500, "Current user not found");

            int unreadChatsCount = 0;

            foreach (var chat in chats)
            {
                var friendEncId = chat.Person1 == encryptedUserId ? chat.Person2 : chat.Person1;
                var friend = allPeople.FirstOrDefault(p => _userIdCrypto.Encrypt(p.Id) == friendEncId);
                if (friend == null)
                    continue;

                // DH секрет для цього чату
                byte[] dhSecret;
                try
                {
                    dhSecret = _dhKeyService.CalculateSharedSecret(user.PrivateDhPrivateEncrypted, friend.PublicDhPrivate);
                }
                catch
                {
                    continue;
                }

                var realMessageIds = chat.PrivateMessagesIds.Select(id => _aesMessageIdService.Decrypt(id)).ToList();
                var messages = await _messageService.GetMessagesByIdsAsync(realMessageIds);

                bool hasUnread = false;
                foreach (var msg in messages)
                {
                    // Відкидаємо видалені для себе
                    if (!string.IsNullOrEmpty(msg.DeletedFor) && msg.DeletedFor == encryptedUserId)
                        continue;

                    string senderIdPlain, isCheckedPlain;
                    try
                    {
                        senderIdPlain = AesDecrypt(msg.SenderId, dhSecret, Convert.FromBase64String(msg.Iv));
                        isCheckedPlain = AesDecrypt(msg.IsChecked ?? "", dhSecret, Convert.FromBase64String(msg.Iv));
                    }
                    catch
                    {
                        continue;
                    }
                    // Непрочитане — якщо я не відправник і не прочитано
                    if (senderIdPlain != userId && isCheckedPlain == "false")
                    {
                        hasUnread = true;
                        break;
                    }
                }
                if (hasUnread)
                    unreadChatsCount++;
            }

            // Формуємо відповідь
            var respObj = new { count = unreadChatsCount };
            var respJson = System.Text.Json.JsonSerializer.Serialize(respObj);

            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aes.CreateEncryptor();
            var cipher = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipher)
            });
        }


        public class GetMessagesRequest
        {
            public string FriendId { get; set; } = string.Empty; // plaintext (id друга)
            public int? Limit { get; set; }
        }

        public class EditMessageRequest
        {
            public string MessageId { get; set; } = string.Empty;
            public string NewCiphertext { get; set; } = string.Empty;
            public string NewIv { get; set; } = string.Empty;
            public string NewIsEdited { get; set; } = string.Empty; // додати!
            public string NewLastEditTime { get; set; } = string.Empty;
        }

        public class DeleteMessageRequest
        {
            public string MessageId { get; set; } = string.Empty;
            public string NewEncryptedDeletedFor { get; set; } = string.Empty; // додати!
        }

        public class DeleteChatRequest
        {
            public string FriendId { get; set; } = string.Empty;
            public bool DeleteForBoth { get; set; }
        }

        public class DeleteSingleMessageRequest
        {
            public string MessageId { get; set; } = string.Empty;
            public string FriendId { get; set; } = string.Empty; // plaintext!
            public bool DeleteForBoth { get; set; }
        }

        public class MetaStruct
        {
            public string fileName { get; set; } = string.Empty;
            public string fileType { get; set; } = string.Empty;
            public string size { get; set; } = string.Empty;
        }


    }
}
