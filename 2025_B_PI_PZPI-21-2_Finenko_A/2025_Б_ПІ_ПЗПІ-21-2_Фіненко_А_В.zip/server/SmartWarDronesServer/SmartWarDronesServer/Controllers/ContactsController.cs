﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Models;
using System.Security.Claims;
using System.Text.Json;
using System.Text;
using System.Text.Json.Nodes;
using SmartWarDronesServer.Services;
using System.Reflection;
using Microsoft.AspNetCore.SignalR;
using SmartWarDrones.Server.Hubs;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/contacts")]
    public class ContactsController : ControllerBase
    {
        private readonly IMongoCollection<Person> _people;
        private readonly IMongoCollection<FriendRequest> _requests;
        private readonly AesService _aesService;
        private readonly RsaKeyService _rsaKeyService;
        private readonly IdentifierCryptoService _identifierCryptoService;
        private readonly AvatarUrlCryptoService _avatarUrlCryptoService;
        private readonly AesUserIdService _userIdCrypto;
        private readonly IConfiguration _config;
        private readonly IHubContext<FriendsHub> _friendsHub;

        public ContactsController(
            IMongoClient mongoClient,
            IConfiguration config,
            AesService aesService,
            RsaKeyService rsaKeyService,
            IdentifierCryptoService identifierCryptoService, // додати!
            AvatarUrlCryptoService avatarUrlCryptoService,
            AesUserIdService userIdCrypto,
            IHubContext<FriendsHub> friendsHub
        )
        {
            var db = mongoClient.GetDatabase(config["MongoDbSettings:DatabaseName"]);
            _people = db.GetCollection<Person>("persons");
            _requests = db.GetCollection<FriendRequest>("friend_requests");
            _aesService = aesService;
            _rsaKeyService = rsaKeyService;
            _identifierCryptoService = identifierCryptoService; // додати!
            _avatarUrlCryptoService = avatarUrlCryptoService;
            _userIdCrypto = userIdCrypto;
            _config = config;
            _friendsHub = friendsHub;
        }

        // Допоміжний метод для отримання userId з токену
        private string GetUserId()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");
        }

        /// <summary>
        /// Публічний RSA ключ для модального Contacts (client шифрує AES-ключ)
        /// </summary>
        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetContactsPublicKey() => Ok(_rsaKeyService.GetPublicKey("contacts"));

        [Authorize]
        [HttpPost("requests")]
        public async Task<IActionResult> GetRequests([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();

            // 1. Декодуємо AES ключ та IV
            var aesKeyBytes = _rsaKeyService.Decrypt("contacts", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            // 2. Зашифруємо userId для пошуку заявок
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            Console.WriteLine($"[FRIEND_REQUESTS] userId: {userId}, encryptedUserId: {encryptedUserId}");

            // 3. Дістаємо всі заявки, де receiverId = encryptedUserId
            var requests = await _requests.Find(r => r.ReceiverId == encryptedUserId).ToListAsync();
            Console.WriteLine($"[FRIEND_REQUESTS] Requests found: {requests.Count}");

            // 4. Розшифровуємо SenderId для пошуку профілів
            var senderIdsPlain = requests
                .Select(r =>
                {
                    try
                    {
                        var plain = _userIdCrypto.Decrypt(r.SenderId);
                        Console.WriteLine($"[FRIEND_REQUESTS] Decrypted SenderId: {plain} (Encrypted: {r.SenderId})");
                        return plain;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[FRIEND_REQUESTS][ERROR] Failed to decrypt SenderId {r.SenderId}: {ex}");
                        return null;
                    }
                })
                .Where(id => id != null)
                .ToList();

            // 5. Дістаємо профілі по plain SenderId
            var senders = await _people.Find(p => senderIdsPlain.Contains(p.Id)).ToListAsync();
            Console.WriteLine($"[FRIEND_REQUESTS] Sender profiles found: {senders.Count}");

            // 6. Формуємо відповідь із дешифрованими avatar та bio!
            var data = requests.Select(req =>
            {
                string? senderIdPlain = null;
                try { senderIdPlain = _userIdCrypto.Decrypt(req.SenderId); } catch { }

                var sender = senders.FirstOrDefault(s => s.Id == senderIdPlain);

                // Логи для дебагу
                Console.WriteLine($"[FRIEND_REQUESTS] SenderIdPlain: {senderIdPlain}, Name: {sender?.Name}");

                // Дешифруємо avatar
                string avatarPath = string.IsNullOrEmpty(sender?.AvatarUrl)
                    ? ""
                    : _avatarUrlCryptoService.Decrypt(sender.AvatarUrl);

                string avatarType;
                string? avatarUrlForFrontend;

                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                // Дешифруємо bio
                string decryptedBio = string.IsNullOrEmpty(sender?.Bio)
                    ? ""
                    : new BioCryptoService(_config).Decrypt(sender.Bio);

                string finalBio;
                try
                {
                    var bioObj = JsonNode.Parse(decryptedBio);
                    finalBio = bioObj?["bio"]?.ToString() ?? "";
                }
                catch
                {
                    finalBio = decryptedBio;
                }

                // Повторно зашифруємо SenderId для фронту (як у заявці)
                return new
                {
                    requestId = req.Id,
                    senderId = req.SenderId, // Уже зашифрований
                    senderIdPlain = senderIdPlain,
                    name = sender?.Name,
                    role = sender?.Role,
                    avatarType = avatarType,
                    avatarUrl = avatarUrlForFrontend,
                    bio = finalBio
                };
            }).ToList();

            // 7. Шифруємо відповідь AES ключем клієнта + IV з запиту
            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;

            var responseJson = JsonSerializer.Serialize(data);
            var responseBytes = Encoding.UTF8.GetBytes(responseJson);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(responseBytes, 0, responseBytes.Length);

            var responseObj = new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipherBytes)
            };

            Console.WriteLine($"[FRIEND_REQUESTS] Sending {data.Count} requests to client.");
            return Ok(responseObj);
        }

        [Authorize]
        [HttpPost("accept")]
        public async Task<IActionResult> AcceptRequest([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);

            var requestId = data?["requestId"]?.ToString();
            var senderIdEncrypted = data?["senderId"]?.ToString();

            if (string.IsNullOrWhiteSpace(requestId) || string.IsNullOrWhiteSpace(senderIdEncrypted))
                return BadRequest("Missing requestId or senderId.");

            var senderIdPlain = _userIdCrypto.Decrypt(senderIdEncrypted);

            if (userId == senderIdPlain)
                return BadRequest("You can't add yourself as a friend.");

            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedSenderId = senderIdEncrypted;

            var updateA = Builders<Person>.Update.AddToSet(p => p.Friends, encryptedSenderId);
            var updateB = Builders<Person>.Update.AddToSet(p => p.Friends, encryptedUserId);
            await _people.UpdateOneAsync(p => p.Id == userId, updateA);
            await _people.UpdateOneAsync(p => p.Id == senderIdPlain, updateB);

            await _requests.DeleteManyAsync(r =>
                (r.SenderId == senderIdEncrypted && r.ReceiverId == encryptedUserId) ||
                (r.SenderId == encryptedUserId && r.ReceiverId == senderIdEncrypted)
            );

            // --- SignalR: сповіщення обох користувачів про зміну
            await _friendsHub.Clients.Group(userId).SendAsync("FriendRequestUpdated");
            await _friendsHub.Clients.Group(senderIdPlain).SendAsync("FriendRequestUpdated");

            return Ok();
        }


        [Authorize]
        [HttpPost("reject")]
        public async Task<IActionResult> RejectRequest([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);
            var requestId = data?["requestId"]?.ToString();
            if (string.IsNullOrWhiteSpace(requestId))
                return BadRequest("Missing requestId.");

            // Витягуємо заявку для SignalR
            var req = await _requests.Find(r => r.Id == requestId).FirstOrDefaultAsync();
            string? senderIdPlain = req != null ? _userIdCrypto.Decrypt(req.SenderId) : null;

            await _requests.DeleteOneAsync(r => r.Id == requestId);

            // --- SignalR: сповіщення про зміну
            await _friendsHub.Clients.Group(userId).SendAsync("FriendRequestUpdated");
            if (!string.IsNullOrEmpty(senderIdPlain))
                await _friendsHub.Clients.Group(senderIdPlain).SendAsync("FriendRequestUpdated");

            return Ok();
        }

        [Authorize]
        [HttpPost("block")]
        public async Task<IActionResult> BlockUser([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);
            var blockId = data?["userId"]?.ToString();
            if (string.IsNullOrWhiteSpace(blockId))
                return BadRequest("Missing userId.");

            if (userId == blockId)
                return BadRequest("You can't block yourself.");

            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedBlockId = _userIdCrypto.Encrypt(blockId);

            // Видалення з друзів
            var updateA = Builders<Person>.Update.Pull(p => p.Friends, encryptedBlockId);
            var updateB = Builders<Person>.Update.Pull(p => p.Friends, encryptedUserId);

            await _people.UpdateOneAsync(p => p.Id == userId, updateA);
            await _people.UpdateOneAsync(p => p.Id == blockId, updateB);

            // Видалення всіх заявок у друзі
            await _requests.DeleteManyAsync(r =>
                (r.SenderId == encryptedUserId && r.ReceiverId == encryptedBlockId) ||
                (r.SenderId == encryptedBlockId && r.ReceiverId == encryptedUserId)
            );

            // --- Видалення всіх заявок у напрямки (battlefield_requests)
            var mongoClient = HttpContext.RequestServices.GetService<IMongoClient>();
            if (mongoClient == null)
                return StatusCode(500, "MongoClient service not available.");

            var db = mongoClient.GetDatabase(_config["MongoDbSettings:DatabaseName"]);
            var battlefieldRequestsColl = db.GetCollection<BattlefieldRequest>("battlefield_requests");
            await battlefieldRequestsColl.DeleteManyAsync(
                Builders<BattlefieldRequest>.Filter.Or(
                    Builders<BattlefieldRequest>.Filter.And(
                        Builders<BattlefieldRequest>.Filter.Eq(x => x.SenderId, encryptedUserId),
                        Builders<BattlefieldRequest>.Filter.Eq(x => x.ReceiverId, encryptedBlockId)
                    ),
                    Builders<BattlefieldRequest>.Filter.And(
                        Builders<BattlefieldRequest>.Filter.Eq(x => x.SenderId, encryptedBlockId),
                        Builders<BattlefieldRequest>.Filter.Eq(x => x.ReceiverId, encryptedUserId)
                    )
                )
            );

            // Додаємо в blocked (зашифрований айді)
            var blockUpdate = Builders<Person>.Update.AddToSet(p => p.BlockedUsers, encryptedBlockId);
            await _people.UpdateOneAsync(p => p.Id == userId, blockUpdate);

            // SignalR
            await _friendsHub.Clients.Group(userId).SendAsync("FriendRequestUpdated");
            await _friendsHub.Clients.Group(blockId).SendAsync("FriendRequestUpdated");

            return Ok();
        }




        [Authorize]
        [HttpPost("unblock")]
        public async Task<IActionResult> UnblockUser([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);

            var unblockId = data?["userId"]?.ToString();
            if (string.IsNullOrWhiteSpace(unblockId))
                return BadRequest("Missing userId.");

            // Ось тут важливо!
            var encryptedUnblockId = _userIdCrypto.Encrypt(unblockId);

            var update = Builders<Person>.Update.Pull(p => p.BlockedUsers, encryptedUnblockId);
            var result = await _people.UpdateOneAsync(p => p.Id == userId, update);

            return Ok();
        }


        // Список друзів
        [Authorize]
        [HttpPost("friends")]
        public async Task<IActionResult> GetFriends([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var aesKeyBytes = _rsaKeyService.Decrypt("contacts", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return NotFound("User not found.");

            // Розшифровуємо encrypted friends в plaintext
            var friendPlainIds = user.Friends
                .Select(fid =>
                {
                    try { return _userIdCrypto.Decrypt(fid); } catch { return null; }
                })
                .Where(fid => !string.IsNullOrEmpty(fid))
                .ToList();

            var friends = await _people.Find(p => friendPlainIds.Contains(p.Id)).ToListAsync();

            // Формуємо дані (з дешифруванням bio/avatar як і раніше)
            var data = friends.Select(f =>
            {
                string avatarPath = string.IsNullOrEmpty(f.AvatarUrl)
                    ? ""
                    : _avatarUrlCryptoService.Decrypt(f.AvatarUrl);

                string avatarType;
                string? avatarUrlForFrontend;
                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                string decryptedBio = string.IsNullOrEmpty(f.Bio)
                    ? ""
                    : new BioCryptoService(_config).Decrypt(f.Bio);

                string finalBio;
                try
                {
                    var bioObj = JsonNode.Parse(decryptedBio);
                    finalBio = bioObj?["bio"]?.ToString() ?? "";
                }
                catch
                {
                    finalBio = decryptedBio;
                }

                return new
                {
                    id = f.Id,
                    name = f.Name,
                    role = f.Role,
                    avatarType = avatarType,
                    avatarUrl = avatarUrlForFrontend,
                    bio = finalBio
                };
            }).ToList();


            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;

            var responseJson = JsonSerializer.Serialize(data);
            var responseBytes = Encoding.UTF8.GetBytes(responseJson);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(responseBytes, 0, responseBytes.Length);

            var responseObj = new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipherBytes)
            };

            return Ok(responseObj);
        }


        [Authorize]
        [HttpPost("blocked")]
        public async Task<IActionResult> GetBlocked([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var aesKeyBytes = _rsaKeyService.Decrypt("contacts", Convert.FromBase64String(encrypted.EncryptedKey));
            var ivBytes = Convert.FromBase64String(encrypted.Iv);

            var user = await _people.Find(p => p.Id == userId).FirstOrDefaultAsync();
            if (user == null)
                return NotFound("User not found.");

            var blockedPlainIds = user.BlockedUsers
                .Select(fid => {
                    try { return _userIdCrypto.Decrypt(fid); } catch { return null; }
                })
                .Where(fid => !string.IsNullOrEmpty(fid))
                .ToList();

            var blocked = await _people.Find(p => blockedPlainIds.Contains(p.Id)).ToListAsync();
            var data = blocked.Select(f =>
            {
                string avatarPath = string.IsNullOrEmpty(f.AvatarUrl)
                    ? ""
                    : _avatarUrlCryptoService.Decrypt(f.AvatarUrl);

                string avatarType;
                string? avatarUrlForFrontend;
                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                string decryptedBio = string.IsNullOrEmpty(f.Bio)
                    ? ""
                    : new BioCryptoService(_config).Decrypt(f.Bio);

                string finalBio;
                try
                {
                    var bioObj = JsonNode.Parse(decryptedBio);
                    finalBio = bioObj?["bio"]?.ToString() ?? "";
                }
                catch
                {
                    finalBio = decryptedBio;
                }

                return new
                {
                    id = f.Id,
                    name = f.Name,
                    role = f.Role,
                    avatarType = avatarType,
                    avatarUrl = avatarUrlForFrontend,
                    bio = finalBio
                };
            }).ToList();

            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = ivBytes;

            var responseJson = JsonSerializer.Serialize(data);
            var responseBytes = Encoding.UTF8.GetBytes(responseJson);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(responseBytes, 0, responseBytes.Length);

            var responseObj = new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipherBytes)
            };

            return Ok(responseObj);
        }


        [Authorize]
        [HttpPost("remove-friend")]
        public async Task<IActionResult> RemoveFriend([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);
            var friendId = data?["userId"]?.ToString();
            if (string.IsNullOrWhiteSpace(friendId))
                return BadRequest("Missing userId.");

            if (userId == friendId)
                return BadRequest("You can't remove yourself as a friend.");

            // Зашифрувати айді для видалення з Friends (бо зберігається encrypted)
            var encryptedUserId = _userIdCrypto.Encrypt(userId);
            var encryptedFriendId = _userIdCrypto.Encrypt(friendId);

            var updateA = Builders<Person>.Update.Pull(p => p.Friends, encryptedFriendId);
            var updateB = Builders<Person>.Update.Pull(p => p.Friends, encryptedUserId);

            await _people.UpdateOneAsync(p => p.Id == userId, updateA);
            await _people.UpdateOneAsync(p => p.Id == friendId, updateB);

            // (опціонально) SignalR сповіщення про оновлення
            await _friendsHub.Clients.Group(userId).SendAsync("FriendRequestUpdated");
            await _friendsHub.Clients.Group(friendId).SendAsync("FriendRequestUpdated");

            return Ok();
        }


        // Надіслати заявку в друзі (шукаємо по ідентифікаторах)
        [Authorize]
        [HttpPost("send")]
        public async Task<IActionResult> SendFriendRequest([FromBody] EncryptedMessage encrypted)
        {
            var senderIdPlain = GetUserId();

            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);
            var receiverIdPlain = data?["userId"]?.ToString();

            if (string.IsNullOrWhiteSpace(receiverIdPlain))
                return BadRequest("Missing userId.");

            if (receiverIdPlain == senderIdPlain)
                return BadRequest("You can't add yourself as a friend.");

            var receiverExists = await _people.Find(p => p.Id == receiverIdPlain).AnyAsync();
            if (!receiverExists)
                return NotFound("User not found.");

            var encryptedSender = _userIdCrypto.Encrypt(senderIdPlain);
            var encryptedReceiver = _userIdCrypto.Encrypt(receiverIdPlain);

            var existing = await _requests.Find(r =>
                r.SenderId == encryptedSender && r.ReceiverId == encryptedReceiver
            ).FirstOrDefaultAsync();

            if (existing != null)
                return BadRequest("Request already exists.");

            await _requests.InsertOneAsync(new FriendRequest
            {
                SenderId = encryptedSender,
                ReceiverId = encryptedReceiver
            });

            // --- SignalR: сповіщення користувача, якому відправили заявку
            await _friendsHub.Clients.Group(receiverIdPlain).SendAsync("FriendRequestUpdated");

            return Ok();
        }

        // Пошук користувача по ідентифікатору для попереднього прев’ю (Send Request)
        [Authorize]
        [HttpPost("find")]
        public async Task<IActionResult> FindUser([FromBody] EncryptedMessage encrypted)
        {
            var userId = GetUserId();
            var json = _aesService.DecryptToJson(encrypted, "contacts");
            var data = JsonNode.Parse(json);
            var identifier = data?["identifier"]?.ToString();
            if (string.IsNullOrWhiteSpace(identifier))
            {
                Console.WriteLine("[BACKEND] No identifier provided");
                return BadRequest("Missing identifier.");
            }

            var encryptedIdentifier = _identifierCryptoService.Encrypt(identifier);

            var allPeople = await _people.Find(_ => true).ToListAsync();
            foreach (var p in allPeople)
            {
                Console.WriteLine($"[BACKEND] DB Person: {p.Name}, Identifier: {p.Identifier}, Prev: {p.PreviousIdentifier}");
            }
            // Шукаємо по зашифрованому!
            var user = await _people.Find(p =>
                (p.Identifier == encryptedIdentifier || p.PreviousIdentifier == encryptedIdentifier)
            ).FirstOrDefaultAsync();

            bool youAreBlocked = false;
            if (user.BlockedUsers != null && user.BlockedUsers.Any())
            {
                var yourEncryptedId = _userIdCrypto.Encrypt(userId);
                youAreBlocked = user.BlockedUsers.Contains(yourEncryptedId);
            }

            if (user == null)
            {
                Console.WriteLine("[BACKEND] User not found by encrypted identifier");
                return NotFound("User not found.");
            }
            else
            {
                Console.WriteLine($"[BACKEND] Found user: {user.Name} (ID: {user.Id})");
            }

            // Зашифруємо відповідь AES ключем (із вхідного запиту!)
            var aesKeyBytes = _rsaKeyService.Decrypt("contacts", Convert.FromBase64String(encrypted.EncryptedKey));
            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = aesKeyBytes;
            aes.IV = Convert.FromBase64String(encrypted.Iv);

            var avatarPath = string.IsNullOrEmpty(user.AvatarUrl)
                ? ""
                : _avatarUrlCryptoService.Decrypt(user.AvatarUrl);

            string decryptedBio = string.IsNullOrEmpty(user.Bio)
                ? ""
                : new BioCryptoService(_config).Decrypt(user.Bio);

            string finalBio;
            try
            {
                var bioObj = JsonNode.Parse(decryptedBio);
                finalBio = bioObj?["bio"]?.ToString() ?? "";
            }
            catch
            {
                finalBio = decryptedBio;
            }

            string avatarType;
            string? avatarUrlForFrontend;

            if (avatarPath.StartsWith("/protected-avatars/"))
            {
                avatarType = "custom";
                avatarUrlForFrontend = null;
            }
            else
            {
                avatarType = "default";
                avatarUrlForFrontend = avatarPath;
            }

            var dataObj = new
            {
                id = user.Id,
                name = user.Name,
                role = user.Role,
                avatarType = avatarType,
                avatarUrl = avatarUrlForFrontend,
                bio = finalBio,
                youAreBlocked
            };
            var responseJson = JsonSerializer.Serialize(dataObj);
            var responseBytes = Encoding.UTF8.GetBytes(responseJson);
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(responseBytes, 0, responseBytes.Length);

            var responseObj = new
            {
                iv = Convert.ToBase64String(aes.IV),
                ciphertext = Convert.ToBase64String(cipherBytes)
            };

            return Ok(responseObj);
        }
    }
}
