﻿using Microsoft.AspNetCore.Mvc;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using MongoDB.Driver;
using System.Security.Claims;
using SmartWarDronesServer.Services;
using Microsoft.AspNetCore.Authorization;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using SmartWarDronesServer.Models.MapModels.BattlefieldModels;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/battlefields")]
    public class BattlefieldsController : ControllerBase
    {
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly AesBattlefieldsService _aesBattlefieldsService;
        private readonly AesBattlefieldIdService _aesBattlefieldIdService;
        private readonly AesBattlefieldPreviewFileService _aesBattlefieldPreviewFileService;
        private readonly IConfiguration _configuration;
        private readonly IMongoCollection<Battlefield> _battlefieldsCollection;
        private readonly IMongoCollection<GlobalChat> _globalChatsCollection;
        private readonly IMongoCollection<BattlefieldRequest> _battlefieldRequestsCollection;
        private readonly AesUserIdService _aesUserIdService;
        private readonly AesBattlefieldOwnerIdService _aesBattlefieldOwnerIdService;
        private readonly IMongoCollection<Person> _people;
        private readonly AvatarUrlCryptoService _avatarUrlCryptoService;
        private readonly AesDroneIdService _aesDroneIdService;
        private readonly IMongoCollection<Drone> _dronesCollection;


        public BattlefieldsController(
            IMongoClient mongoClient,
            IConfiguration configuration,
            RsaKeyService rsaKeyService,
            AesService aesService,
            AesBattlefieldsService aesBattlefieldsService,
            AesBattlefieldIdService aesBattlefieldIdService,
            AesBattlefieldPreviewFileService aesBattlefieldPreviewFileService,
            AesUserIdService aesUserIdService,
            AesDroneIdService aesDroneIdService,
            AesBattlefieldOwnerIdService aesBattlefieldOwnerIdService,
            AvatarUrlCryptoService avatarUrlCryptoService
        )
        {
            _configuration = configuration;
            var db = mongoClient.GetDatabase(configuration["MongoDbSettings:DatabaseName"]);

            _battlefieldsCollection = db.GetCollection<Battlefield>("battlefields");
            _globalChatsCollection = db.GetCollection<GlobalChat>("global_chats");
            _battlefieldRequestsCollection = db.GetCollection<BattlefieldRequest>("battlefield_requests");
            _people = db.GetCollection<Person>("persons");
            _dronesCollection = db.GetCollection<Drone>("drones");
            _rsaKeyService = rsaKeyService;
            _aesService = aesService;
            _aesBattlefieldsService = aesBattlefieldsService;
            _aesBattlefieldIdService = aesBattlefieldIdService;
            _aesBattlefieldPreviewFileService = aesBattlefieldPreviewFileService;
            _aesUserIdService = aesUserIdService;
            _aesBattlefieldOwnerIdService = aesBattlefieldOwnerIdService;
            _aesDroneIdService = aesDroneIdService;
            _avatarUrlCryptoService = avatarUrlCryptoService;
        }

        private string GetUserId()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetBattlefieldsPublicKey()
        {
            var publicKey = _rsaKeyService.GetPublicKey("battlefields");
            return Ok(publicKey);
        }

        [Authorize]
        [HttpPost("add")]
        [RequestSizeLimit(25 * 1024 * 1024)] // до 25MB
        public async Task<IActionResult> AddBattlefield()
        {
            var form = await Request.ReadFormAsync();
            var encryptedJson = form["encrypted"].FirstOrDefault();
            var file = form.Files["preview"];

            if (string.IsNullOrWhiteSpace(encryptedJson))
                return BadRequest("Encrypted payload missing.");

            EncryptedMessage? encrypted = null;
            try
            {
                encrypted = System.Text.Json.JsonSerializer.Deserialize<EncryptedMessage>(encryptedJson);
            }
            catch
            {
                return BadRequest("Cannot deserialize encrypted data.");
            }
            if (encrypted == null)
                return BadRequest("Cannot deserialize encrypted data.");

            if (string.IsNullOrWhiteSpace(encrypted.EncryptedKey) ||
                string.IsNullOrWhiteSpace(encrypted.Iv) ||
                string.IsNullOrWhiteSpace(encrypted.Ciphertext))
                return BadRequest("Invalid encrypted data fields.");

            byte[] aesKeyBytes, ivBytes, cipherBytes;
            try
            {
                aesKeyBytes = _aesService.DecryptAESKey(encrypted.EncryptedKey, "battlefields");
                ivBytes = Convert.FromBase64String(encrypted.Iv);
                cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
            }
            catch
            {
                return BadRequest("Failed to decode encrypted fields.");
            }

            string json;
            try
            {
                using (var aes = Aes.Create())
                {
                    aes.Key = aesKeyBytes;
                    aes.IV = ivBytes;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using var decryptor = aes.CreateDecryptor();
                    using var ms = new MemoryStream(cipherBytes);
                    using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                    using var sr = new StreamReader(cs, Encoding.UTF8);
                    json = sr.ReadToEnd();
                }
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            CreateBattlefieldDto? bfDto;
            try
            {
                bfDto = System.Text.Json.JsonSerializer.Deserialize<CreateBattlefieldDto>(json);
            }
            catch
            {
                return BadRequest("Cannot parse DTO");
            }
            if (bfDto == null)
                return BadRequest("Не вдалося розпарсити дані про напрямок");

            // --- 1. Отримуємо і шифруємо ID створювача (ownerId)
            string creatorUserId;
            try
            {
                creatorUserId = GetUserId();
            }
            catch
            {
                return Unauthorized("User ID not found in token.");
            }
            var encryptedOwnerId = _aesBattlefieldOwnerIdService.Encrypt(creatorUserId);

            // --- 2. dronesIds: шифруємо кожен id окремо
            var dronesIdsList = new List<string>();
            if (bfDto.DronesIds != null)
            {
                foreach (var droneId in bfDto.DronesIds)
                {
                    dronesIdsList.Add(_aesBattlefieldsService.Encrypt(droneId));
                }
            }

            // --- 3. Прев’ю
            string encryptedUrl;
            if (file != null && file.Length > 0)
            {
                byte[] fileBytes;
                using (var memory = new MemoryStream())
                {
                    await file.CopyToAsync(memory);
                    fileBytes = memory.ToArray();
                }

                byte[] previewPlain;
                try
                {
                    using (var aes = Aes.Create())
                    {
                        aes.Key = aesKeyBytes;
                        aes.IV = ivBytes;
                        aes.Mode = CipherMode.CBC;
                        aes.Padding = PaddingMode.PKCS7;
                        using var decryptor = aes.CreateDecryptor();
                        previewPlain = decryptor.TransformFinalBlock(fileBytes, 0, fileBytes.Length);
                    }
                }
                catch
                {
                    return BadRequest("Failed to decrypt preview file.");
                }

                var encryptedPreviewBytes = _aesBattlefieldPreviewFileService.Encrypt(previewPlain);
                var ext = Path.GetExtension(file.FileName);
                if (string.IsNullOrWhiteSpace(ext)) ext = ".png";
                var fileName = Guid.NewGuid().ToString() + ext;
                var storagePath = _configuration["BattlefieldPreviewStorage:ProtectedFolder"];
                if (string.IsNullOrWhiteSpace(storagePath))
                    return StatusCode(500, "BattlefieldPreviewStorage:ProtectedFolder is not set in appsettings.json");

                if (!Directory.Exists(storagePath))
                    Directory.CreateDirectory(storagePath);

                var fullPath = Path.Combine(storagePath, fileName);
                System.IO.File.WriteAllBytes(fullPath, encryptedPreviewBytes);
                var previewUrl = $"/{storagePath}/{fileName}".Replace("\\", "/");
                encryptedUrl = _aesBattlefieldsService.Encrypt(previewUrl);
            }
            else
            {
                string avatarUrl = bfDto.MapAvatarUrl ?? "";
                encryptedUrl = _aesBattlefieldsService.Encrypt(avatarUrl);
            }

            // --- 4. Зберігаємо напрямок (без MembersIds)
            var bf = new Battlefield
            {
                Name = _aesBattlefieldsService.Encrypt(bfDto.Name ?? string.Empty),
                About = _aesBattlefieldsService.Encrypt(bfDto.About ?? string.Empty),
                MapFocus = _aesBattlefieldsService.Encrypt(bfDto.MapFocus ?? string.Empty),
                MapSize = _aesBattlefieldsService.Encrypt(bfDto.MapSize ?? string.Empty),
                MapStyle = _aesBattlefieldsService.Encrypt(bfDto.MapStyle ?? string.Empty),
                MapAvatarUrl = encryptedUrl,
                DronesIds = dronesIdsList,
                OwnerId = encryptedOwnerId
            };

            _battlefieldsCollection.InsertOne(bf);

            // --- 5. Додаємо зашифрований id напрямку у Person.Battlefields ---
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(bf.Id);
            var personFilter = Builders<Person>.Filter.Eq(x => x.Id, creatorUserId);
            var update = Builders<Person>.Update.AddToSet(x => x.Battlefields, encryptedBattlefieldId);
            await _people.UpdateOneAsync(personFilter, update);

            // --- 6. Створюємо global chat (якщо треба)
            var encryptedIdForChat = _aesBattlefieldIdService.Encrypt(bf.Id);
            // Зчитуємо ключ для шифрування приватного DH ключа
            var dhAesKey = _configuration["DhEncryption:Key"]!;

            // Генеруємо пару DH-ключів для глобального чату
            var dhGroup = DiffieHellmanKeyPair.Generate(dhAesKey);

            var globalChat = new GlobalChat
            {
                BattlefieldId = encryptedIdForChat,
                GlobalMessagesIds = new List<string>(),
                ChatPublicDhGroup = dhGroup.PublicKey,
                ChatPrivateDhGroupEncrypted = dhGroup.EncryptedPrivateKey
            };
            _globalChatsCollection.InsertOne(globalChat);
            // --- 7. Повертаємо айді (як було) ---
            string encryptedId;
            using (var aes = Aes.Create())
            {
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                var plainBytes = Encoding.UTF8.GetBytes(bf.Id);
                using var encryptor = aes.CreateEncryptor();
                var cipherId = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                encryptedId = Convert.ToBase64String(cipherId);
            }

            return Ok(new { success = true, encryptedId });
        }



        [Authorize]
        [HttpPost("add-requests")]
        public IActionResult AddBattlefieldRequests([FromBody] EncryptedMessage encrypted)
        {
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;

            var battlefieldId = payload.GetProperty("battlefieldId").GetString() ?? "";
            var receivers = payload.GetProperty("receivers").EnumerateArray().Select(x => x.GetString()).Where(x => !string.IsNullOrEmpty(x)).ToList();

            if (string.IsNullOrEmpty(battlefieldId) || receivers.Count == 0)
                return BadRequest("Дані не валідні");

            var senderId = GetUserId();

            var encSenderId = _aesUserIdService.Encrypt(senderId);
            var encBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);

            var requests = receivers.Select(recId => new BattlefieldRequest
            {
                SenderId = encSenderId,
                ReceiverId = _aesUserIdService.Encrypt(recId!),
                BattlefieldId = encBattlefieldId
            }).ToList();

            _battlefieldRequestsCollection.InsertMany(requests);

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("my-battlefields")]
        public async Task<IActionResult> GetMyBattlefields([FromBody] EncryptedMessage encrypted)
        {
            // 1. Розшифруємо запит, перевірка і т.д. (для сумісності з клієнтом)
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            // payload не потрібен – айді з токену

            // 2. Отримати айді користувача
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Знайти користувача
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
            {
                // Захищена відповідь (зашифрувати строку через AES)
                var response = new { message = "No battlefields" };
                return Ok(_aesService.EncryptJson(response, encrypted, "battlefields"));
            }

            // 4. Дешифруємо кожен айді та знаходимо напрямок
            var battlefieldIds = person.Battlefields
                .Select(encId =>
                {
                    try { return _aesBattlefieldIdService.Decrypt(encId); }
                    catch { return null; }
                })
                .Where(id => !string.IsNullOrEmpty(id))
                .ToList();

            var battlefields = await _battlefieldsCollection
                .Find(b => battlefieldIds.Contains(b.Id))
                .ToListAsync();

            // 5. Повертаємо інфу про кожен напрямок (мінімум: name, about, preview...)
            var result = battlefields.Select(b => new
            {
                id = b.Id,
                name = _aesBattlefieldsService.Decrypt(b.Name),
                about = _aesBattlefieldsService.Decrypt(b.About),
                mapFocus = _aesBattlefieldsService.Decrypt(b.MapFocus),
                mapSize = _aesBattlefieldsService.Decrypt(b.MapSize),
                mapStyle = _aesBattlefieldsService.Decrypt(b.MapStyle),
                mapAvatarUrl = _aesBattlefieldsService.Decrypt(b.MapAvatarUrl),
                dronesIds = b.DronesIds,
                ownerId = b.OwnerId
                // Додавай потрібні тобі ще поля!
            });

            return Ok(_aesService.EncryptJson(result, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("join-requests")]
        public async Task<IActionResult> GetJoinRequests([FromBody] EncryptedMessage encrypted)
        {
            // 1. Розшифровуємо (просто AES session для авторизації)
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            // payload не потрібен

            // 2. Отримати айді користувача + зашифрувати його для порівняння
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }
            var encryptedUserId = _aesUserIdService.Encrypt(userId);

            // 3. Шукаємо заявки на користувача
            var filter = Builders<BattlefieldRequest>.Filter.Eq(x => x.ReceiverId, encryptedUserId);
            var requests = await _battlefieldRequestsCollection.Find(filter).ToListAsync();
            if (requests.Count == 0)
            {
                var response = new { message = "No requests to join in battlefields" };
                return Ok(_aesService.EncryptJson(response, encrypted, "battlefields"));
            }

            // 4. Для кожної заявки: інфа про того хто подав і про напрямок
            var results = new List<object>();
            foreach (var req in requests)
            {
                // senderId (encrypted) → шукаємо Person
                var senderPerson = await _people.Find(p => p.Id == null).FirstOrDefaultAsync(); // Fallback
                foreach (var person in await _people.Find(_ => true).ToListAsync())
                {
                    if (_aesUserIdService.Encrypt(person.Id) == req.SenderId)
                    {
                        senderPerson = person;
                        break;
                    }
                }
                // battlefieldId (encrypted) → шукаємо Battlefield
                var battlefieldId = "";
                try { battlefieldId = _aesBattlefieldIdService.Decrypt(req.BattlefieldId); } catch { }
                var battlefield = await _battlefieldsCollection.Find(b => b.Id == battlefieldId).FirstOrDefaultAsync();

                if (senderPerson != null && battlefield != null)
                {
                    results.Add(new
                    {
                        requestId = req.Id,
                        sender = new
                        {
                            id = senderPerson.Id,
                            name = senderPerson.Name,
                            avatarUrl = string.IsNullOrEmpty(senderPerson.AvatarUrl)
            ? null
            : _avatarUrlCryptoService.Decrypt(senderPerson.AvatarUrl),
                            avatarType = !string.IsNullOrEmpty(senderPerson.AvatarUrl)
            && _avatarUrlCryptoService.Decrypt(senderPerson.AvatarUrl).StartsWith("/protected-avatars/")
            ? "custom"
            : "default"
                        },
                        battlefield = new
                        {
                            id = battlefield.Id,
                            name = _aesBattlefieldsService.Decrypt(battlefield.Name)
                        }
                    });

                }
            }

            return Ok(_aesService.EncryptJson(results, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("preview-file")]
        public async Task<IActionResult> GetBattlefieldPreviewFile([FromBody] EncryptedMessage encrypted)
        {
            // 1. Розшифруємо запит (витягуємо id)
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrEmpty(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Знаходимо напрямок
            var battlefield = await _battlefieldsCollection.Find(b => b.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
                return NotFound("Battlefield not found");

            // 3. Декодуємо шлях до превью
            var encryptedUrl = battlefield.MapAvatarUrl;
            var previewPath = _aesBattlefieldsService.Decrypt(encryptedUrl);

            // 4. Перевіряємо, чи це дефолтне превью (шлях з /battlefieldPreview/defaultBattlefieldPreview.png)
            if (previewPath.Contains("defaultBattlefieldPreview.png"))
                return BadRequest("Default preview, no file to decrypt");

            // 5. Відкриваємо файл, розшифровуємо
            var fullPath = previewPath.TrimStart('/');
            if (!System.IO.File.Exists(fullPath))
                return NotFound("Preview file not found");

            var encryptedBytes = await System.IO.File.ReadAllBytesAsync(fullPath);
            var decrypted = _aesBattlefieldPreviewFileService.Decrypt(encryptedBytes);

            // 6. Повертаємо файл як image/png (або image/jpg, якщо потрібно)
            return File(decrypted, "image/png");
        }

        [Authorize]
        [HttpPost("is-owner")]
        public IActionResult IsOwner([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrEmpty(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Айді користувача з токену
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Знайти напрямок
            var bf = _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefault();
            if (bf == null)
                return NotFound("Battlefield not found");

            // 4. Дешифрувати OwnerId і порівняти
            var ownerId = _aesBattlefieldOwnerIdService.Decrypt(bf.OwnerId);
            var isOwner = (ownerId == userId);

            var response = new { isOwner };
            return Ok(_aesService.EncryptJson(response, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("delete")]
        public async Task<IActionResult> DeleteBattlefield([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrEmpty(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Айді користувача з токена
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Знаходимо напрямок
            var battlefield = await _battlefieldsCollection.Find(b => b.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
                return NotFound("Battlefield not found");

            // 4. Перевірка власника
            var ownerId = _aesBattlefieldOwnerIdService.Decrypt(battlefield.OwnerId);
            if (ownerId != userId)
                return Forbid("You are not the owner of this battlefield");

            // 5. Видаляємо Battlefield
            await _battlefieldsCollection.DeleteOneAsync(b => b.Id == battlefieldId);

            // 6. Видаляємо GlobalChat та повідомлення
            var encryptedBfId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            var globalChat = await _globalChatsCollection.Find(x => x.BattlefieldId == encryptedBfId).FirstOrDefaultAsync();

            if (globalChat is not null)
            {
                // 6a. Видаляємо всі globalMessages цього чату
                var ids = globalChat.GlobalMessagesIds;
                if (ids is not null && ids.Count > 0)
                {
                    var messagesColl = HttpContext.RequestServices.GetService<IMongoClient>()
                        .GetDatabase(_configuration["MongoDbSettings:DatabaseName"])
                        .GetCollection<GlobalMessage>("global_messages");
                    var idsFilter = Builders<GlobalMessage>.Filter.In(x => x.Id, ids);
                    await messagesColl.DeleteManyAsync(idsFilter);
                }

                // 6b. Видаляємо сам чат
                await _globalChatsCollection.DeleteOneAsync(x => x.Id == globalChat.Id);
            }

            // 7. Видаляємо айді цього battlefield з Person.Battlefields у всіх користувачів
            var usersFilter = Builders<Person>.Filter.AnyEq(x => x.Battlefields, encryptedBfId);
            var pullUpdate = Builders<Person>.Update.Pull(x => x.Battlefields, encryptedBfId);
            await _people.UpdateManyAsync(usersFilter, pullUpdate);

            // 8. Видаляємо всі BattlefieldRequest, де цей айді в полі battlefieldId
            var reqsFilter = Builders<BattlefieldRequest>.Filter.Eq(x => x.BattlefieldId, encryptedBfId);
            await _battlefieldRequestsCollection.DeleteManyAsync(reqsFilter);

            // 9. Видалити прев’ю з файлової системи (якщо не дефолтне)
            var mapAvatarUrl = _aesBattlefieldsService.Decrypt(battlefield.MapAvatarUrl ?? "");
            if (!string.IsNullOrEmpty(mapAvatarUrl) && !mapAvatarUrl.Contains("defaultBattlefieldPreview.png"))
            {
                var previewPath = mapAvatarUrl.TrimStart('/');
                if (System.IO.File.Exists(previewPath))
                {
                    try { System.IO.File.Delete(previewPath); }
                    catch { /* ігнорувати помилку */ }
                }
            }

            // 10. ОК
            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("accept-request")]
        public async Task<IActionResult> AcceptBattlefieldRequest([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();
            var requestId = payload.GetProperty("requestId").GetString();

            if (string.IsNullOrEmpty(battlefieldId) || string.IsNullOrEmpty(requestId))
                return BadRequest("battlefieldId or requestId is required");

            // 2. Айді користувача з токена
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Перевірка: чи справді це адресат заявки (receiverId)
            var encryptedUserId = _aesUserIdService.Encrypt(userId);
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);

            var request = await _battlefieldRequestsCollection
                .Find(x => x.Id == requestId && x.ReceiverId == encryptedUserId && x.BattlefieldId == encryptedBattlefieldId)
                .FirstOrDefaultAsync();

            if (request == null)
                return NotFound("Request not found or does not belong to you");

            // 4. Додаємо айді напрямку в Person.Battlefields
            var update = Builders<Person>.Update.AddToSet(x => x.Battlefields, encryptedBattlefieldId);
            var res = await _people.UpdateOneAsync(x => x.Id == userId, update);

            // 5. Видаляємо **усі** заявки для цього користувача і цього напрямку
            var filter = Builders<BattlefieldRequest>.Filter.And(
                Builders<BattlefieldRequest>.Filter.Eq(x => x.ReceiverId, encryptedUserId),
                Builders<BattlefieldRequest>.Filter.Eq(x => x.BattlefieldId, encryptedBattlefieldId)
            );
            await _battlefieldRequestsCollection.DeleteManyAsync(filter);

            return Ok(new { success = true });
        }


        [Authorize]
        [HttpPost("reject-request")]
        public async Task<IActionResult> RejectBattlefieldRequest([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var requestId = payload.GetProperty("requestId").GetString();

            if (string.IsNullOrEmpty(requestId))
                return BadRequest("requestId is required");

            // 2. Айді користувача з токена
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Знаходимо заявку
            var encryptedUserId = _aesUserIdService.Encrypt(userId);

            var request = await _battlefieldRequestsCollection
                .Find(x => x.Id == requestId && x.ReceiverId == encryptedUserId)
                .FirstOrDefaultAsync();

            if (request == null)
                return NotFound("Request not found or does not belong to you");

            // 4. Видаляємо заявку з бази
            await _battlefieldRequestsCollection.DeleteOneAsync(x => x.Id == requestId);

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("edit-battlefield")]
        [RequestSizeLimit(25 * 1024 * 1024)]
        public async Task<IActionResult> EditBattlefield()
        {
            // 1. Отримуємо userId із токена
            string userId;
            try
            {
                userId = GetUserId();
            }
            catch
            {
                return Unauthorized("User ID not found in token.");
            }

            // 2. Парсимо форму
            var form = await Request.ReadFormAsync();
            var encryptedJson = form["encrypted"].FirstOrDefault();
            var file = form.Files["preview"];

            Console.WriteLine("=== FORM RECEIVED ===");
            Console.WriteLine($"encryptedJson: {encryptedJson}");
            Console.WriteLine($"Has file: {file != null}");

            if (string.IsNullOrWhiteSpace(encryptedJson))
                return BadRequest("Encrypted payload missing.");

            EncryptedMessage? encrypted = null;
            try
            {
                encrypted = System.Text.Json.JsonSerializer.Deserialize<EncryptedMessage>(encryptedJson);
                Console.WriteLine("Deserialized EncryptedMessage:");
                Console.WriteLine($"EncryptedKey: {encrypted?.EncryptedKey}");
                Console.WriteLine($"Iv: {encrypted?.Iv}");
                Console.WriteLine($"Ciphertext: {encrypted?.Ciphertext}");
            }
            catch
            {
                Console.WriteLine("Cannot deserialize encrypted data");
                return BadRequest("Cannot deserialize encrypted data.");
            }
            if (encrypted == null)
            {
                Console.WriteLine("Encrypted is null after deserialization!");
                return BadRequest("Cannot deserialize encrypted data.");
            }



            // 3. Дешифруємо дані (AES+IV з RSA як завжди)
            byte[] aesKeyBytes, ivBytes, cipherBytes;
            try
            {
                Console.WriteLine("Trying to decode fields...");
                aesKeyBytes = _aesService.DecryptAESKey(encrypted.EncryptedKey, "battlefields");
                ivBytes = Convert.FromBase64String(encrypted.Iv);
                cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
                Console.WriteLine("Decryption params decoded OK.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to decode encrypted fields: {ex}");
                return BadRequest("Failed to decode encrypted fields.");
            }

            string json;
            try
            {
                using (var aes = Aes.Create())
                {
                    aes.Key = aesKeyBytes;
                    aes.IV = ivBytes;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using var decryptor = aes.CreateDecryptor();
                    using var ms = new MemoryStream(cipherBytes);
                    using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                    using var sr = new StreamReader(cs, Encoding.UTF8);
                    json = sr.ReadToEnd();
                }
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            EditBattlefieldDto? dto;
            try
            {
                dto = System.Text.Json.JsonSerializer.Deserialize<EditBattlefieldDto>(json);
                Console.WriteLine($"[EditBattlefield] Десеріалізовано: Name={dto?.Name}, About={dto?.About}, Id={dto?.BattlefieldId}");
            }
            catch
            {
                return BadRequest("Cannot parse DTO");
            }
            if (dto == null || string.IsNullOrWhiteSpace(dto.BattlefieldId))
                return BadRequest("Не вказаний ID напрямку");

            // 4. Знаходимо цей напрямок
            var battlefield = await _battlefieldsCollection.Find(b => b.Id == dto.BattlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
                return NotFound("Battlefield not found");

            // 5. Перевіряємо чи userId == ownerId
            var decryptedOwnerId = _aesBattlefieldOwnerIdService.Decrypt(battlefield.OwnerId);
            if (decryptedOwnerId != userId)
                return Forbid("You are not the owner of this battlefield");

            // 6. Будуємо update
            var update = Builders<Battlefield>.Update;
            var updates = new List<UpdateDefinition<Battlefield>>();

            // Перевіряємо, чи це повне оновлення (є map+preview або поле DronesIds)
            bool mapInfoChanged =
                dto.MapFocus != null || dto.MapSize != null || dto.MapStyle != null || dto.MapAvatarUrl != null || dto.DronesIds != null || file != null;

            if (mapInfoChanged)
            {
                // --- Повне оновлення
                if (!string.IsNullOrWhiteSpace(dto.Name))
                    updates.Add(update.Set(x => x.Name, _aesBattlefieldsService.Encrypt(dto.Name)));
                if (!string.IsNullOrWhiteSpace(dto.About))
                    updates.Add(update.Set(x => x.About, _aesBattlefieldsService.Encrypt(dto.About)));
                if (dto.MapFocus != null)
                    updates.Add(update.Set(x => x.MapFocus, _aesBattlefieldsService.Encrypt(dto.MapFocus)));
                if (dto.MapSize != null)
                    updates.Add(update.Set(x => x.MapSize, _aesBattlefieldsService.Encrypt(dto.MapSize)));
                if (dto.MapStyle != null)
                    updates.Add(update.Set(x => x.MapStyle, _aesBattlefieldsService.Encrypt(dto.MapStyle)));
                if (dto.DronesIds != null)
                    updates.Add(update.Set(x => x.DronesIds, dto.DronesIds.Select(id => _aesBattlefieldsService.Encrypt(id)).ToList()));

                // --- Оновлюємо превью
                if (file != null && file.Length > 0)
                {
                    byte[] fileBytes;
                    using (var memory = new MemoryStream())
                    {
                        await file.CopyToAsync(memory);
                        fileBytes = memory.ToArray();
                    }

                    byte[] previewPlain;
                    try
                    {
                        using (var aes = Aes.Create())
                        {
                            aes.Key = aesKeyBytes;
                            aes.IV = ivBytes;
                            aes.Mode = CipherMode.CBC;
                            aes.Padding = PaddingMode.PKCS7;
                            using var decryptor = aes.CreateDecryptor();
                            previewPlain = decryptor.TransformFinalBlock(fileBytes, 0, fileBytes.Length);
                        }
                    }
                    catch
                    {
                        return BadRequest("Failed to decrypt preview file.");
                    }

                    var encryptedPreviewBytes = _aesBattlefieldPreviewFileService.Encrypt(previewPlain);
                    var ext = Path.GetExtension(file.FileName);
                    if (string.IsNullOrWhiteSpace(ext)) ext = ".png";
                    var fileName = Guid.NewGuid().ToString() + ext;
                    var storagePath = _configuration["BattlefieldPreviewStorage:ProtectedFolder"];
                    if (string.IsNullOrWhiteSpace(storagePath))
                        return StatusCode(500, "BattlefieldPreviewStorage:ProtectedFolder is not set");

                    if (!Directory.Exists(storagePath))
                        Directory.CreateDirectory(storagePath);

                    var fullPath = Path.Combine(storagePath, fileName);
                    System.IO.File.WriteAllBytes(fullPath, encryptedPreviewBytes);
                    var previewUrl = $"/{storagePath}/{fileName}".Replace("\\", "/");
                    var encryptedUrl = _aesBattlefieldsService.Encrypt(previewUrl);
                    updates.Add(update.Set(x => x.MapAvatarUrl, encryptedUrl));

                    // Можеш ще видалити старий файл, якщо потрібно
                    var oldUrl = _aesBattlefieldsService.Decrypt(battlefield.MapAvatarUrl ?? "");
                    if (!string.IsNullOrEmpty(oldUrl) && !oldUrl.Contains("defaultBattlefieldPreview.png"))
                    {
                        var previewPath = oldUrl.TrimStart('/');
                        if (System.IO.File.Exists(previewPath))
                        {
                            try { System.IO.File.Delete(previewPath); } catch { }
                        }
                    }
                }
                else if (dto.MapAvatarUrl != null)
                {
                    // Якщо новий шлях (але без файлу), просто зашифруй і онови
                    updates.Add(update.Set(x => x.MapAvatarUrl, _aesBattlefieldsService.Encrypt(dto.MapAvatarUrl)));
                }
            }
            else
            {
                // --- Скорочене оновлення: тільки назва й опис
                if (!string.IsNullOrWhiteSpace(dto.Name))
                    updates.Add(update.Set(x => x.Name, _aesBattlefieldsService.Encrypt(dto.Name)));
                if (dto.About != null)
                    updates.Add(update.Set(x => x.About, _aesBattlefieldsService.Encrypt(dto.About)));
            }

            if (updates.Count == 0)
                return BadRequest("No fields to update");

            // 7. Оновлюємо
            var combined = update.Combine(updates);
            var res = await _battlefieldsCollection.UpdateOneAsync(b => b.Id == dto.BattlefieldId, combined);

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("get-by-id")]
        public async Task<IActionResult> GetBattlefieldById([FromBody] EncryptedMessage encrypted)
        {
            // 1. Розшифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrEmpty(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Отримуємо userId з токена
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Перевіряємо чи користувач є учасником цього напрямку
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
                return Forbid("You are not a member of this battlefield.");

            // Перевіряємо чи цей battlefieldId є у списку
            bool found = person.Battlefields.Any(encId =>
            {
                try { return _aesBattlefieldIdService.Decrypt(encId) == battlefieldId; }
                catch { return false; }
            });

            if (!found)
                return Forbid("You are not a member of this battlefield.");

            // 4. Отримуємо сам Battlefield з бази
            var bf = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (bf == null)
                return NotFound("Battlefield not found");

            var mapFocusString = _aesBattlefieldsService.Decrypt(bf.MapFocus);
            double[]? mapFocusArr = null;
            try
            {
                if (!string.IsNullOrEmpty(mapFocusString) && mapFocusString.Trim().StartsWith("[") && mapFocusString.Trim().EndsWith("]"))
                    mapFocusArr = System.Text.Json.JsonSerializer.Deserialize<double[]>(mapFocusString);
            }
            catch
            {
                // Ignore
            }
            if (mapFocusArr == null)
                mapFocusArr = new double[] { 48.3794, 31.1656 };

            // 5. Формуємо відповідь
            var response = new
            {
                id = bf.Id,
                name = _aesBattlefieldsService.Decrypt(bf.Name),
                about = _aesBattlefieldsService.Decrypt(bf.About),
                mapFocus = mapFocusArr,
                mapSize = _aesBattlefieldsService.Decrypt(bf.MapSize),
                mapStyle = _aesBattlefieldsService.Decrypt(bf.MapStyle),
                mapAvatarUrl = _aesBattlefieldsService.Decrypt(bf.MapAvatarUrl),
                dronesIds = bf.DronesIds, // (!) ще треба розшифрувати дрони, якщо потрібно!
                ownerId = bf.OwnerId
                // Можеш додати інші потрібні тобі поля
            };

            Console.WriteLine("--- [GetBattlefieldById] SERVER RESPONSE ---");
            Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(response));
            // 6. Зашифровуємо і повертаємо відповідь
            return Ok(_aesService.EncryptJson(response, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("members")]
        public async Task<IActionResult> GetBattlefieldMembers([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrEmpty(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Отримуємо userId з токена
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Перевіряємо чи користувач є учасником цього напрямку
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
                return Forbid("You are not a member of this battlefield.");

            // Перевіряємо чи цей battlefieldId є у списку
            bool found = person.Battlefields.Any(encId =>
            {
                try { return _aesBattlefieldIdService.Decrypt(encId) == battlefieldId; }
                catch { return false; }
            });

            if (!found)
                return Forbid("You are not a member of this battlefield.");

            // 4. Отримуємо ownerId
            var bf = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (bf == null)
                return NotFound("Battlefield not found");
            var ownerId = _aesBattlefieldOwnerIdService.Decrypt(bf.OwnerId);

            // 5. Шукаємо всіх користувачів, які мають цей battlefieldId в своїх Battlefields
            var encBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            var filter = Builders<Person>.Filter.AnyEq(x => x.Battlefields, encBattlefieldId);
            var members = await _people.Find(filter).ToListAsync();

            var result = members.Select(m => {
                var decryptedAvatar = string.IsNullOrEmpty(m.AvatarUrl) ? null : _avatarUrlCryptoService.Decrypt(m.AvatarUrl);
                var avatarType = (!string.IsNullOrEmpty(decryptedAvatar) && decryptedAvatar.StartsWith("/protected-avatars/"))
                    ? "custom"
                    : "default";
                return new
                {
                    id = m.Id,
                    name = m.Name,
                    role = m.Role, // Додаємо роль користувача!
                    avatarUrl = decryptedAvatar,
                    avatarType,
                    isOwner = (m.Id == ownerId)
                };
            });

            // 6. Повертаємо список (шифруємо як завжди)
            return Ok(_aesService.EncryptJson(result, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("does-join-request-exist")]
        public async Task<IActionResult> DoesJoinRequestExist([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            var json = _aesService.DecryptToJson(encrypted, "battlefields");
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;

            var receiverId = payload.GetProperty("receiverId").GetString();
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrWhiteSpace(receiverId) || string.IsNullOrWhiteSpace(battlefieldId))
                return BadRequest("receiverId and battlefieldId are required");

            // 2. Айді користувача, який відправляє (тобто, хто надсилає запрошення)
            string senderId;
            try { senderId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Шифруємо всі айді для порівняння з базою
            var encSenderId = _aesUserIdService.Encrypt(senderId);
            var encReceiverId = _aesUserIdService.Encrypt(receiverId);
            var encBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);

            // 4. Шукаємо заявку у колекції
            var filter = Builders<BattlefieldRequest>.Filter.And(
                Builders<BattlefieldRequest>.Filter.Eq(x => x.SenderId, encSenderId),
                Builders<BattlefieldRequest>.Filter.Eq(x => x.ReceiverId, encReceiverId),
                Builders<BattlefieldRequest>.Filter.Eq(x => x.BattlefieldId, encBattlefieldId)
            );
            var exists = await _battlefieldRequestsCollection.Find(filter).AnyAsync();

            // 5. Повертаємо відповідь (не забудь зашифрувати як завжди)
            var response = new { exists };
            return Ok(_aesService.EncryptJson(response, encrypted, "battlefields"));
        }

        [Authorize]
        [HttpPost("owner-kicks-member")]
        public async Task<IActionResult> OwnerKicksMember([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload (отримуємо айді напрямку та користувача)
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();
            var userIdToKick = payload.GetProperty("userId").GetString();

            if (string.IsNullOrWhiteSpace(battlefieldId) || string.IsNullOrWhiteSpace(userIdToKick))
                return BadRequest("battlefieldId and userId are required");

            // 2. Айді з токена (перевіряємо, чи це творець)
            string requesterId;
            try { requesterId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Шукаємо напрямок
            var battlefield = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
                return NotFound("Battlefield not found");

            // 4. Перевіряємо чи requesterId == ownerId
            var decryptedOwnerId = _aesBattlefieldOwnerIdService.Decrypt(battlefield.OwnerId);
            if (decryptedOwnerId != requesterId)
                return Forbid("You are not the owner of this battlefield");

            // 5. Видаляємо айді напрямку з масиву Battlefields користувача userIdToKick
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            var filter = Builders<Person>.Filter.Eq(x => x.Id, userIdToKick);
            var update = Builders<Person>.Update.Pull(x => x.Battlefields, encryptedBattlefieldId);

            var result = await _people.UpdateOneAsync(filter, update);

            if (result.MatchedCount == 0)
                return NotFound("User not found or is not a member");

            // (Опціонально: якщо треба видалити ще інші залишки — наприклад заявки, можеш це додати тут)

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("leaving-battlefield")]
        public async Task<IActionResult> LeaveBattlefield([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrWhiteSpace(battlefieldId))
                return BadRequest("battlefieldId required");

            // 2. Айді користувача з токену
            string userId;
            try { userId = GetUserId(); }
            catch { return Unauthorized("User ID not found in token."); }

            // 3. Знаходимо користувача
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null)
                return NotFound("User not found");

            // 4. Шукаємо зашифрований battlefieldId у person.Battlefields
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            if (person.Battlefields == null || !person.Battlefields.Contains(encryptedBattlefieldId))
                return BadRequest("You are not a member of this battlefield");

            // 5. Забороняємо власнику покидати (тільки через видалення!)
            var bf = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (bf != null)
            {
                var ownerId = _aesBattlefieldOwnerIdService.Decrypt(bf.OwnerId);
                if (ownerId == userId)
                    return Forbid("Owner cannot leave battlefield (only delete).");
            }

            // 6. Якщо оператор — видаляємо його дрони зі списку напрямку!
            if (person.Role == "operator" && bf != null && bf.DronesIds != null && bf.DronesIds.Count > 0)
            {
                var encryptedUserId = _aesUserIdService.Encrypt(userId);

                // 1. Знайти всі дрони цього оператора (OperatorId == encryptedUserId)
                var userDrones = await _dronesCollection
                    .Find(d => d.OperatorId == encryptedUserId)
                    .ToListAsync();

                // 2. Для кожного дрона — шифруємо його Id через AesDroneIdService
                var droneIdsToRemove = new List<string>();
                foreach (var drone in userDrones)
                {
                    var encryptedDroneId = _aesDroneIdService.Encrypt(drone.Id);

                    // Якщо цей дрон присутній у bf.DronesIds — видалити
                    if (bf.DronesIds.Contains(encryptedDroneId))
                        droneIdsToRemove.Add(encryptedDroneId);
                }

                if (droneIdsToRemove.Any())
                {
                    var update = Builders<Battlefield>.Update.PullAll(x => x.DronesIds, droneIdsToRemove);
                    await _battlefieldsCollection.UpdateOneAsync(
                        x => x.Id == battlefieldId,
                        update
                    );
                }
            }

            // 7. Видаляємо цей battlefield з поля Battlefields у користувача
            var filter = Builders<Person>.Filter.Eq(x => x.Id, userId);
            var updatePerson = Builders<Person>.Update.Pull(x => x.Battlefields, encryptedBattlefieldId);
            await _people.UpdateOneAsync(filter, updatePerson);

            // (Опціонально: видалити заявки, повідомлення, і т.д., якщо треба)

            return Ok(new { success = true });
        }



        [Authorize]
        [HttpPost("add-drones-to-battlefield")]
        public async Task<IActionResult> AddDronesToBattlefield([FromBody] EncryptedMessage encrypted)
        {
            Console.WriteLine("[BACKEND] === Отримано запит на додавання дронів до напрямку ===");
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
                Console.WriteLine("[BACKEND] Payload після дешифрування: " + json);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[BACKEND] Помилка дешифрування payload: " + ex.Message);
                return BadRequest("Failed to decrypt payload.");
            }

            string userId;
            try
            {
                userId = GetUserId();
                Console.WriteLine("[BACKEND] Айді користувача з токену: " + userId);
            }
            catch
            {
                Console.WriteLine("[BACKEND] Не знайдено UserId у токені!");
                return Unauthorized("User ID not found in token.");
            }

            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();
            var droneIdsArray = payload.GetProperty("droneIds").EnumerateArray()
                .Select(x => x.GetString()).Where(x => !string.IsNullOrEmpty(x)).ToList();

            Console.WriteLine("[BACKEND] BattlefieldId: " + battlefieldId);
            Console.WriteLine("[BACKEND] DroneIds: " + string.Join(", ", droneIdsArray));

            if (string.IsNullOrWhiteSpace(battlefieldId) || droneIdsArray.Count == 0)
            {
                Console.WriteLine("[BACKEND] Некоректний payload: battlefieldId або droneIds пусті!");
                return BadRequest("battlefieldId and at least one droneId required");
            }

            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
            {
                Console.WriteLine("[BACKEND] Користувач не є учасником жодного напрямку");
                return Forbid("You are not a member of this battlefield.");
            }

            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            bool isMember = person.Battlefields.Any(encId =>
            {
                try { return _aesBattlefieldIdService.Decrypt(encId) == battlefieldId; }
                catch { return false; }
            });
            Console.WriteLine("[BACKEND] Користувач є учасником цього напрямку: " + isMember);

            if (!isMember)
            {
                Console.WriteLine("[BACKEND] Користувач НЕ є учасником цього напрямку!");
                return Forbid("You are not a member of this battlefield.");
            }

            var encryptedDroneIds = droneIdsArray.Select(id => _aesDroneIdService.Encrypt(id!)).ToList();
            Console.WriteLine("[BACKEND] Зашифровані DroneIds: " + string.Join(", ", encryptedDroneIds));

            var battlefield = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
            {
                Console.WriteLine("[BACKEND] Battlefield не знайдено!");
                return NotFound("Battlefield not found");
            }

            var update = Builders<Battlefield>.Update.AddToSetEach(x => x.DronesIds, encryptedDroneIds);
            var updateResult = await _battlefieldsCollection.UpdateOneAsync(x => x.Id == battlefieldId, update);
            Console.WriteLine($"[BACKEND] Результат оновлення: ModifiedCount={updateResult.ModifiedCount}");

            return Ok(new { success = true });
        }

        [Authorize]
        [HttpPost("get-battlefield-drones")]
        public async Task<IActionResult> GetBattlefieldDrones([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо payload (отримуємо battlefieldId)
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }
            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();

            if (string.IsNullOrWhiteSpace(battlefieldId))
                return BadRequest("battlefieldId is required");

            // 2. Витягуємо userId з токена
            string userId;
            try
            {
                userId = GetUserId();
            }
            catch
            {
                return Unauthorized("User ID not found in token.");
            }

            // 3. Перевіряємо, чи user є учасником напрямку
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
                return Forbid("You are not a member of this battlefield.");

            bool isMember = person.Battlefields.Any(encId =>
            {
                try { return _aesBattlefieldIdService.Decrypt(encId) == battlefieldId; }
                catch { return false; }
            });
            if (!isMember)
                return Forbid("You are not a member of this battlefield.");

            // 4. Знаходимо напрямок
            var battlefield = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
                return NotFound("Battlefield not found");

            // 5. Дешифруємо всі droneIds
            var decryptedDroneIds = battlefield.DronesIds
                .Select(id => {
                    try { return _aesDroneIdService.Decrypt(id); }
                    catch { return null; }
                })
                .Where(id => !string.IsNullOrEmpty(id))
                .ToList();

            // 6. Дістаємо дрони з колекції
            var dronesCollection = HttpContext.RequestServices.GetService<IMongoClient>()
                .GetDatabase(_configuration["MongoDbSettings:DatabaseName"])
                .GetCollection<Drone>("drones");

            var filter = Builders<Drone>.Filter.In(d => d.Id, decryptedDroneIds);
            var drones = await dronesCollection.Find(filter).ToListAsync();

            // 7. Декодуємо всі поля дрона
            var aesDronesService = HttpContext.RequestServices.GetService<AesDronesService>();
            var result = drones.Select(d => new
            {
                d.Id,
                DroneName = aesDronesService.Decrypt(d.DroneName),
                DroneType = aesDronesService.Decrypt(d.DroneType),
                FrequencyBand = aesDronesService.Decrypt(d.FrequencyBand),
                AvatarUrl = aesDronesService.Decrypt(d.AvatarUrl),
                SafetyCode = aesDronesService.Decrypt(d.SafetyCode),
                OperatorId = _aesUserIdService.Decrypt(d.OperatorId)
            }).ToList();

            // 8. Декодуємо ownerId для creatorId
            // !! ВАЖЛИВО: Декодувати потрібно через _aesBattlefieldOwnerIdService.Decrypt, а не AesBattlefieldsService.Decrypt
            var decryptedOwnerId = _aesBattlefieldOwnerIdService.Decrypt(battlefield.OwnerId);

            // 9. Формуємо відповідь
            var responseObjRaw = new
            {
                drones = result,
                creatorId = decryptedOwnerId // тепер це вже нешифрований userId!
            };

            // 10. Зашифрувати відповідь тим же AES+IV
            var responseJson = System.Text.Json.JsonSerializer.Serialize(responseObjRaw);
            var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

            using var aes = System.Security.Cryptography.Aes.Create();
            aes.Key = _aesService.DecryptAESKey(encrypted.EncryptedKey, "battlefields");
            aes.IV = Convert.FromBase64String(encrypted.Iv);
            aes.Mode = System.Security.Cryptography.CipherMode.CBC;
            aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            var responseObj = new
            {
                iv = encrypted.Iv,
                ciphertext = Convert.ToBase64String(cipherBytes)
            };

            return Ok(responseObj);
        }



        [Authorize]
        [HttpPost("battlefield-drone-stats")]
        public async Task<IActionResult> GetBattlefieldDroneStats([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                // 1. Дешифруємо payload (отримуємо droneId)
                string json;
                try
                {
                    json = _aesService.DecryptToJson(encrypted, "battlefields");
                }
                catch
                {
                    return BadRequest("Failed to decrypt payload.");
                }
                var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
                var droneId = payload.GetProperty("droneId").GetString();

                if (string.IsNullOrWhiteSpace(droneId))
                    return BadRequest("droneId is required");

                // 2. Зашифровуємо droneId так само, як у StatsController
                var encryptedDroneId = _aesDroneIdService.Encrypt(droneId);

                // 3. Дістаємо статистику для цього дрона напряму з колекції
                var db = HttpContext.RequestServices.GetService<IMongoClient>()
                    .GetDatabase(_configuration["MongoDbSettings:DatabaseName"]);
                var statsCollection = db.GetCollection<Stats>("stats");

                var filter = Builders<Stats>.Filter.Eq(s => s.DroneId, encryptedDroneId);
                var statsList = await statsCollection.Find(filter).ToListAsync();

                if (statsList == null || statsList.Count == 0)
                    return NotFound(new { Error = "No stats found for this drone" });

                // 4. Формуємо відповідь (можеш додати ще поля, якщо треба)
                var response = statsList.Select(s => new
                {
                    StatsType = s.StatsType,
                    StatsInformation = s.StatsInformation,
                    LastUpdate = s.LastUpdate
                }).ToList();

                var responseJson = System.Text.Json.JsonSerializer.Serialize(response);
                var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

                // 5. Шифруємо відповідь так само, як і в інших запитах
                using var aes = System.Security.Cryptography.Aes.Create();
                aes.Key = _aesService.DecryptAESKey(encrypted.EncryptedKey, "battlefields");
                aes.IV = Convert.FromBase64String(encrypted.Iv);
                aes.Mode = System.Security.Cryptography.CipherMode.CBC;
                aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor();
                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var responseObj = new
                {
                    iv = encrypted.Iv,
                    ciphertext = Convert.ToBase64String(cipherBytes)
                };

                return Ok(responseObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ [battlefield-drone-stats] Failed: {ex}");
                return StatusCode(500, new { error = "Failed to fetch stats", details = ex.ToString() });
            }
        }

        [Authorize]
        [HttpPost("remove-drone-from-battlefield")]
        public async Task<IActionResult> RemoveDroneFromBattlefield([FromBody] EncryptedMessage encrypted)
        {
            Console.WriteLine("[BACKEND] === Запит на видалення дрона з напрямку ===");
            string json;
            try
            {
                json = _aesService.DecryptToJson(encrypted, "battlefields");
                Console.WriteLine("[BACKEND] Payload після дешифрування: " + json);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[BACKEND] Помилка дешифрування payload: " + ex.Message);
                return BadRequest("Failed to decrypt payload.");
            }

            string userId;
            try
            {
                userId = GetUserId();
            }
            catch
            {
                return Unauthorized("User ID not found in token.");
            }

            var payload = System.Text.Json.JsonDocument.Parse(json).RootElement;
            var battlefieldId = payload.GetProperty("battlefieldId").GetString();
            var droneId = payload.GetProperty("droneId").GetString();

            if (string.IsNullOrWhiteSpace(battlefieldId) || string.IsNullOrWhiteSpace(droneId))
                return BadRequest("battlefieldId and droneId are required");

            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null || person.Battlefields == null || person.Battlefields.Count == 0)
                return Forbid("You are not a member of this battlefield.");

            bool isMember = person.Battlefields.Any(encId =>
            {
                try { return _aesBattlefieldIdService.Decrypt(encId) == battlefieldId; }
                catch { return false; }
            });
            if (!isMember)
                return Forbid("You are not a member of this battlefield.");

            var encryptedDroneId = _aesDroneIdService.Encrypt(droneId);

            // Оновлюємо документ напрямку (видаляємо droneId з масиву)
            var update = Builders<Battlefield>.Update.Pull(x => x.DronesIds, encryptedDroneId);
            var battlefieldResult = await _battlefieldsCollection.UpdateOneAsync(
                x => x.Id == battlefieldId,
                update
            );

            Console.WriteLine($"[BACKEND] Видалення droneId з масиву напрямку. ModifiedCount={battlefieldResult.ModifiedCount}");


            return Ok(new { success = true });
        }




    }

    // DTO для створення Battlefield
    public class CreateBattlefieldDto
    {
        public string Name { get; set; } = "";
        public string About { get; set; } = "";
        public string MapFocus { get; set; } = "";
        public string MapSize { get; set; } = "";
        public string MapStyle { get; set; } = "";
        public string MapAvatarUrl { get; set; } = "";
        public List<string> MembersIds { get; set; } = new();
        public List<string> DronesIds { get; set; } = new();
    }

    public class EditBattlefieldDto
    {
        public string BattlefieldId { get; set; } = "";
        public string Name { get; set; } = "";
        public string About { get; set; } = "";
        public string? MapFocus { get; set; }
        public string? MapSize { get; set; }
        public string? MapStyle { get; set; }
        public string? MapAvatarUrl { get; set; }
        public List<string>? DronesIds { get; set; }
    }

    public class DoesJoinRequestExistDto
    {
        public string ReceiverId { get; set; } = string.Empty;
        public string BattlefieldId { get; set; } = string.Empty;
    }


}
