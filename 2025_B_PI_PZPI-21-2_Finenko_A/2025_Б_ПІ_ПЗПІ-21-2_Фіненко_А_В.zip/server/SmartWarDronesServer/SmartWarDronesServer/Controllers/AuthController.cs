﻿using Microsoft.AspNetCore.Mvc;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using System.Text.Json;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly AuthService _authService;
        private readonly JwtService _jwtService;

        public AuthController(RsaKeyService rsaKeyService, AesService aesService, AuthService authService, JwtService jwtService)
        {
            _rsaKeyService = rsaKeyService;
            _aesService = aesService;
            _authService = authService;
            _jwtService = jwtService;
        }

        [HttpGet("public-key/register")]
        public IActionResult GetRegisterPublicKey() => Ok(_rsaKeyService.GetPublicKey("register"));

        [HttpGet("public-key/login")]
        public IActionResult GetLoginPublicKey() => Ok(_rsaKeyService.GetPublicKey("login"));

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "register");
                var request = JsonSerializer.Deserialize<RegisterData>(json);
                if (request == null) return BadRequest("Invalid decrypted data.");

                var result = await _authService.RegisterAsync(request);
                return result.Success ? Ok(result.Message) : BadRequest(result.Message);
            }
            catch
            {
                return BadRequest("Decryption failed or invalid data.");
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "login");
                var creds = JsonSerializer.Deserialize<RegisterData>(json);
                if (creds == null) return BadRequest("Invalid decrypted credentials.");

                var (success, refreshToken, accessToken) = await _authService.LoginAsync(creds.Login, creds.Password, _jwtService);
                if (!success) return BadRequest("Invalid login or password");

                Response.Cookies.Append("refreshToken", refreshToken, new CookieOptions
                {
                    HttpOnly = true,
                    Secure = false,
                    SameSite = SameSiteMode.Lax,
                    Expires = DateTime.UtcNow.AddDays(7)
                });

                return Ok(accessToken);
            }
            catch
            {
                return BadRequest("Login error");
            }
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> Refresh()
        {
            if (!Request.Cookies.TryGetValue("refreshToken", out var refreshToken))
                return BadRequest("Missing refresh token");

            var (success, accessToken) = await _authService.RefreshAccessTokenAsync(refreshToken, _jwtService);
            return success ? Ok(accessToken) : Unauthorized("Invalid refresh token");
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            if (!Request.Cookies.TryGetValue("refreshToken", out var refreshToken))
                return BadRequest("No refresh token");

            var result = await _authService.RevokeRefreshTokenAsync(refreshToken);

            Response.Cookies.Append("refreshToken", "", new CookieOptions
            {
                Expires = DateTime.UtcNow.AddDays(-1),
                HttpOnly = true,
                Secure = false,
                SameSite = SameSiteMode.Lax
            });

            return result ? Ok("Logged out") : BadRequest("Token not found");
        }
    }
}
