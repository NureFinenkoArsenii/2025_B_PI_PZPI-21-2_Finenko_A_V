﻿using Microsoft.AspNetCore.Mvc;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;

namespace SmartWarDrones.Server.Controllers
{
    [ApiController]
    [Route("api/contact")]
    public class ContactController : ControllerBase
    {
        private readonly EmailService _emailService;
        private readonly AesService _aesService;
        private readonly RsaKeyService _rsaKeyService;

        public ContactController(EmailService emailService, AesService aesService, RsaKeyService rsaKeyService)
        {
            _emailService = emailService;
            _aesService = aesService;
            _rsaKeyService = rsaKeyService;
        }

        [HttpGet("public-key")]
        public IActionResult GetPublicKey()
        {
            var base64 = _rsaKeyService.GetPublicKey("email");
            return Ok(base64);
        }

        [HttpPost("send")]
        public async Task<IActionResult> Send([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "email");
                var email = System.Text.Json.JsonSerializer.Deserialize<EmailMessage>(json);

                if (email == null ||
                    string.IsNullOrWhiteSpace(email.Name) ||
                    string.IsNullOrWhiteSpace(email.Email) ||
                    string.IsNullOrWhiteSpace(email.Subject) ||
                    string.IsNullOrWhiteSpace(email.Message))
                {
                    return BadRequest("Invalid message content.");
                }

                var success = await _emailService.SendEmailAsync(
                    email.Name, email.Email, email.Subject, email.Message
                );

                return success ? Ok("Message sent.") : StatusCode(500, "Failed to send email.");
            }
            catch
            {
                return BadRequest("Decryption failed.");
            }
        }
    }
}
