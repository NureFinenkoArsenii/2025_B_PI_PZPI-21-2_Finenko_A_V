﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using MongoDB.Driver;
using SmartWarDrones.Server.Hubs;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Services;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace SmartWarDronesServer.Controllers
{
    [ApiController]
    [Route("api/global-chat")]
    public class GlobalChatController : ControllerBase
    {
        private readonly MessageService _messageService;
        private readonly AesUserIdService _userIdCrypto;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly IMongoCollection<Person> _people;
        private readonly DhKeyService _dhKeyService;
        private readonly AesMessageIdService _aesMessageIdService;
        private readonly IHubContext<FriendsHub> _friendsHub;
        private readonly AesBattlefieldsService _aesBattlefieldsService;
        private readonly AesBattlefieldIdService _aesBattlefieldIdService;
        private readonly AesBattlefieldPreviewFileService _aesBattlefieldPreviewFileService;
        private readonly IConfiguration _configuration;
        private readonly IMongoCollection<Battlefield> _battlefieldsCollection;
        private readonly IMongoCollection<GlobalChat> _globalChatsCollection;
        private readonly IMongoCollection<BattlefieldRequest> _battlefieldRequestsCollection;
        private readonly IMongoCollection<GlobalMessage> _globalMessagesCollection;
        private readonly IMongoCollection<Identification> _identificationsCollection;
        private readonly AesBattlefieldOwnerIdService _aesBattlefieldOwnerIdService;
        private readonly AvatarUrlCryptoService _avatarUrlCryptoService;
        private readonly GlobalChatDhKeyService _globalChatDhKeyService;

        public GlobalChatController(
            MessageService messageService,
            AesUserIdService userIdCrypto,
            RsaKeyService rsaKeyService,
            IMongoClient mongoClient,
            DhKeyService dhKeyService,
            AesService aesService,
            AesMessageIdService aesMessageIdService,
            IHubContext<FriendsHub> friendsHub,
            IConfiguration configuration,
            AesBattlefieldsService aesBattlefieldsService,
            AesBattlefieldIdService aesBattlefieldIdService,
            AesBattlefieldPreviewFileService aesBattlefieldPreviewFileService,
            AesBattlefieldOwnerIdService aesBattlefieldOwnerIdService,
            GlobalChatDhKeyService globalChatDhKeyService,
            AvatarUrlCryptoService avatarUrlCryptoService)
        {
            _messageService = messageService;
            _userIdCrypto = userIdCrypto;
            _rsaKeyService = rsaKeyService;
            _dhKeyService = dhKeyService;
            _aesService = aesService;
            _aesMessageIdService = aesMessageIdService;
            _friendsHub = friendsHub;
            _configuration = configuration;
            var db = mongoClient.GetDatabase(configuration["MongoDbSettings:DatabaseName"]);
            _globalMessagesCollection = db.GetCollection<GlobalMessage>("global_messages");
            _identificationsCollection = db.GetCollection<Identification>("identifications");
            _globalChatDhKeyService = globalChatDhKeyService;
            _battlefieldsCollection = db.GetCollection<Battlefield>("battlefields");
            _globalChatsCollection = db.GetCollection<GlobalChat>("global_chats");
            _battlefieldRequestsCollection = db.GetCollection<BattlefieldRequest>("battlefield_requests");
            _people = db.GetCollection<Person>("persons");
            _aesBattlefieldsService = aesBattlefieldsService;
            _aesBattlefieldIdService = aesBattlefieldIdService;
            _aesBattlefieldPreviewFileService = aesBattlefieldPreviewFileService;
            _aesBattlefieldOwnerIdService = aesBattlefieldOwnerIdService;
            _avatarUrlCryptoService = avatarUrlCryptoService;
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetGlobalChatPublicKey()
        {
            return Ok(_rsaKeyService.GetPublicKey("global-chat"));
        }

        [Authorize]
        [HttpPost("get-shared-secret")]
        public async Task<IActionResult> GetSharedSecret([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            // 1. Дешифруємо payload
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("global-chat", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid AES key or IV.");
            }

            string json;
            try
            {
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);
                json = sr.ReadToEnd();
            }
            catch (Exception ex)
            {
                return BadRequest("Failed to decrypt payload.");
            }

            // 2. Витягуємо battlefieldId
            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var battlefieldIdPlain = node?["encryptedBattlefieldId"]?.ToString();
            if (string.IsNullOrWhiteSpace(battlefieldIdPlain))
                return BadRequest("Missing battlefieldId");

            // 3. Зашифрувати його для пошуку
            string encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldIdPlain);

            // 4. Шукаємо GlobalChat
            var globalChat = await _globalChatsCollection.Find(x => x.BattlefieldId == encryptedBattlefieldId).FirstOrDefaultAsync();
            if (globalChat == null)
                return NotFound("Global chat not found.");

            // 5. Знаходимо Person
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null)
                return NotFound("User not found.");

            // 6. Перевірка, чи user є учасником напрямку
            if (!person.Battlefields.Contains(encryptedBattlefieldId))
                return Forbid("User is not a member of this battlefield.");

            // 7. Формуємо shared secret через сервіс (private user DH + public group DH)
            var sharedSecret = _globalChatDhKeyService.GetSharedSecretForClient(
                person.PrivateDhGroupEncrypted,
                globalChat.ChatPublicDhGroup
            );

            // 8. Віддаємо результат
            var sharedSecretBase64 = Convert.ToBase64String(sharedSecret);
            var respObj = new { sharedSecret = sharedSecretBase64 };
            var respJson = System.Text.Json.JsonSerializer.Serialize(respObj);

            using var aesResp = Aes.Create();
            aesResp.Key = aesKeyBytes;
            aesResp.IV = ivBytes;
            aesResp.Mode = CipherMode.CBC;
            aesResp.Padding = PaddingMode.PKCS7;
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aesResp.CreateEncryptor();
            var cipherResp = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aesResp.IV),
                ciphertext = Convert.ToBase64String(cipherResp)
            });
        }


        [Authorize]
        [HttpPost("get-messages")]
        public async Task<IActionResult> GetGlobalChatMessages([FromBody] EncryptedMessage encrypted)
        {
            // 1. Дешифруємо AES-ключ та IV (загальні для сесії)
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("global-chat", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch
            {
                return BadRequest("Invalid AES key or IV.");
            }

            // 2. Дешифруємо пейлоад (отримуємо battlefieldId)
            string json;
            try
            {
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);
                json = sr.ReadToEnd();
            }
            catch
            {
                return BadRequest("Failed to decrypt payload.");
            }

            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var battlefieldId = node?["battlefieldId"]?.ToString();
            if (string.IsNullOrWhiteSpace(battlefieldId))
                return BadRequest("Missing battlefieldId.");

            // 3. Авторизація та пошук об'єктів
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldId);
            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null)
                return NotFound("User not found.");
            if (!person.Battlefields.Contains(encryptedBattlefieldId))
                return Forbid("User is not a member of this battlefield.");

            // 4. Знаходимо GlobalChat
            var globalChat = await _globalChatsCollection.Find(x => x.BattlefieldId == encryptedBattlefieldId).FirstOrDefaultAsync();
            if (globalChat == null)
                return NotFound("Global chat not found.");

            // 5. Розшифровуємо messageIds
            var decryptedMessageIds = globalChat.GlobalMessagesIds
                .Select(id => _aesMessageIdService.Decrypt(id)).ToList();

            // 6. Завантажуємо всі повідомлення разом
            var messagesFilter = Builders<GlobalMessage>.Filter.In(x => x.Id, decryptedMessageIds);
            var messages = await _globalMessagesCollection.Find(messagesFilter).ToListAsync();

            // 7. Формуємо відповідь для клієнта
            var result = new List<object>();
            foreach (var encryptedMsgId in globalChat.GlobalMessagesIds)
            {
                // 7.1. Дістаємо з identifications: messageOwnerId (зашифрований userId)
                var identification = await _identificationsCollection
                    .Find(x => x.MessageId == encryptedMsgId)
                    .FirstOrDefaultAsync();
                if (identification == null)
                    continue;

                var ownerUserIdDecrypted = _userIdCrypto.Decrypt(identification.MessageOwnerId);
                var ownerPerson = await _people.Find(x => x.Id == ownerUserIdDecrypted).FirstOrDefaultAsync();
                if (ownerPerson == null)
                    continue;

                // ---- Дешифрування аватарки ----
                string avatarPath = string.IsNullOrEmpty(ownerPerson.AvatarUrl)
                    ? ""
                    : _avatarUrlCryptoService.Decrypt(ownerPerson.AvatarUrl);

                string avatarType;
                string? avatarUrlForFrontend;

                if (avatarPath.StartsWith("/protected-avatars/"))
                {
                    avatarType = "custom";
                    avatarUrlForFrontend = null;
                }
                else
                {
                    avatarType = "default";
                    avatarUrlForFrontend = avatarPath;
                }

                // 7.2. Shared secret для розшифрування цього повідомлення
                var sharedSecret = _globalChatDhKeyService.GetSharedSecretForServer(
                    globalChat.ChatPrivateDhGroupEncrypted,
                    ownerPerson.PublicDhGroup
                );

                // 7.3. Дістаємо сам message
                var msgId = _aesMessageIdService.Decrypt(encryptedMsgId);
                var message = messages.FirstOrDefault(m => m.Id == msgId);
                if (message == null)
                    continue;

                // 7.4. Дешифруємо усі поля (твоя AES-розшифровка через sharedSecret + message.iv)
                string DecryptField(string cipherBase64)
                {
                    if (string.IsNullOrEmpty(cipherBase64)) return "";
                    var cipherBytes = Convert.FromBase64String(cipherBase64);
                    using var aes = Aes.Create();
                    aes.Key = sharedSecret;
                    aes.IV = Convert.FromBase64String(message.Iv);
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using var decryptor = aes.CreateDecryptor();
                    var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
                    return Encoding.UTF8.GetString(plainBytes);
                }

                // 7.5. Формуємо об'єкт повідомлення для фронту (з інфою про автора)
                result.Add(new
                {
                    id = message.Id,
                    senderId = ownerUserIdDecrypted,
                    senderName = ownerPerson.Name,
                    senderRole = ownerPerson.Role,
                    senderAvatarType = avatarType,
                    senderAvatarUrl = avatarUrlForFrontend,
                    message = DecryptField(message.Ciphertext),
                    createdAt = DecryptField(message.CreatedAt),
                    isEdited = DecryptField(message.IsEdited),
                    replyId = DecryptField(message.ReplyId),
                    whoChecked = DecryptField(message.WhoChecked),
                    attachments = DecryptField(message.Attachments)
                });
            }

            // 8. Шифруємо масив для відправки клієнту (тим же aesKeyBytes/ivBytes)
            var respJson = System.Text.Json.JsonSerializer.Serialize(result);
            using var aesOut = Aes.Create();
            aesOut.Key = aesKeyBytes;
            aesOut.IV = ivBytes;
            aesOut.Mode = CipherMode.CBC;
            aesOut.Padding = PaddingMode.PKCS7;
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aesOut.CreateEncryptor();
            var cipherResp = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            return Ok(new
            {
                iv = Convert.ToBase64String(aesOut.IV),
                ciphertext = Convert.ToBase64String(cipherResp)
            });
        }


        [Authorize]
        [HttpPost("clear-chat")]
        public async Task<IActionResult> ClearGlobalChat([FromBody] EncryptedMessage encrypted)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");

            // 1. Дешифруємо payload
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("global-chat", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[ClearChat] Invalid AES key/IV: " + ex);
                return BadRequest("Invalid AES key or IV.");
            }

            string json;
            try
            {
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);
                json = sr.ReadToEnd();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[ClearChat] Failed to decrypt payload: " + ex);
                return BadRequest("Failed to decrypt payload.");
            }

            var node = System.Text.Json.Nodes.JsonNode.Parse(json);
            var battlefieldId = node?["battlefieldId"]?.ToString(); // plain ObjectId
            Console.WriteLine($"[ClearChat] User: {userId}, BattlefieldId from payload: {battlefieldId}");

            if (string.IsNullOrWhiteSpace(battlefieldId))
            {
                Console.WriteLine("[ClearChat] Missing battlefieldId in payload.");
                return BadRequest("Missing battlefieldId");
            }

            // 2. Знайти Battlefield по plain Id
            var battlefield = await _battlefieldsCollection.Find(x => x.Id == battlefieldId).FirstOrDefaultAsync();
            if (battlefield == null)
            {
                Console.WriteLine("[ClearChat] Battlefield not found for Id: " + battlefieldId);
                return NotFound("Battlefield not found.");
            }
            Console.WriteLine($"[ClearChat] Battlefield found: {battlefield.Id}");

            // 3. Перевірити власника
            var encryptedUserId = _aesBattlefieldOwnerIdService.Encrypt(userId);
            Console.WriteLine($"[ClearChat] Battlefield.OwnerId: {battlefield.OwnerId}, UserId: {userId}, EncryptedUserId: {encryptedUserId}");
            if (battlefield.OwnerId != encryptedUserId)
            {
                Console.WriteLine("[ClearChat] User is not owner.");
                return Forbid("Only the owner can clear the chat.");
            }

            // 4. Отримати зашифрований айді напрямку для пошуку GlobalChat
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefield.Id);
            Console.WriteLine($"[ClearChat] Encrypted BattlefieldId for GlobalChat: {encryptedBattlefieldId}");

            var globalChat = await _globalChatsCollection.Find(x => x.BattlefieldId == encryptedBattlefieldId).FirstOrDefaultAsync();
            if (globalChat == null)
            {
                Console.WriteLine("[ClearChat] Global chat not found for BattlefieldId: " + encryptedBattlefieldId);
                return NotFound("Global chat not found.");
            }
            Console.WriteLine($"[ClearChat] Global chat found: {globalChat.Id}");

            // 5. Дістаємо зашифровані айді повідомлень
            var encryptedMsgIds = globalChat.GlobalMessagesIds ?? new List<string>();

            // 6. Дешифруємо всі айді повідомлень для видалення з global_messages
            var plainMsgIds = new List<string>();
            foreach (var encId in encryptedMsgIds)
            {
                try
                {
                    var plainId = _aesMessageIdService.Decrypt(encId);
                    plainMsgIds.Add(plainId);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[ClearChat] Can't decrypt messageId: {encId}, Error: {ex}");
                }
            }

            if (plainMsgIds.Count > 0)
            {
                Console.WriteLine($"[ClearChat] Deleting {plainMsgIds.Count} messages from global_messages.");
                var filter = Builders<GlobalMessage>.Filter.In(x => x.Id, plainMsgIds);
                await _globalMessagesCollection.DeleteManyAsync(filter);
            }
            else
            {
                Console.WriteLine("[ClearChat] No messages to delete from global_messages.");
            }

            // 7. Видаляємо відповідні документи з identifications по зашифрованим messageId
            if (encryptedMsgIds.Count > 0)
            {
                Console.WriteLine($"[ClearChat] Deleting {encryptedMsgIds.Count} identifications...");
                var idFilter = Builders<Identification>.Filter.In(x => x.MessageId, encryptedMsgIds);
                await _identificationsCollection.DeleteManyAsync(idFilter);
            }
            else
            {
                Console.WriteLine("[ClearChat] No identifications to delete.");
            }

            // 8. Очистити масив повідомлень у глобальному чаті
            var update = Builders<GlobalChat>.Update.Set(x => x.GlobalMessagesIds, new List<string>());
            await _globalChatsCollection.UpdateOneAsync(x => x.Id == globalChat.Id, update);

            // 9. (Optional) SignalR...

            // 10. Зашифрована відповідь
            var respJson = System.Text.Json.JsonSerializer.Serialize(new { cleared = true });
            using var aesResp = Aes.Create();
            aesResp.Key = aesKeyBytes;
            aesResp.IV = ivBytes;
            aesResp.Mode = CipherMode.CBC;
            aesResp.Padding = PaddingMode.PKCS7;
            var respBytes = Encoding.UTF8.GetBytes(respJson);
            using var encryptor = aesResp.CreateEncryptor();
            var cipherResp = encryptor.TransformFinalBlock(respBytes, 0, respBytes.Length);

            Console.WriteLine("[ClearChat] Chat cleared successfully!");
            return Ok(new
            {
                iv = Convert.ToBase64String(aesResp.IV),
                ciphertext = Convert.ToBase64String(cipherResp)
            });
        }



        [Authorize]
        [HttpPost("send")]
        public async Task<IActionResult> SendGlobalMessage([FromBody] EncryptedMessage encrypted)
        {

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");


            // 1. Дешифрування AES ключа та IV
            byte[] aesKeyBytes, ivBytes;
            try
            {
                aesKeyBytes = _rsaKeyService.Decrypt("global-chat", Convert.FromBase64String(encrypted.EncryptedKey));
                ivBytes = Convert.FromBase64String(encrypted.Iv);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[B3 ERR] Invalid AES key or IV: " + ex);
                return BadRequest("Invalid AES key or IV.");
            }

            // 2. Розшифрування payload (повідомлення)
            string json;
            try
            {
                using var aes = Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                using var decryptor = aes.CreateDecryptor();
                var cipherBytes = Convert.FromBase64String(encrypted.Ciphertext);
                using var ms = new MemoryStream(cipherBytes);
                using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
                using var sr = new StreamReader(cs, Encoding.UTF8);
                json = sr.ReadToEnd();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[B4 ERR] Failed to decrypt payload: " + ex);
                return BadRequest("Failed to decrypt payload.");
            }

            // 3. Витягуємо battlefieldId
            var msgNode = System.Text.Json.Nodes.JsonNode.Parse(json);
            var battlefieldIdPlain = msgNode?["encryptedBattlefieldId"]?.ToString();

            if (string.IsNullOrWhiteSpace(battlefieldIdPlain))
                return BadRequest("Missing battlefieldId in payload.");

            // 4. Шифруємо battlefieldId для пошуку
            var encryptedBattlefieldId = _aesBattlefieldIdService.Encrypt(battlefieldIdPlain);

            // 5. Шукаємо глобальний чат
            var globalChat = await _globalChatsCollection.Find(x => x.BattlefieldId == encryptedBattlefieldId).FirstOrDefaultAsync();
            if (globalChat == null)
            {
                return NotFound("Global chat for battlefield not found.");
            }

            // 6. Перевірка користувача (AesUserIdService)
            var encryptedUserId = _userIdCrypto.Encrypt(userId);

            var person = await _people.Find(x => x.Id == userId).FirstOrDefaultAsync();
            if (person == null)
            {
                return NotFound("User not found.");
            }

            // 7. Перевіряємо, що user є учасником напрямку
            if (!person.Battlefields.Contains(encryptedBattlefieldId))
            {
                return Forbid("User is not a member of this battlefield.");
            }

            // 8. Десеріалізуємо повідомлення
            var globalMessage = System.Text.Json.JsonSerializer.Deserialize<GlobalMessage>(json);
            if (globalMessage == null)
            {
                return BadRequest("Invalid message payload.");
            }
            if (globalMessage == null)
                Console.WriteLine("[B10 ERR] Deserialization returned null!");
            else
            {
                Console.WriteLine("[B10+] Deserialized GlobalMessage:");
                Console.WriteLine($"  senderId: {globalMessage.SenderId}");
                Console.WriteLine($"  ciphertext: {globalMessage.Ciphertext}");
                Console.WriteLine($"  iv: {globalMessage.Iv}");
                Console.WriteLine($"  createdAt: {globalMessage.CreatedAt}");
                Console.WriteLine($"  isEdited: {globalMessage.IsEdited}");
                Console.WriteLine($"  replyId: {globalMessage.ReplyId}");
                Console.WriteLine($"  whoChecked: {globalMessage.WhoChecked}");
                Console.WriteLine($"  attachments: {globalMessage.Attachments}");
            }


            // 9. Додаємо повідомлення в базу
            await _globalMessagesCollection.InsertOneAsync(globalMessage);

            // --- Шифрування id повідомлення ---
            string encryptedMessageId = _aesMessageIdService.Encrypt(globalMessage.Id);

            // --- Додаємо до масиву чату ---
            var update = Builders<GlobalChat>.Update.Push(x => x.GlobalMessagesIds, encryptedMessageId);
            var res = await _globalChatsCollection.UpdateOneAsync(
                x => x.BattlefieldId == encryptedBattlefieldId,
                update
            );

            // --- Зберігаємо відповідність senderId <-> messageId у колекції identifications ---
            var identification = new Identification
            {
                MessageOwnerId = encryptedUserId,      // зашифрований userId
                MessageId = encryptedMessageId         // зашифрований messageId
            };
            await _identificationsCollection.InsertOneAsync(identification);

            if (res.MatchedCount == 0)
            {
                return NotFound("Global chat for battlefield not found.");
            }


            return Ok(new { messageId = globalMessage.Id });

        }

    }
}
