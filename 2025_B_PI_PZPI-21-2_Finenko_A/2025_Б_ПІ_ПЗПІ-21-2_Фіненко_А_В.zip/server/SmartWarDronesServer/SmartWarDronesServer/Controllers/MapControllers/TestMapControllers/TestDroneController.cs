﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Models.MapModels.TestMapModels;
using SmartWarDronesServer.Repositories.TestRepositories;
using SmartWarDronesServer.Services;
using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace SmartWarDronesServer.Controllers.MapControllers.TestMapControllers
{
    [ApiController]
    [Route("api/map/test-drone")]
    public class TestDroneController : ControllerBase
    {
        private readonly TestDroneRepository _droneRepository;
        private readonly TestStatsRepository _statsRepository;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly AesUserIdService _userIdCrypto;

        public TestDroneController(
            TestDroneRepository droneRepository,
            TestStatsRepository statsRepository,
            RsaKeyService rsaKeyService,
            AesUserIdService userIdCrypto,
            AesService aesService
        )
        {
            _droneRepository = droneRepository;
            _statsRepository = statsRepository;
            _rsaKeyService = rsaKeyService;
            _aesService = aesService;
            _userIdCrypto = userIdCrypto;
        }

        private string GetUserId()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetTestMapPublicKey()
        {
            return Ok(_rsaKeyService.GetPublicKey("test-map"));
        }

        [Authorize]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "test-map");
                var obj = JsonNode.Parse(json);

                var droneName = obj?["droneName"]?.ToString();
                var droneType = obj?["droneType"]?.ToString();
                var safetyCode = obj?["safetyCode"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneName) ||
                    string.IsNullOrWhiteSpace(droneType) ||
                    string.IsNullOrWhiteSpace(safetyCode))
                {
                    return BadRequest(new { Error = "Missing required fields" });
                }

                var existing = await _droneRepository.GetByDroneNameAsync(droneName);
                if (existing != null)
                    return BadRequest(new { Error = "Drone already exists" });

                // 1. Отримати userId з токену
                var userId = GetUserId();

                // 2. Зашифрувати userId через AesUserIdService
                var encryptedPersonId = _userIdCrypto.Encrypt(userId);

                // 3. Додати до моделі
                var dbDrone = new TestDrone
                {
                    DroneName = droneName,
                    DroneType = droneType,
                    SafetyCode = safetyCode,
                    PersonId = encryptedPersonId
                };

                await _droneRepository.InsertAsync(dbDrone);

                // Створити початкові stats для дрона
                var statsTypes = new List<string>
        {
            "Humidity",
            "Temperature",
            "WindDirection",
            "WindSpeed",
            "REBPresence",
            "BatteryLevel"
        };

                foreach (var statsType in statsTypes)
                {
                    var stats = new TestStats
                    {
                        StatsType = statsType,
                        StatsInformation = "Initial value",
                        DroneId = dbDrone.Id,
                        LastUpdate = DateTime.UtcNow
                    };
                    await _statsRepository.InsertAsync(stats);
                }

                return Ok(new TestDroneResponseModel
                {
                    Id = dbDrone.Id,
                    DroneName = dbDrone.DroneName,
                    DroneType = dbDrone.DroneType
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to register drone: {ex.Message}");
                return StatusCode(500, "Drone registration failed.");
            }
        }


        [Authorize]
        [HttpPost("getAll")]
        public async Task<IActionResult> GetAll([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                // 1. Розшифрувати AES-ключ
                var aesKeyBytes = _rsaKeyService.Decrypt("test-map", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);

                // 2. Витягти userId з токена та зашифрувати
                var userId = GetUserId(); // твоя функція
                var encryptedUserId = _userIdCrypto.Encrypt(userId);

                // 3. Отримати тільки свої дрони
                var drones = await _droneRepository.GetByPersonIdAsync(encryptedUserId);

                // 4. Підготувати відповідь
                var response = drones.Select(x => new TestDroneResponseModel
                {
                    Id = x.Id,
                    DroneName = x.DroneName,
                    DroneType = x.DroneType
                }).ToList();

                var responseJson = System.Text.Json.JsonSerializer.Serialize(response);
                var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

                // 5. Зашифрувати відповідь тим же AES+IV
                using var aes = System.Security.Cryptography.Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = System.Security.Cryptography.CipherMode.CBC;
                aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var responseObj = new
                {
                    iv = encrypted.Iv, // IV той же
                    ciphertext = Convert.ToBase64String(cipherBytes)
                };

                return Ok(responseObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to fetch drones: {ex.Message}");
                return StatusCode(500, "Failed to fetch drones.");
            }
        }


        [Authorize]
        [HttpPut("changeDroneName")]
        public async Task<IActionResult> ChangeDroneName([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "test-map");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                var newDroneName = obj?["newDroneName"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneId) || string.IsNullOrWhiteSpace(newDroneName))
                    return BadRequest("droneId and newDroneName are required.");

                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found.");

                drone.DroneName = newDroneName;
                await _droneRepository.UpdateAsync(drone);

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to change drone name: {ex.Message}");
                return StatusCode(500, "Failed to change drone name.");
            }
        }

        [Authorize]
        [HttpPut("changeDroneType")]
        public async Task<IActionResult> ChangeDroneType([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "test-map");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                var newDroneType = obj?["newDroneType"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneId) || string.IsNullOrWhiteSpace(newDroneType))
                    return BadRequest("droneId and newDroneType are required.");

                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found.");

                drone.DroneType = newDroneType;
                await _droneRepository.UpdateAsync(drone);

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to change drone type: {ex.Message}");
                return StatusCode(500, "Failed to change drone type.");
            }
        }

        [Authorize]
        [HttpPost("deleteByDroneName")]
        public async Task<IActionResult> DeleteByDroneName([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "test-map");
                var obj = JsonNode.Parse(json);

                var droneName = obj?["droneName"]?.ToString();
                if (string.IsNullOrWhiteSpace(droneName))
                    return BadRequest(new { Error = "droneName is required" });

                var drone = await _droneRepository.GetByDroneNameAsync(droneName);
                if (drone == null)
                    return NotFound(new { Error = "Drone not found" });

                await _droneRepository.DeleteByNameAsync(droneName);
                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to delete drone: {ex.Message}");
                return StatusCode(500, "Failed to delete drone.");
            }
        }
    }
}
