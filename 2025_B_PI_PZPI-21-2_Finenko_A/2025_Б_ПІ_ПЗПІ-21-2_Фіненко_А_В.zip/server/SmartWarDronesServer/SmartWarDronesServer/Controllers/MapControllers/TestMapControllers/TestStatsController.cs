﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SmartWarDronesServer.Models.MapModels.TestMapModels;
using SmartWarDronesServer.Repositories.TestRepositories;
using SmartWarDronesServer.Hubs; // якщо твій SignalR Hub для статистики тут
using Microsoft.AspNetCore.Authorization;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using System.Text.Json.Nodes;

namespace SmartWarDronesServer.Controllers.MapControllers.TestMapControllers
{
    [ApiController]
    [Route("api/map/test-stats")]
    public class TestStatsController : ControllerBase
    {
        private readonly TestStatsRepository _stateRepository;
        private readonly TestDroneRepository _droneRepository;
        private readonly IHubContext<StatsHub> _hubContext;
        private readonly AesService _aesService;
        private readonly RsaKeyService _rsaKeyService;

        public TestStatsController(TestStatsRepository stateRepository, TestDroneRepository droneRepository, IHubContext<StatsHub> hubContext, AesService aesService, RsaKeyService rsaKeyService)
        {
            _stateRepository = stateRepository;
            _droneRepository = droneRepository;
            _hubContext = hubContext;
            _aesService = aesService;
            _rsaKeyService = rsaKeyService;
        }

        [Authorize]
        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetStatsById(string id)
        {
            var stats = await _stateRepository.GetByIdAsync(id);
            if (stats == null)
                return NotFound(new { Error = "Stats not found" });

            var response = new TestStatsResponseModel
            {
                StatsType = stats.StatsType,
                StatsInformation = stats.StatsInformation
            };

            return Ok(response);
        }

        [Authorize]
        [HttpPost("getByDroneId")]
        public async Task<IActionResult> GetStatsByDroneId([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "test-map");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                if (string.IsNullOrWhiteSpace(droneId))
                    return BadRequest(new { Error = "droneId is required" });

                var stats = await _stateRepository.GetByDroneIdAsync(droneId);
                if (stats == null || stats.Count == 0)
                    return NotFound(new { Error = "No stats found for this drone" });

                var response = stats.Select(s => new TestStatsResponseModel
                {
                    StatsType = s.StatsType,
                    StatsInformation = s.StatsInformation
                }).ToList();

                var responseJson = System.Text.Json.JsonSerializer.Serialize(response);
                var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

                // Зашифрувати відповідь тим же AES+IV
                var aesKeyBytes = _rsaKeyService.Decrypt("test-map", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);

                using var aes = System.Security.Cryptography.Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = System.Security.Cryptography.CipherMode.CBC;
                aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var responseObj = new
                {
                    iv = encrypted.Iv,
                    ciphertext = Convert.ToBase64String(cipherBytes)
                };

                return Ok(responseObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to fetch stats: {ex.Message}");
                return StatusCode(500, "Failed to fetch stats.");
            }
        }


        [Authorize]
        [HttpGet("getByDroneName/{droneName}")]
        public async Task<IActionResult> GetStatsByDroneName(string droneName)
        {
            var drone = await _droneRepository.GetByDroneNameAsync(droneName);
            if (drone == null)
                return NotFound(new { Error = "Drone not found" });

            var stats = await _stateRepository.GetByDroneIdAsync(drone.Id);
            if (stats == null || stats.Count == 0)
                return NotFound(new { Error = "No stats found for this drone" });

            var response = stats.Select(s => new TestStatsResponseModel
            {
                StatsType = s.StatsType,
                StatsInformation = s.StatsInformation
            });

            return Ok(response);
        }

        [HttpPut("updateByDroneIdAndStatsType/{droneId}")]
        public async Task<IActionResult> UpdateStatsByDroneIdAndStatsType(string droneId, [FromBody] TestUpdateStatsModel model)
        {
            var stats = await _stateRepository.GetByDroneIdAndStatsTypeAsync(droneId, model.StatsType);
            if (stats == null)
                return NotFound(new { Error = "Stats not found for the given DroneId and StatsType" });

            stats.StatsInformation = model.StatsInformation;
            stats.LastUpdate = DateTime.UtcNow;

            await _stateRepository.UpdateAsync(stats);

            // Відправляємо оновлення клієнтам через SignalR
            await _hubContext.Clients.All.SendAsync("ReceiveStatsUpdate", new
            {
                droneId = droneId,
                statsType = model.StatsType,
                statsInformation = model.StatsInformation
            });

            return Ok(stats);
        }

        [Authorize]
        [HttpPost("updateSensorData")]
        public async Task<IActionResult> UpdateSensorData([FromBody] TestSensorDataModel sensorData)
        {
            var drone = await _droneRepository.GetByIdAsync(sensorData.DroneId);
            if (drone == null)
                return NotFound(new { Error = "Drone not found" });

            var statsTypes = new[]
            {
                new { Type = "Temperature", Value = sensorData.Temperature.ToString() },
                new { Type = "Humidity", Value = sensorData.Humidity.ToString() },
                new { Type = "WindSpeed", Value = sensorData.WindSpeed.ToString() },
                new { Type = "WindDirection", Value = sensorData.WindDirection },
                new { Type = "BatteryLevel", Value = sensorData.BatteryLevel.ToString() },
                new { Type = "REBPresence", Value = sensorData.REBPresence.ToString() }
            };

            foreach (var statsType in statsTypes)
            {
                var stats = await _stateRepository.GetByDroneIdAndStatsTypeAsync(sensorData.DroneId, statsType.Type);
                if (stats != null)
                {
                    stats.StatsInformation = statsType.Value;
                    stats.LastUpdate = DateTime.UtcNow;
                    await _stateRepository.UpdateAsync(stats);
                }
                else
                {
                    var newStats = new TestStats
                    {
                        DroneId = sensorData.DroneId,
                        StatsType = statsType.Type,
                        StatsInformation = statsType.Value,
                        LastUpdate = DateTime.UtcNow
                    };
                    await _stateRepository.InsertAsync(newStats);
                }
            }

            return Ok(new { Message = "Sensor data updated successfully" });
        }
    }
}
