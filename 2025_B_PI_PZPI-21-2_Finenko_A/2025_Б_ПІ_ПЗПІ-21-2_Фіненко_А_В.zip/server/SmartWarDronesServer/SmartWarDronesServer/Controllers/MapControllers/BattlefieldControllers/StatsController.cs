﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SmartWarDronesServer.Models.MapModels.BattlefieldModels;
using SmartWarDronesServer.Repositories.BattlefieldRepositories;
using SmartWarDronesServer.Hubs; // якщо твій SignalR Hub для статистики тут
using Microsoft.AspNetCore.Authorization;
using SmartWarDrones.Server.Services;
using System.Text.Json.Nodes;
using SmartWarDrones.Server.Models;
using SmartWarDronesServer.Services;


namespace SmartWarDronesServer.Controllers.MapControllers.BattlefieldControllers
{
    [ApiController]
    [Route("api/map/stats")]
    public class StatsController : ControllerBase
    {
        private readonly StatsRepository _stateRepository;
        private readonly DroneRepository _droneRepository;
        private readonly IHubContext<StatsHub> _hubContext;
        private readonly AesService _aesService;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesDroneIdService _aesDroneIdService;
        private readonly AesDronesService _aesDronesService;

        public StatsController(
            StatsRepository stateRepository, 
            DroneRepository droneRepository, 
            IHubContext<StatsHub> hubContext, 
            AesService aesService, 
            RsaKeyService rsaKeyService, 
            AesDroneIdService aesDroneIdService, 
            AesDronesService aesDronesService)
        {
            _stateRepository = stateRepository;
            _droneRepository = droneRepository;
            _hubContext = hubContext;
            _aesService = aesService;
            _rsaKeyService = rsaKeyService;
            _aesDroneIdService = aesDroneIdService;
            _aesDronesService = aesDronesService;
        }

        [Authorize]
        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetStatsById(string id)
        {
            var stats = await _stateRepository.GetByIdAsync(id);
            if (stats == null)
                return NotFound(new { Error = "Stats not found" });

            var response = new StatsResponseModel
            {
                StatsType = stats.StatsType,
                StatsInformation = stats.StatsInformation
            };

            return Ok(response);
        }

        [Authorize]
        [HttpPost("getByDroneId")]
        public async Task<IActionResult> GetStatsByDroneId([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                if (string.IsNullOrWhiteSpace(droneId))
                    return BadRequest(new { Error = "droneId is required" });

                // ---- ТУТ ШИФРУЄМО ДЛЯ Пошуку ----
                var encryptedDroneId = _aesDroneIdService.Encrypt(droneId);

                var stats = await _stateRepository.GetByDroneIdAsync(encryptedDroneId);
                if (stats == null || stats.Count == 0)
                    return NotFound(new { Error = "No stats found for this drone" });

                var response = stats.Select(s => new StatsResponseModel
                {
                    StatsType = s.StatsType,
                    StatsInformation = s.StatsInformation
                }).ToList();

                var responseJson = System.Text.Json.JsonSerializer.Serialize(response);
                var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

                // Зашифрувати відповідь тим же AES+IV
                var aesKeyBytes = _rsaKeyService.Decrypt("drones", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);

                using var aes = System.Security.Cryptography.Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = System.Security.Cryptography.CipherMode.CBC;
                aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var responseObj = new
                {
                    iv = encrypted.Iv,
                    ciphertext = Convert.ToBase64String(cipherBytes)
                };

                return Ok(responseObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to fetch stats: {ex}");
                return StatusCode(500, new { error = "Failed to fetch stats", details = ex.ToString() });
            }
        }


        [Authorize]
        [HttpGet("getByDroneName/{droneName}")]
        public async Task<IActionResult> GetStatsByDroneName(string droneName)
        {
            var drone = await _droneRepository.GetByDroneNameAsync(droneName);
            if (drone == null)
                return NotFound(new { Error = "Drone not found" });

            // ---- ШИФРУЄМО його Id ----
            var encryptedDroneId = _aesDroneIdService.Encrypt(drone.Id);

            var stats = await _stateRepository.GetByDroneIdAsync(encryptedDroneId);
            if (stats == null || stats.Count == 0)
                return NotFound(new { Error = "No stats found for this drone" });

            var response = stats.Select(s => new StatsResponseModel
            {
                StatsType = s.StatsType,
                StatsInformation = s.StatsInformation
            });

            return Ok(response);
        }


        [HttpPut("updateByDroneIdAndStatsType/{droneId}")]
        public async Task<IActionResult> UpdateStatsByDroneIdAndStatsType(string droneId, [FromBody] UpdateStatsModel model)
        {
            // ---- ШИФРУЄМО ----
            var encryptedDroneId = _aesDroneIdService.Encrypt(droneId);

            var stats = await _stateRepository.GetByDroneIdAndStatsTypeAsync(encryptedDroneId, model.StatsType);
            if (stats == null)
                return NotFound(new { Error = "Stats not found for the given DroneId and StatsType" });

            stats.StatsInformation = model.StatsInformation;
            stats.LastUpdate = DateTime.UtcNow;

            await _stateRepository.UpdateAsync(stats);

            // Відправляємо оновлення клієнтам через SignalR
            await _hubContext.Clients.All.SendAsync("ReceiveStatsUpdate", new
            {
                droneId = droneId,
                statsType = model.StatsType,
                statsInformation = model.StatsInformation
            });

            return Ok(stats);
        }

        [Authorize]
        [HttpPut("updateByDroneSafetyCodeAndStatsType")]
        public async Task<IActionResult> UpdateByDroneSafetyCodeAndStatsType([FromBody] UpdateStatsBySafetyCodeModel model)
        {
            if (string.IsNullOrWhiteSpace(model.SafetyCode) ||
                string.IsNullOrWhiteSpace(model.StatsType) ||
                string.IsNullOrWhiteSpace(model.StatsInformation))
                return BadRequest(new { Error = "safetyCode, statsType, statsInformation are required" });

            // 1. Зашифрувати SafetyCode так само як при додаванні дрона
            var encryptedSafetyCode = _aesDronesService.Encrypt(model.SafetyCode);

            // 2. Знайти дрона
            var drone = await _droneRepository.GetBySafetyCodeAsync(encryptedSafetyCode);
            if (drone == null)
                return NotFound(new { Error = "Drone not found by safetyCode" });

            // 3. Зашифрувати його Id для статистик
            var encryptedDroneId = _aesDroneIdService.Encrypt(drone.Id);

            // 4. Знайти статистику для цього дрона і типу
            var stats = await _stateRepository.GetByDroneIdAndStatsTypeAsync(encryptedDroneId, model.StatsType);
            if (stats == null)
                return NotFound(new { Error = "Stats not found for given drone and type" });

            // 5. Оновити статистику
            stats.StatsInformation = model.StatsInformation;
            stats.LastUpdate = DateTime.UtcNow;
            await _stateRepository.UpdateAsync(stats);

            // (опційно — відправити оновлення через SignalR)
            await _hubContext.Clients.All.SendAsync("ReceiveStatsUpdate", new
            {
                 droneId = drone.Id,
                 statsType = model.StatsType,
                 statsInformation = model.StatsInformation
           });

            return Ok(stats);
        }


        [Authorize]
        [HttpPost("updateSensorData")]
        public async Task<IActionResult> UpdateSensorData([FromBody] SensorDataModel sensorData)
        {
            var drone = await _droneRepository.GetByIdAsync(sensorData.DroneId);
            if (drone == null)
                return NotFound(new { Error = "Drone not found" });

            // ---- ШИФРУЄМО DroneId для статистик ----
            var encryptedDroneId = _aesDroneIdService.Encrypt(sensorData.DroneId);

            var statsTypes = new[]
            {
        new { Type = "Temperature", Value = sensorData.Temperature.ToString() },
        new { Type = "Humidity", Value = sensorData.Humidity.ToString() },
        new { Type = "WindSpeed", Value = sensorData.WindSpeed.ToString() },
        new { Type = "WindDirection", Value = sensorData.WindDirection },
        new { Type = "BatteryLevel", Value = sensorData.BatteryLevel.ToString() },
        new { Type = "REBPresence", Value = sensorData.REBPresence.ToString() }
    };

            foreach (var statsType in statsTypes)
            {
                var stats = await _stateRepository.GetByDroneIdAndStatsTypeAsync(encryptedDroneId, statsType.Type);
                if (stats != null)
                {
                    stats.StatsInformation = statsType.Value;
                    stats.LastUpdate = DateTime.UtcNow;
                    await _stateRepository.UpdateAsync(stats);
                }
                else
                {
                    var newStats = new Stats
                    {
                        DroneId = encryptedDroneId,
                        StatsType = statsType.Type,
                        StatsInformation = statsType.Value,
                        LastUpdate = DateTime.UtcNow
                    };
                    await _stateRepository.InsertAsync(newStats);
                }
            }

            return Ok(new { Message = "Sensor data updated successfully" });
        }

        public class UpdateStatsBySafetyCodeModel
        {
            public string SafetyCode { get; set; } = "";
            public string StatsType { get; set; } = "";
            public string StatsInformation { get; set; } = "";
        }

    }
}
