﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using SmartWarDronesServer.Models.MapModels.BattlefieldModels;
using SmartWarDronesServer.Repositories.BattlefieldRepositories;
using SmartWarDronesServer.Services;
using System.Security.Claims;
using System.Text.Json.Nodes;


namespace SmartWarDronesServer.Controllers.MapControllers.BattlefieldControllers
{
    [ApiController]
    [Route("api/map/drone")]
    public class DroneController : ControllerBase
    {
        private readonly DroneRepository _droneRepository;
        private readonly StatsRepository _statsRepository;
        private readonly RsaKeyService _rsaKeyService;
        private readonly AesService _aesService;
        private readonly AesUserIdService _userIdCrypto;
        private readonly AesDronesService _aesDronesService; // Додаємо
        private readonly AesDroneIdService _aesDroneIdService;

        public DroneController(
            DroneRepository droneRepository,
            StatsRepository statsRepository,
            RsaKeyService rsaKeyService,
            AesUserIdService userIdCrypto,
            AesService aesService,
            AesDronesService aesDronesService,
            AesDroneIdService aesDroneIdService // Додаємо
            )
        {
            _droneRepository = droneRepository;
            _statsRepository = statsRepository;
            _rsaKeyService = rsaKeyService;
            _aesService = aesService;
            _userIdCrypto = userIdCrypto;
            _aesDronesService = aesDronesService; // Додаємо
            _aesDroneIdService = aesDroneIdService;
        }

        private string GetUserId()
        {
            return User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? throw new UnauthorizedAccessException("User ID not found in token.");
        }

        [Authorize]
        [HttpGet("public-key")]
        public IActionResult GetPublicKey()
            => Ok(_rsaKeyService.GetPublicKey("drones"));

        [Authorize]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneName = obj?["droneName"]?.ToString();
                var droneType = obj?["droneType"]?.ToString();
                var frequencyBand = obj?["frequencyBand"]?.ToString();
                var avatarUrl = obj?["avatarUrl"]?.ToString() ?? "";
                var safetyCode = obj?["safetyCode"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneName) ||
                    string.IsNullOrWhiteSpace(droneType) ||
                    string.IsNullOrWhiteSpace(frequencyBand) ||
                    string.IsNullOrWhiteSpace(safetyCode))
                {
                    return BadRequest("Missing required fields");
                }

                var userId = GetUserId();
                var encryptedPersonId = _userIdCrypto.Encrypt(userId);

                // Завантажуємо всі дрони користувача
                var existingDrones = await _droneRepository.GetByPersonIdAsync(encryptedPersonId);

                // Перевірка унікальності SafetyCode
                var encryptedSafetyCode = _aesDronesService.Encrypt(safetyCode);
                if (existingDrones.Any(d => d.SafetyCode == encryptedSafetyCode))
                {
                    return BadRequest("Problem with Adding New Drone");
                }

                // Перевірка унікальності імені
                var encryptedDroneName = _aesDronesService.Encrypt(droneName);
                if (existingDrones.Any(d => d.DroneName == encryptedDroneName))
                {
                    return BadRequest("Not unique name");
                }

                // Шифруємо всі поля
                var dbDrone = new Drone
                {
                    DroneName = encryptedDroneName,
                    DroneType = _aesDronesService.Encrypt(droneType),
                    FrequencyBand = _aesDronesService.Encrypt(frequencyBand),
                    AvatarUrl = _aesDronesService.Encrypt(avatarUrl),
                    SafetyCode = encryptedSafetyCode,
                    OperatorId = encryptedPersonId
                };

                await _droneRepository.InsertAsync(dbDrone);

                // Створення stats без змін
                var statsTypes = new List<string>
        {
            "Humidity",
            "Temperature",
            "WindDirection",
            "WindSpeed",
            "REBPresence",
            "BatteryLevel"
        };

                foreach (var statsType in statsTypes)
                {
                    var encryptedDroneId = _aesDroneIdService.Encrypt(dbDrone.Id);
                    var stats = new Stats
                    {
                        StatsType = statsType,
                        StatsInformation = "Initial value",
                        DroneId = encryptedDroneId, // Тепер шифруємо
                        LastUpdate = DateTime.UtcNow
                    };
                    await _statsRepository.InsertAsync(stats);
                }

                return Ok(new { Success = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to register drone: {ex.Message}");
                return StatusCode(500, "Drone registration failed.");
            }
        }

        [Authorize]
        [HttpPost("getAll")]
        public async Task<IActionResult> GetAll([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                // 1. Розшифрувати AES-ключ
                var aesKeyBytes = _rsaKeyService.Decrypt("drones", Convert.FromBase64String(encrypted.EncryptedKey));
                var ivBytes = Convert.FromBase64String(encrypted.Iv);

                // 2. Витягти userId з токена та зашифрувати
                var userId = GetUserId();
                var encryptedUserId = _userIdCrypto.Encrypt(userId);

                // 3. Отримати свої дрони
                var drones = await _droneRepository.GetByPersonIdAsync(encryptedUserId);

                // 4. Розшифрувати перед відправкою!
                var response = drones.Select(d => new
                {
                    d.Id,
                    DroneName = _aesDronesService.Decrypt(d.DroneName),
                    DroneType = _aesDronesService.Decrypt(d.DroneType),
                    FrequencyBand = _aesDronesService.Decrypt(d.FrequencyBand),
                    AvatarUrl = _aesDronesService.Decrypt(d.AvatarUrl),
                    SafetyCode = _aesDronesService.Decrypt(d.SafetyCode),
                    d.OperatorId // Якщо потрібно, тут можна теж розшифрувати, але зазвичай OperatorId не розшифровується для фронта
                }).ToList();

                var responseJson = System.Text.Json.JsonSerializer.Serialize(response);
                var plainBytes = System.Text.Encoding.UTF8.GetBytes(responseJson);

                // 5. Зашифрувати відповідь тим же AES+IV
                using var aes = System.Security.Cryptography.Aes.Create();
                aes.Key = aesKeyBytes;
                aes.IV = ivBytes;
                aes.Mode = System.Security.Cryptography.CipherMode.CBC;
                aes.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

                using var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                var responseObj = new
                {
                    iv = encrypted.Iv,
                    ciphertext = Convert.ToBase64String(cipherBytes)
                };

                return Ok(responseObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to fetch drones: {ex.Message}");
                return StatusCode(500, "Failed to fetch drones.");
            }
        }

        [Authorize]
        [HttpPut("updateInfo")]
        public async Task<IActionResult> UpdateDroneInfo([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                var newName = obj?["name"]?.ToString();
                var newType = obj?["type"]?.ToString();
                var newBand = obj?["band"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneId) ||
                    string.IsNullOrWhiteSpace(newName) ||
                    string.IsNullOrWhiteSpace(newType) ||
                    string.IsNullOrWhiteSpace(newBand))
                {
                    return BadRequest("All fields are required.");
                }

                // Дістаємо дрон
                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found.");

                // Шифруємо нові дані
                var encryptedName = _aesDronesService.Encrypt(newName);
                var encryptedType = _aesDronesService.Encrypt(newType);
                var encryptedBand = _aesDronesService.Encrypt(newBand);

                // ===== Валідація імені по всій базі (унікальність) =====
                var droneWithThisName = await _droneRepository.GetByDroneNameAsync(encryptedName);
                if (droneWithThisName != null && droneWithThisName.Id != droneId)
                {
                    return BadRequest("Not unique name");
                }

                var updated = await _droneRepository.UpdateDroneInfoAsync(droneId, encryptedName, encryptedType, encryptedBand);
                if (!updated)
                    return StatusCode(500, "Failed to update drone.");

                return Ok(new { Success = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to update drone info: {ex.Message}");
                return StatusCode(500, "Failed to update drone info.");
            }
        }



        [Authorize]
        [HttpPut("changeDroneName")]
        public async Task<IActionResult> ChangeDroneName([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                var newDroneName = obj?["newDroneName"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneId) || string.IsNullOrWhiteSpace(newDroneName))
                    return BadRequest("droneId and newDroneName are required.");

                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found.");

                drone.DroneName = newDroneName;
                await _droneRepository.UpdateAsync(drone);

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to change drone name: {ex.Message}");
                return StatusCode(500, "Failed to change drone name.");
            }
        }

        [Authorize]
        [HttpPut("changeDroneType")]
        public async Task<IActionResult> ChangeDroneType([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                var newDroneType = obj?["newDroneType"]?.ToString();

                if (string.IsNullOrWhiteSpace(droneId) || string.IsNullOrWhiteSpace(newDroneType))
                    return BadRequest("droneId and newDroneType are required.");

                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found.");

                drone.DroneType = newDroneType;
                await _droneRepository.UpdateAsync(drone);

                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to change drone type: {ex.Message}");
                return StatusCode(500, "Failed to change drone type.");
            }
        }

        [Authorize]
        [HttpPost("deleteById")]
        public async Task<IActionResult> DeleteById([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneId = obj?["droneId"]?.ToString();
                if (string.IsNullOrWhiteSpace(droneId))
                    return BadRequest("droneId is required");

                // Знаходимо дрона
                var drone = await _droneRepository.GetByIdAsync(droneId);
                if (drone == null)
                    return NotFound("Drone not found");

                // Видаляємо дрона
                var deleted = await _droneRepository.DeleteByIdAsync(droneId);

                // Видаляємо всі статистики по зашифрованому айді дрона
                var encryptedDroneId = _aesDroneIdService.Encrypt(droneId);
                await _statsRepository.DeleteByDroneIdAsync(encryptedDroneId);

                if (!deleted)
                    return StatusCode(500, "Failed to delete drone.");

                return Ok(new { Success = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to delete drone: {ex.Message}");
                return StatusCode(500, "Failed to delete drone.");
            }
        }


        [Authorize]
        [HttpPost("deleteByDroneName")]
        public async Task<IActionResult> DeleteByDroneName([FromBody] EncryptedMessage encrypted)
        {
            try
            {
                var json = _aesService.DecryptToJson(encrypted, "drones");
                var obj = JsonNode.Parse(json);

                var droneName = obj?["droneName"]?.ToString();
                if (string.IsNullOrWhiteSpace(droneName))
                    return BadRequest(new { Error = "droneName is required" });

                var drone = await _droneRepository.GetByDroneNameAsync(droneName);
                if (drone == null)
                    return NotFound(new { Error = "Drone not found" });

                await _droneRepository.DeleteByNameAsync(droneName);
                return NoContent();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to delete drone: {ex.Message}");
                return StatusCode(500, "Failed to delete drone.");
            }
        }

    }
}
