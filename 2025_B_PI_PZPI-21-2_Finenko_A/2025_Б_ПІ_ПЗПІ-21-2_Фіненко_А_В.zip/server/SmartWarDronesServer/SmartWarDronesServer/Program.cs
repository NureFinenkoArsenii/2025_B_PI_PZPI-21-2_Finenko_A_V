using MongoDB.Driver;
using SmartWarDrones.Server.Models;
using SmartWarDrones.Server.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using SmartWarDronesServer.Services;
using Microsoft.AspNetCore.SignalR; // ������!
using SmartWarDrones.Server.Hubs;// ������, ���� ���� FriendsHub.cs � /Hubs/
using SmartWarDronesServer.Repositories.TestRepositories;
using SmartWarDronesServer.Repositories.BattlefieldRepositories;
using SmartWarDronesServer.Hubs;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<EmailService>();
builder.Services.AddScoped<TestDroneRepository>();
builder.Services.AddScoped<TestStatsRepository>();
builder.Services.AddScoped<DroneRepository>();
builder.Services.AddScoped<StatsRepository>();
builder.Services.AddSingleton<RsaKeyService>();
builder.Services.AddSingleton<AesDronesService>();
builder.Services.AddSingleton<IdentifierService>();
builder.Services.AddHostedService<IdentifierBackgroundService>();
builder.Services.AddScoped<PasswordService>();
builder.Services.AddSingleton<AesDroneIdService>();
builder.Services.AddSingleton<BioCryptoService>();
builder.Services.AddSingleton<IdentifierCryptoService>();
builder.Services.AddSingleton<AesBattlefieldsService>();
builder.Services.AddSingleton<AesBattlefieldIdService>();
builder.Services.AddSingleton<AesBattlefieldPreviewFileService>();
builder.Services.AddSingleton<AesUserIdService>();
builder.Services.AddSingleton<GlobalChatDhKeyService>();
builder.Services.AddSingleton<AttachmentUrlCryptoService>();
builder.Services.AddSingleton<AesBattlefieldOwnerIdService>();
builder.Services.AddScoped<MessageService>();
builder.Services.AddSingleton<DhKeyService>();
builder.Services.AddSingleton<AesMessageIdService>();
builder.Services.AddSingleton<AvatarUrlCryptoService>();
builder.Services.AddScoped<AesService>();
builder.Services.AddSignalR(); // ������

builder.Services.Configure<MongoDbSettings>(
    builder.Configuration.GetSection("MongoDbSettings"));

builder.Services.AddSingleton<IMongoClient>(s =>
    new MongoClient(builder.Configuration["MongoDbSettings:ConnectionString"]));

builder.Services.AddScoped<JwtService>();
builder.Services.AddScoped<AuthService>();

builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer("Bearer", options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["JwtSecret"]!))
        };
    });

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:5173")
              .AllowAnyMethod()
        .WithHeaders("Authorization", "X-Public-Key", "Content-Type", "x-requested-with", "x-signalr-user-agent")
              .AllowCredentials()
              .SetIsOriginAllowed(_ => true);
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHub<FriendsHub>("/hubs/friends"); // ������!
app.MapHub<StatsHub>("/hubs/statshub");

using (var scope = app.Services.CreateScope())
{
    var identifierService = scope.ServiceProvider.GetRequiredService<IdentifierService>();
    await identifierService.UpdateAllIdentifiersAsync();

    // ������ ���������� ��� ������ � ����������
    var testDroneRepo = scope.ServiceProvider.GetRequiredService<TestDroneRepository>();
    await testDroneRepo.CreateIndexesAsync();

    var testStatsRepo = scope.ServiceProvider.GetRequiredService<TestStatsRepository>();
    await testStatsRepo.CreateIndexesAsync();

    // ������ ���������� ��� ������ � ����������
    var DroneRepo = scope.ServiceProvider.GetRequiredService<DroneRepository>();
    await testDroneRepo.CreateIndexesAsync();

    var StatsRepo = scope.ServiceProvider.GetRequiredService<StatsRepository>();
    await testStatsRepo.CreateIndexesAsync();

}

await app.RunAsync();
