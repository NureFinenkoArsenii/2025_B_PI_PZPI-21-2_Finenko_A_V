import React, { useContext, useState, useEffect } from 'react';
import { DroneContext } from './DroneContext';
import DroneFormField from './DroneFormField';
import { fetchWithAuth } from '../../../utils/tokenManager';
import {
    generateRandomBytes,
    encryptJsonWithAES_forPassword,
    encryptAESKeyWithRSA_forPassword,
  } from "../../../utils/passwordCrypto";
  

function RegisterDrone() {
    const { selectedDrone, addDrone, updateDrone } = useContext(DroneContext);
    const [droneName, setDroneName] = useState('');
    const [droneType, setDroneType] = useState('');
    const [safetyCode, setSafetyCode] = useState('');
    const [id, setId] = useState(null);

    useEffect(() => {
        if (selectedDrone) {
            setDroneName(selectedDrone.droneName || '');
            setDroneType(selectedDrone.droneType || '');
            setSafetyCode(selectedDrone.safetyCode || '');
            setId(selectedDrone.id || null);
        } else {
            setDroneName('');
            setDroneType('');
            setSafetyCode('');
            setId(null);
        }
    }, [selectedDrone]);

    const handleSubmit = async (e) => {
        e.preventDefault();
      
        if (selectedDrone) {
          try {
            const updatedDrone = { id, droneName, droneType, safetyCode };
            updateDrone(updatedDrone);
            window.location.reload();
          } catch (error) {
            console.error('Error updating drone data:', error);
          }
        } else {
          try {
            // 1. Отримати публічний RSA-ключ
            const publicKeyRes = await fetchWithAuth("/api/map/test-drone/public-key");
            const base64 = await publicKeyRes.text();
      
            // 2. Сформувати PEM
            const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
              .match(/.{1,64}/g)
              .join("\n")}\n-----END PUBLIC KEY-----`;
      
            // 3. Згенерувати AES-ключ та IV
            const aesKey = generateRandomBytes(16);
            const ivBytes = generateRandomBytes(16);
      
            // 4. Зашифрувати payload
            const payload = { droneName, droneType, safetyCode };
            const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, ivBytes);
      
            // 5. Зашифрувати AES-ключ RSA публічним ключем
            const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
      
            // 6. Надіслати на бекенд
            const response = await fetchWithAuth('/api/map/test-drone/register', {
              method: 'POST',
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
            });
      
            if (response.ok) {
              // Відповідь plaintext (тільки базова info, не треба розшифровувати!)
              const data = await response.json();
              addDrone(data);
              window.location.reload();
            } else {
              // Можливо сервер віддасть { Error: "..."} або plain string
              const text = await response.text();
              console.error('Error registering drone:', text);
            }
          } catch (error) {
            console.error('Error registering drone:', error);
          }
        }
      };

    return (
        <div className="register-drone">
            <h2>{selectedDrone ? 'Edit Drone' : 'Register New Drone'}</h2>
            <form onSubmit={handleSubmit}>
                <DroneFormField label="Drone Name" value={droneName} onChange={setDroneName} />
                <DroneFormField label="Drone Type" value={droneType} onChange={setDroneType} />
                <DroneFormField label="Safety Code" value={safetyCode} onChange={setSafetyCode} disabled={!!selectedDrone} />
                <button type="submit">{selectedDrone ? 'Update Drone' : 'Register Drone'}</button>
            </form>
        </div>
    );
}

export default RegisterDrone;