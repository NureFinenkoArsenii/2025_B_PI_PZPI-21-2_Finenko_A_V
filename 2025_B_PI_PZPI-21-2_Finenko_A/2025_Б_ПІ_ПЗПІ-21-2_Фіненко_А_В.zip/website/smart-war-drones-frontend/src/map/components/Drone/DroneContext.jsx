import React, { createContext, useState, useEffect } from 'react';
import { fetchWithAuth } from '../../../utils/tokenManager';
import {
    generateRandomBytes,
    encryptJsonWithAES_forPassword,
    encryptAESKeyWithRSA_forPassword,
    decryptWithAES_fromResponse,
  } from "../../../utils/passwordCrypto";
export const DroneContext = createContext();

export function DroneProvider({ children }) {
    const [drones, setDrones] = useState([]);
    const [selectedDrone, setSelectedDrone] = useState(null);
    const [mapState, setMapState] = useState(() => {
        // Ініціалізуємо стан карти з localStorage або використовуємо значення за замовчуванням
        const savedMapState = JSON.parse(localStorage.getItem('mapState'));
        return savedMapState || {
            center: [48.3794, 31.1656],
            zoom: 6,
        };
    });


    async function fetchEncryptedDrones() {
        // 1. Отримати публічний RSA-ключ
        const publicKeyRes = await fetchWithAuth("/api/map/test-drone/public-key");
        const base64 = await publicKeyRes.text();
      
        // 2. Сформувати PEM
        const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
          .match(/.{1,64}/g)
          .join("\n")}\n-----END PUBLIC KEY-----`;
      
        // 3. Згенерувати AES-ключ та IV
        const aesKey = generateRandomBytes(16); // Uint8Array[16]
        const ivBytes = generateRandomBytes(16);
      
        // 4. Зашифрувати payload (у нашому випадку – {})
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword({}, aesKey, ivBytes);
      
        // 5. Зашифрувати AES-ключ RSA публічним ключем
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
      
        // 6. Відправити зашифроване тіло на бекенд
        const response = await fetchWithAuth("/api/map/test-drone/getAll", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
        });
      
        // 7. Отримати зашифровану відповідь
        const encryptedResponse = await response.json(); // { iv, ciphertext }
      
        // 8. Розшифрувати на фронті
        const drones = decryptWithAES_fromResponse(encryptedResponse, aesKey);
        const normalizeDrone = d => ({
            id: d.id || d.Id,
            droneName: d.droneName || d.DroneName,
            droneType: d.droneType || d.DroneType,
        });
        
        const rawDrones = drones.map(normalizeDrone);
        return rawDrones;
      }

      useEffect(() => {
        async function fetchDrones() {
            try {
                const drones = await fetchEncryptedDrones();
            
                setDrones(data);
            } catch (err) {
        }
    }
        fetchDrones();
    }, []);

    const saveMapState = (newState) => {
        setMapState(newState);
        localStorage.setItem('mapState', JSON.stringify(newState));
    };

    const selectDrone = (drone) => setSelectedDrone(drone);
    const addDrone = (drone) => setDrones([...drones, drone]);
    const updateDrone = (updatedDrone) => {
        setDrones(drones.map(drone => drone.id === updatedDrone.id ? updatedDrone : drone));
    };
    const deleteDrone = (droneName) => {
        setDrones(drones.filter(drone => drone.droneName !== droneName));
    };

    return (
        <DroneContext.Provider value={{
            drones,
            selectedDrone,
            selectDrone,
            addDrone,
            updateDrone,
            deleteDrone,
            mapState,
            saveMapState
        }}>
            {children}
        </DroneContext.Provider>
    );
}