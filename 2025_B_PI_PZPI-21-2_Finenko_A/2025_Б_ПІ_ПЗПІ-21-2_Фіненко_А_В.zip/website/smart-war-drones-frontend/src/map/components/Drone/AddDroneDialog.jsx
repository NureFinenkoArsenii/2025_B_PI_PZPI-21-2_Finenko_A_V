import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import '../../../styles/map/Drone/AddDroneDialog.scss';
import ErrorDialog from './ErrorDialog';
import { fetchWithAuth } from '../../../utils/tokenManager';
import {
    generateRandomBytes,
    encryptJsonWithAES_forPassword,
    encryptAESKeyWithRSA_forPassword,
    decryptWithAES_fromResponse,
  } from "../../../utils/passwordCrypto";

function AddDroneDialog({ onClose, onAddDrone }) {
    const { t } = useTranslation(); // Ініціалізація перекладу
    const [droneName, setDroneName] = useState('');
    const [droneType, setDroneType] = useState('');
    const [safetyCode, setSafetyCode] = useState('');
    const [error, setError] = useState(null);
    const [warning, setWarning] = useState(null);
    const [suggestions, setSuggestions] = useState([]);
    const [allTypes, setAllTypes] = useState([]);
    const [isFocused, setIsFocused] = useState(false);
    const [selectedIndex, setSelectedIndex] = useState(-1);
    const suggestionsRef = useRef(null);
    const dialogRef = useRef(null);

    async function fetchEncryptedDrones() {
        // 1. Отримати публічний RSA-ключ
        const publicKeyRes = await fetchWithAuth("/api/map/test-drone/public-key");
        const base64 = await publicKeyRes.text();
      
        // 2. Сформувати PEM
        const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
          .match(/.{1,64}/g)
          .join("\n")}\n-----END PUBLIC KEY-----`;
      
        // 3. Згенерувати AES-ключ та IV
        const aesKey = generateRandomBytes(16); // Uint8Array[16]
        const ivBytes = generateRandomBytes(16);
      
        // 4. Зашифрувати payload (у нашому випадку – {})
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword({}, aesKey, ivBytes);
      
        // 5. Зашифрувати AES-ключ RSA публічним ключем
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
      
        // 6. Відправити зашифроване тіло на бекенд
        const response = await fetchWithAuth("/api/map/test-drone/getAll", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
        });
      
        // 7. Отримати зашифровану відповідь
        const encryptedResponse = await response.json(); // { iv, ciphertext }
      
        // 8. Розшифрувати на фронті
        const drones = decryptWithAES_fromResponse(encryptedResponse, aesKey);
        const normalizeDrone = d => ({
            id: d.id || d.Id,
            droneName: d.droneName || d.DroneName,
            droneType: d.droneType || d.DroneType,
        });
        
        const rawDrones = drones.map(normalizeDrone);
        return rawDrones;
      }

    useEffect(() => {
        const fetchDroneTypes = async () => {
            try {
                const drones = await fetchEncryptedDrones();
                const types = [...new Set(drones.map(drone => drone.droneType))];
                setAllTypes(types);
            } catch (error) {
                console.error(t('fetch_drone_types_error'), error);
            }
        };

        fetchDroneTypes();
    }, [t]);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (
                dialogRef.current && 
                !dialogRef.current.contains(e.target) && 
                (!suggestionsRef.current || !suggestionsRef.current.contains(e.target)) && 
                !error
            ) {
                onClose();
            }
        };
    
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [onClose, error]);

    const handleSuggestionClick = (suggestion, event) => {
        if (event) {
            event.stopPropagation();
        }
        setDroneType(suggestion);
        setSuggestions([]);
        setIsFocused(false);
    };

    const handleTypeChange = (e) => {
        const value = e.target.value;
        setDroneType(value);

        const filteredSuggestions = allTypes.filter(type => 
            type.toLowerCase().startsWith(value.toLowerCase())
        );

        setSuggestions(filteredSuggestions);
        setIsFocused(true);
        setSelectedIndex(-1);
    };

    const handleFocus = () => {
        setIsFocused(true);
    };

    const handleBlur = (e) => {
        if (suggestionsRef.current && !suggestionsRef.current.contains(e.relatedTarget)) {
            setIsFocused(false);
        }
    };

    const handleKeyDown = (e) => {
        if (suggestions.length > 0) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedIndex(prevIndex => 
                    prevIndex < suggestions.length - 1 ? prevIndex + 1 : prevIndex
                );
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedIndex(prevIndex => (prevIndex > 0 ? prevIndex - 1 : prevIndex));
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (selectedIndex >= 0 && selectedIndex < suggestions.length) {
                    setDroneType(suggestions[selectedIndex]);
                    setSuggestions([]);
                    setIsFocused(false);
                }
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        if (safetyCode.length !== 13) {
            setError(t('safety_code_length_error'));
            return;
        }
    
        const payload = {
            droneName,
            droneType,
            safetyCode,
        };
    
        try {
            // 1. Запит на RSA-публічний ключ
            const publicKeyRes = await fetchWithAuth("/api/map/test-drone/public-key");
            const base64 = await publicKeyRes.text();
            const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
    
            // 2. Генерація AES-ключа та IV
            const aesKey = generateRandomBytes(16);
            const ivBytes = generateRandomBytes(16);
    
            // 3. AES-шифрування JSON payload
            const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, ivBytes);
    
            // 4. Шифруємо AES-ключ через RSA-публічний
            const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
    
            // 5. POST encrypted
            const response = await fetchWithAuth('/api/map/test-drone/register', {
                method: 'POST',
                body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
                headers: { "Content-Type": "application/json" }
            });
    
            // 6. Опціонально — якщо відповідь теж зашифрована, дешифруємо її тут (аналогічно getAll)
            if (response.ok) {
                // Якщо повертається просто TestDroneResponseModel — обробляй як plaintext:
                const data = await response.json();
                onAddDrone(data);
                onClose();
            } else {
                const errorData = await response.json();
                setError(errorData.Error || t('register_drone_fail'));
            }
        } catch (error) {
            console.error(t('register_drone_error'), error);
            setError(t('register_drone_fail'));
        }
    };

    const handleBackdropClick = (e) => {
        if (e.target === e.currentTarget && !error) {
            onClose();
        }
    };

    const closeErrorDialog = () => {
        setError(null);
    };

    const closeWarningDialog = () => {
        setWarning(null);
    };

    return (
        <>
            <div className="dialog-backdrop" onClick={handleBackdropClick}>
                <div className="dialog" ref={dialogRef}>
                    <h2>{t('add_new_drone')}</h2>
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label>{t('drone_name')}:</label>
                            <input
                                type="text"
                                value={droneName}
                                onChange={(e) => setDroneName(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>{t('drone_type')}:</label>
                            <input
                                type="text"
                                value={droneType}
                                onChange={handleTypeChange}
                                onFocus={handleFocus}
                                onBlur={handleBlur}
                                onKeyDown={handleKeyDown}
                                required
                            />
                            {isFocused && suggestions.length > 0 && (
                                <div className="suggestions" ref={suggestionsRef}>
                                    {suggestions.map((suggestion, index) => (
                                        <div
                                            key={index}
                                            onMouseDown={(event) => handleSuggestionClick(suggestion, event)}
                                            className={`suggestion-item ${index === selectedIndex ? 'selected' : ''}`}
                                        >
                                            {suggestion}
                                        </div>
                                    ))}
                                </div>
                            )}
                            <div className="static-suggestions">
                                <div onClick={() => handleSuggestionClick('attack')}>{t('attack_drone')}</div>
                                <div onClick={() => handleSuggestionClick('transport')}>{t('transport_drone')}</div>
                                <div onClick={() => handleSuggestionClick('scout')}>{t('scout_drone')}</div>
                            </div>
                        </div>
                        <div className="form-group">
                            <label>{t('safety_code')}:</label>
                            <input
                                type="text"
                                value={safetyCode}
                                onChange={(e) => setSafetyCode(e.target.value)}
                                required
                                maxLength={13}
                            />
                        </div>
                        <div className="dialog-actions">
                            <button type="submit" className="add-button">{t('add_drone')}</button>
                            <button type="button" className="cancel-button" onClick={onClose}>{t('cancel')}</button>
                        </div>
                    </form>
                </div>
            </div>
            {error && (
                <ErrorDialog
                    message={error}
                    onClose={closeErrorDialog}
                />
            )}
            {warning && (
                <WarningDialog
                    message={warning}
                    onClose={closeWarningDialog}
                />
            )}
        </>
    );
}

export default AddDroneDialog;