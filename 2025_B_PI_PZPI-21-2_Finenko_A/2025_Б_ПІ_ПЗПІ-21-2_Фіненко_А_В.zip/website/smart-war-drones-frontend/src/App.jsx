import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./layout/Layout";
import Home from "./pages/Home";
import MobileApp from "./pages/MobileApp";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Workplace from "./pages/Workplace";
import ProtectedRoute from "./components/ProtectedRoute";
import ProfileView from "./pages/ProfileView";
import Map from "./map/Map";
import Battlefield from "./battlefields/Battlefield";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/mobile" element={<MobileApp />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Route>
        <Route
          path="/workplace"
          element={
            <ProtectedRoute>
              <Workplace />
            </ProtectedRoute>
          }
        />
        <Route 
          path="/workplace/profile" 
          element={
          <ProtectedRoute>
            <ProfileView />
            </ProtectedRoute>
          } 
        />
        <Route
          path="/workplace/messages"
          element={
            <ProtectedRoute>
              <Workplace mode="messages" />
            </ProtectedRoute>
          }
        />
        <Route
          path="/workplace/map"
          element={
            <ProtectedRoute>
              <Map />
            </ProtectedRoute>
          }
        />
        <Route
          path="/workplace/battlefield/:id"
          element={
            <ProtectedRoute>
              <Battlefield />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
