import React, { useEffect, useRef } from "react";
import "../../battlefieldStyles/Chat/ConfirmClearChatModal.scss"; // або свій стиль

export default function ConfirmClearChatModal({ open, onClose, onClear }) {
  const modalRef = useRef();

  useEffect(() => {
    if (!open) return;
    function onKeyDown(e) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  // Закриття по кліку поза вікном
  function onBackdrop(e) {
    if (modalRef.current && !modalRef.current.contains(e.target)) onClose();
  }

  if (!open) return null;
  return (
    <div className="clear-modal-backdrop" onMouseDown={onBackdrop}>
      <div className="clear-modal-box" ref={modalRef}>
        <div className="clear-modal-title">Are you sure you want to clear the chat's history?</div>
        <div className="clear-modal-actions">
          <button className="clear-modal-clear-btn" onClick={onClear}>Clear All</button>
          <button className="clear-modal-cancel-btn" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
