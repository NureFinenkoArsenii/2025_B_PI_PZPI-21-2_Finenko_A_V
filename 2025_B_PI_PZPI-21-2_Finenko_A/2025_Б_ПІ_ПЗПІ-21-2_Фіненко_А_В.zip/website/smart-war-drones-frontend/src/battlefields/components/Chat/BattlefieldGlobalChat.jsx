import React, { useState, useRef, useEffect } from "react";
import "../../battlefieldStyles/Chat/BattlefieldGlobalChat.scss";
import JSEncrypt from "jsencrypt";
import CryptoJS from "crypto-js";
import { fetchWithAuth, getUserIdFromToken } from "../../../utils/tokenManager";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
} from "../../../utils/passwordCrypto";
import ConfirmClearChatModal from "./ConfirmClearChatModal";


function formatDate(dateStr) {
  try {
    const d = new Date(dateStr);
    if (isNaN(d)) return "";
    return d.toLocaleString("uk-UA", {
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
    });
  } catch {
    return "";
  }
}

const myUserId = getUserIdFromToken();

export default function BattlefieldGlobalChat({ battlefieldId }) {
  const [collapsed, setCollapsed] = useState(false);
  const [message, setMessage] = useState("");
  const [height, setHeight] = useState(300);
  const [isResizing, setIsResizing] = useState(false);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  const [sending, setSending] = useState(false);
  const [sidebar, setSidebar] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const [isOwnerChecked, setIsOwnerChecked] = useState(false);
  const messagesEndRef = useRef(null);
  const startY = useRef(null);
  const startHeight = useRef(null);
  const myUserId = getUserIdFromToken();

  // Кеш для blob-URL кастомних аватарок
  const customAvatarCache = useRef({});

  // --- Автоскрол ---
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, height]);

  useEffect(() => {
    if (!battlefieldId) return;
    (async () => {
      try {
        // 1. Отримати публічний ключ (battlefields)
        const pubKeyRes = await fetchWithAuth("/api/battlefields/public-key");
        if (!pubKeyRes.ok) throw new Error("Failed to fetch public key");
        const pubKey = await pubKeyRes.text();

        // 2. Зашифрувати payload
        const sessionAesKey = generateRandomBytes(16);
        const sessionIv = generateRandomBytes(16);
        const payload = { battlefieldId };
        console.log("[ClearChat][FRONT] battlefieldId:", battlefieldId);
        const { ciphertext: encPayload, iv: encIv } = encryptJsonWithAES_forPassword(payload, sessionAesKey, sessionIv);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, pubKey);
        console.log("[ClearChat][FRONT] Encrypted payload: ", {
          encryptedKey,
          iv: encIv,
          ciphertext: encPayload
        });
    
        // 3. Запит на is-owner
        const res = await fetchWithAuth("/api/battlefields/is-owner", {
          method: "POST",
          body: JSON.stringify({
            encryptedKey,
            iv: encIv,
            ciphertext: encPayload,
          }),
        });
        if (!res.ok) throw new Error("Failed to check owner");

        // 4. Дешифрувати відповідь
        const respJson = await res.json();
        const ivWA = CryptoJS.enc.Base64.parse(respJson.iv);
        const keyWA = CryptoJS.lib.WordArray.create(sessionAesKey);
        const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, keyWA, {
          iv: ivWA,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const json = decrypted.toString(CryptoJS.enc.Utf8);
        const { isOwner } = JSON.parse(json);
        setIsOwner(isOwner);
        setIsOwnerChecked(true);
      } catch (err) {
        setIsOwner(false);
        setIsOwnerChecked(true);
        alert("Failed to clear chat: " + err?.message);
        // optionally log error
      }
    })();
  }, [battlefieldId]);

  // --- Завантаження повідомлень ---
  useEffect(() => {
    if (!battlefieldId) return;
    fetchMessages();
    // eslint-disable-next-line
  }, [battlefieldId]);

  // --- Sidebar animation ---
  useEffect(() => {
    if (!collapsed) {
      setSidebar(true);
    } else {
      setTimeout(() => setSidebar(false), 250);
    }
  }, [collapsed]);

  // --- Завантажити всі повідомлення та підвантажити кастомні аватарки ---
  async function fetchMessages() {
    setLoading(true);
    try {
      // 1. Публічний ключ
      const pubKeyRes = await fetchWithAuth("/api/global-chat/public-key");
      if (!pubKeyRes.ok) throw new Error("Failed to fetch public key");
      const globalChatPubKey = await pubKeyRes.text();

      // 2. Генерація AES-ключа, формування payload
      const sessionAesKey = generateRandomBytes(16);
      const sessionIv = generateRandomBytes(16);
      const payload = { battlefieldId };
      const { ciphertext: encPayload, iv: encIv } = encryptJsonWithAES_forPassword(payload, sessionAesKey, sessionIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, globalChatPubKey);

      const getMessagesBody = {
        encryptedKey,
        iv: encIv,
        ciphertext: encPayload,
      };

      const res = await fetchWithAuth("/api/global-chat/get-messages", {
        method: "POST",
        body: JSON.stringify(getMessagesBody),
      });

      if (!res.ok) throw new Error("Failed to load messages: " + (await res.text()));

      const resJson = await res.json();

      // Дешифрування масиву повідомлень
      const keyWA = CryptoJS.lib.WordArray.create(sessionAesKey);
      const ivWA = CryptoJS.enc.Base64.parse(resJson.iv);
      const decrypted = CryptoJS.AES.decrypt(resJson.ciphertext, keyWA, {
        iv: ivWA,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const arrStr = decrypted.toString(CryptoJS.enc.Utf8);
      let messagesArr = JSON.parse(arrStr);

      // --- Підвантаження кастомних аватарок для тих, в кого avatarType==="custom" (і не своє) ---
      messagesArr = await Promise.all(
        messagesArr.map(async (msg) => {
          if (
            msg.senderAvatarType === "custom" &&
            msg.senderId !== myUserId &&
            !msg.senderAvatarUrl &&
            msg.senderId
          ) {
            // кешована?
            if (customAvatarCache.current[msg.senderId]) {
              return { ...msg, senderAvatarUrl: customAvatarCache.current[msg.senderId] };
            }
            try {
              const token = localStorage.getItem("jwt");
              const fileRes = await fetch(`/api/profile/avatar-file/${msg.senderId}`, {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (!fileRes.ok) throw new Error("Cannot get avatar file");
              const fileBuffer = await fileRes.arrayBuffer();

              // Публічний ключ для AES (id користувача)
              const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
              const rsaKeyBase64 = await rsaKeyRes.text();
              const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

              const sessionAesKey = generateRandomBytes(16);
              const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
              const encryptor = new JSEncrypt();
              encryptor.setPublicKey(rsaKeyPem);
              const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

              // Запит на AES-ключ файлу
              const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${msg.senderId}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ encryptedSessionAesKey }),
              });
              const { iv, ciphertext } = await resp.json();

              const keyBytes = sessionAesKey;
              const ivWord = CryptoJS.enc.Base64.parse(iv);
              const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
                iv: ivWord,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7,
              });

              const avatarAesKeyBytes = Uint8Array.from(
                decrypted.words.flatMap(w => [
                  (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
                ]).slice(0, decrypted.sigBytes)
              );

              const fileBytes = new Uint8Array(fileBuffer);
              const fileIv = fileBytes.slice(0, 16);
              const fileCipher = fileBytes.slice(16);

              const decWord = CryptoJS.AES.decrypt(
                { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
                CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
                {
                  iv: CryptoJS.lib.WordArray.create(fileIv),
                  mode: CryptoJS.mode.CBC,
                  padding: CryptoJS.pad.Pkcs7,
                }
              );

              const uint8Decrypted = Uint8Array.from(
                decWord.words.flatMap(w => [
                  (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
                ]).slice(0, decWord.sigBytes)
              );

              const blob = new Blob([uint8Decrypted], { type: "image/png" });
              const url = URL.createObjectURL(blob);
              customAvatarCache.current[msg.senderId] = url;
              return { ...msg, senderAvatarUrl: url };
            } catch (err) {
              console.error("❌ Failed to fetch/decrypt custom avatar (msg):", err);
              return msg;
            }
          } else {
            return msg;
          }
        })
      );

      setMessages(messagesArr);
    } catch (e) {
      setMessages([]);
      console.error("[GlobalChat] Failed to fetch messages", e);
    }
    setLoading(false);
  }

  async function handleClearChat() {
    try {
      // Ключ для global chat
      const pubKeyRes = await fetchWithAuth("/api/global-chat/public-key");
      if (!pubKeyRes.ok) throw new Error("Failed to fetch public key");
      const globalChatPubKey = await pubKeyRes.text();
  
      const sessionAesKey = generateRandomBytes(16);
      const sessionIv = generateRandomBytes(16);
  
      const payload = { battlefieldId }; // важливо!
      const { ciphertext: encPayload, iv: encIv } = encryptJsonWithAES_forPassword(payload, sessionAesKey, sessionIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, globalChatPubKey);
  
      const body = {
        encryptedKey,
        iv: encIv,
        ciphertext: encPayload,
      };
  
      const res = await fetchWithAuth("/api/global-chat/clear-chat", {
        method: "POST",
        body: JSON.stringify(body),
      });
  
      if (!res.ok) throw new Error(await res.text());
  
      // Дешифрування відповіді
      const respJson = await res.json();
      const ivResp = CryptoJS.enc.Base64.parse(respJson.iv);
      const keyWA = CryptoJS.lib.WordArray.create(sessionAesKey);
      const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, keyWA, {
        iv: ivResp,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const json = decrypted.toString(CryptoJS.enc.Utf8);
      const resp = JSON.parse(json);
      if (resp.cleared) {
        setShowClearModal(false);
        fetchMessages();
      } else {
        alert("Failed to clear chat.");
      }
    } catch (err) {
      alert("Failed to clear chat: " + err?.message);
    }
  }
  

  // --- Відправка нового повідомлення ---
  async function handleSendGlobalMessage() {
    if (!message.trim() || !battlefieldId) return;
    setSending(true);

    try {
      const pubKeyRes = await fetchWithAuth("/api/global-chat/public-key");
      if (!pubKeyRes.ok) throw new Error("Failed to fetch public key");
      const globalChatPubKey = await pubKeyRes.text();

      const sessionAesKey = generateRandomBytes(16);
      const sessionIv = generateRandomBytes(16);
      const encryptedBattlefieldId = battlefieldId;
      const secretPayload = { encryptedBattlefieldId };
      const { ciphertext: encPayload, iv: encIv } = encryptJsonWithAES_forPassword(secretPayload, sessionAesKey, sessionIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, globalChatPubKey);

      const getSecretReqBody = {
        encryptedKey,
        iv: encIv,
        ciphertext: encPayload,
      };

      const secretRes = await fetchWithAuth("/api/global-chat/get-shared-secret", {
        method: "POST",
        body: JSON.stringify(getSecretReqBody),
      });
      if (!secretRes.ok) throw new Error("Failed to get shared secret: " + (await secretRes.text()));

      const secretResJson = await secretRes.json();

      const keyWordArray = CryptoJS.lib.WordArray.create(sessionAesKey);
      const ivWordArray = CryptoJS.enc.Base64.parse(secretResJson.iv);
      const decrypted = CryptoJS.AES.decrypt(secretResJson.ciphertext, keyWordArray, {
        iv: ivWordArray,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const respStr = decrypted.toString(CryptoJS.enc.Utf8);
      const respObj = JSON.parse(respStr);
      const sharedSecretBase64 = respObj.sharedSecret;
      const sharedSecret = Uint8Array.from(atob(sharedSecretBase64), (c) => c.charCodeAt(0));

      const ivMsg = generateRandomBytes(16);
      const senderId = getUserIdFromToken();
      const now = new Date().toISOString();

      function aesEncryptField(val, key, iv) {
        let str = typeof val === "string" ? val : JSON.stringify(val);
        const keyWA = CryptoJS.lib.WordArray.create(key);
        const ivWA = CryptoJS.lib.WordArray.create(iv);
        const encrypted = CryptoJS.AES.encrypt(str, keyWA, {
          iv: ivWA,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
      }

      const msgObj = {
        senderId: aesEncryptField(senderId, sharedSecret, ivMsg),
        ciphertext: aesEncryptField(message, sharedSecret, ivMsg),
        iv: CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(ivMsg)),
        createdAt: aesEncryptField(now, sharedSecret, ivMsg),
        isEdited: aesEncryptField(false, sharedSecret, ivMsg),
        replyId: aesEncryptField(null, sharedSecret, ivMsg),
        whoChecked: aesEncryptField([], sharedSecret, ivMsg),
        attachments: aesEncryptField([], sharedSecret, ivMsg),
        encryptedBattlefieldId,
      };

      const packetAesKey = generateRandomBytes(16);
      const packetIv = generateRandomBytes(16);
      const msgObjStr = JSON.stringify(msgObj);
      const packetKeyWA = CryptoJS.lib.WordArray.create(packetAesKey);
      const packetIvWA = CryptoJS.lib.WordArray.create(packetIv);
      const msgObjEnc = CryptoJS.AES.encrypt(msgObjStr, packetKeyWA, {
        iv: packetIvWA,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const encryptedPacketKey = encryptAESKeyWithRSA_forPassword(packetAesKey, globalChatPubKey);

      const sendBody = {
        encryptedKey: encryptedPacketKey,
        iv: CryptoJS.enc.Base64.stringify(packetIvWA),
        ciphertext: msgObjEnc.toString(),
      };

      const sendRes = await fetchWithAuth("/api/global-chat/send", {
        method: "POST",
        body: JSON.stringify(sendBody),
      });

      if (!sendRes.ok) throw new Error(await sendRes.text());

      setMessage("");
      fetchMessages();
    } catch (e) {
      alert(e.message);
    }
    setSending(false);
  }

  // --- UI ---
  const renderMsg = (msg, idx) => {
    const isMine = msg.senderId === myUserId;
    return (
      <div
    key={msg.id}
    className={`bgc-message-row ${isMine ? "mine" : "theirs"}`}
  >

        {/* Аватарка лише якщо чуже повідомлення */}
        {!isMine && (
          <div className="bgc-avatar-box">
            {msg.senderAvatarType === "default" && msg.senderAvatarUrl && (
              <img className="bgc-avatar-img" src={msg.senderAvatarUrl} alt="Avatar" />
            )}
            {msg.senderAvatarType === "custom" && msg.senderAvatarUrl && (
              <img className="bgc-avatar-img" src={msg.senderAvatarUrl} alt="Custom avatar" />
            )}
            {msg.senderAvatarType === "custom" && !msg.senderAvatarUrl && (
              <div className="bgc-avatar-placeholder">
                <span>🛡️</span>
              </div>
            )}
          </div>
        )}
        <div className="bgc-message-bubble">
          {/* Інфо про відправника */}
          {!isMine && (
            <div className="bgc-message-meta">
              <span className="bgc-message-name">{msg.senderName}</span>
              <span className="bgc-message-role">{msg.senderRole}</span>
            </div>
          )}
          <div className="bgc-message-content">{msg.message}</div>
          <div className="bgc-message-date">
            {formatDate(msg.createdAt)}
          </div>
        </div>
      </div>
    );
  };
  

  React.useEffect(() => {
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    } else {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
    // eslint-disable-next-line
  }, [isResizing]);

  function handleMouseDown(e) {
    setIsResizing(true);
    startY.current = e.clientY;
    startHeight.current = height;
    document.body.style.cursor = "ns-resize";
  }
  function handleMouseMove(e) {
    if (!isResizing) return;
    const delta = startY.current - e.clientY;
    let newHeight = Math.max(120, Math.min(500, startHeight.current + delta));
    setHeight(newHeight);
  }
  function handleMouseUp() {
    setIsResizing(false);
    document.body.style.cursor = "";
  }

  // --- Sidebar анімація ---
  return (
    <div className={`battlefield-global-chat${collapsed ? " collapsed" : ""}${sidebar ? " with-sidebar" : ""}`}
       style={!collapsed ? { height: `${height}px` } : {}}>
    <div className="bgc-header">
      <span className="bgc-title">Global Chat</span>

      {/* КНОПКА ВИДАЛЕННЯ — тільки для власника, тільки якщо перевірка завершена */}
      {isOwnerChecked && isOwner && (
        <button
          className="bgc-clear-btn"
          title="Clear chat"
          onClick={e => {
            e.stopPropagation();
            setShowClearModal(true);
          }}
          style={{ marginRight: "5px", marginTop: "4px", background: "none", border: "none", cursor: "pointer" }}
        >
          <img src="/icons/deleteBattlefieldIcon.png" alt="Clear chat" style={{ width: 28, height: 28 }} />
        </button>
      )}

      <button className="bgc-collapse-btn" tabIndex={-1} onClick={() => setCollapsed(v => !v)}>
        {collapsed ? <>&#9650;</> : <>&#9660;</>}
      </button>
    </div>
      {!collapsed && (
        <>
          <div className="bgc-resizer" onMouseDown={handleMouseDown} title="Resize"></div>
          <div className="bgc-body" style={{ height: height - 100 }}>
          <div className="bgc-messages-list" style={{ overflowY: "auto", height: "100%", padding: "14px 10px 12px 10px" }}>
              {loading ? (
                <div className="bgc-messages-placeholder"><span>Loading…</span></div>
              ) : messages.length === 0 ? (
                <div className="bgc-messages-placeholder"><span>No messages yet.</span></div>
              ) : (
                messages.map(renderMsg)
              )}
              <div ref={messagesEndRef} />
            </div>
            <div className="bgc-input-row">
              <label className="bgc-file-label">
                <input type="file" style={{ display: "none" }} disabled />
              </label>
              <input
                type="text"
                className="bgc-input"
                placeholder="Type your message…"
                value={message}
                onChange={e => setMessage(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter" && !sending) handleSendGlobalMessage();
                }}
                disabled={sending}
              />
              <button className="bgc-send-btn" onClick={handleSendGlobalMessage} disabled={sending}>
                {sending ? "..." : "Send"}
              </button>
            </div>
          </div>
        </>
      )}
      {/* Sidebar ефект */}
      <div className={`bgc-sidebar${sidebar ? " show" : ""}`} />
      <ConfirmClearChatModal
        open={showClearModal}
        onClose={() => setShowClearModal(false)}
        onClear={handleClearChat}
      />
    </div>
  );
}
