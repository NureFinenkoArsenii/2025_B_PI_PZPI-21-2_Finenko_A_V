import { useEffect, useRef } from "react";
import "../../battlefieldStyles/InteractionColumn/_kickMemberConfirmModal.scss";

export default function KickMemberConfirmModal({ open, member, onKick, onCancel }) {
  const modalRef = useRef();

  // Закриття по Esc чи кліку поза модалкою
  useEffect(() => {
    if (!open) return;

    const onKeyDown = (e) => {
      if (e.key === "Escape") onCancel();
    };
    const onClick = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) onCancel();
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("mousedown", onClick);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("mousedown", onClick);
    };
  }, [open, onCancel]);

  if (!open) return null;
  return (
    <div className="kick-member-overlay">
      <div className="kick-member-modal" ref={modalRef}>
        <div className="kick-member-title">Are you sure you want to kick {member?.name}?</div>
        <div className="kick-member-actions">
          <button className="kick-btn" onClick={onKick}>Kick</button>
          <button className="cancel-btn" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
