import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import ReactDOM from "react-dom";
import AnimatedHeightWrapper from "../../../components/AnimatedHeightWrapper";
import "../../battlefieldStyles/InteractionColumn/_battlefieldMembersModal.scss";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
  bytesToWordArray,
} from "../../../utils/passwordCrypto";
import CryptoJS from "crypto-js";
import { fetchWithAuth } from "../../../utils/tokenManager";
import KickMemberConfirmModal from "./KickMemberConfirmModal";

// --- Довжина ідентифікатора
const IDENTIFIER_LENGTH = 6;

export default function BattlefieldMembersModal({ open, onClose, battlefieldId }) {
  // --- Основний режим модалки
  const [mode, setMode] = useState("view"); // view | add
  const [searchQuery, setSearchQuery] = useState("");
  const [members, setMembers] = useState([]);
  const [customAvatars, setCustomAvatars] = useState({});
  const [isOwner, setIsOwner] = useState(false);
  const [ownerChecked, setOwnerChecked] = useState(false);
  const [loadingMembers, setLoadingMembers] = useState(true);
  const modalRef = useRef();
  const memberIds = useMemo(() => new Set(members.map(m => m.id)), [members]);
  const [requestsExist, setRequestsExist] = useState({});
  const [kickModalOpen, setKickModalOpen] = useState(false);
  const [kickMember, setKickMember] = useState(null);


  // --- Додавання нового учасника (Add New Member)
  const [identifier, setIdentifier] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | found | error
  const [foundUser, setFoundUser] = useState(null);
  const [customAvatarUrl, setCustomAvatarUrl] = useState(null);
  const [addSearchQuery, setAddSearchQuery] = useState("");
  const [friends, setFriends] = useState([]);
  const [friendsAvatars, setFriendsAvatars] = useState({});
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [blockedList, setBlockedList] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [sending, setSending] = useState(false);
  const [sendResult, setSendResult] = useState("");


  // --- Скидання станів при закритті або режимі
  useEffect(() => {
    if (!open) {
      setMode("view");
      setSearchQuery("");
      setMembers([]);
      setCustomAvatars({});
      setIsOwner(false);
      setOwnerChecked(false);
      setLoadingMembers(true);

      setIdentifier("");
      setStatus("idle");
      setFoundUser(null);
      setCustomAvatarUrl(null);
      setAddSearchQuery("");
      setFriends([]);
      setFriendsAvatars({});
      setLoadingFriends(false);
      setBlockedList([]);
      setSelectedIds([]);
      setSendResult("");
      setSending(false);
    }
  }, [open]);

  // --- Зміна режиму з очищенням полів
  const handleSetMode = useCallback((m) => {
    setMode(m);
    setIdentifier("");
    setStatus("idle");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setAddSearchQuery("");
    setSelectedIds([]);
    setSendResult("");
    setSending(false);
  }, []);

  // --- Перевірка власника
  useEffect(() => {
    let ignore = false;
    setOwnerChecked(false);
    setIsOwner(false);
    if (!open || !battlefieldId) return;
    (async () => {
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { battlefieldId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      const resp = await fetchWithAuth("/api/battlefields/is-owner", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
      if (!resp.ok) return;
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      let data = null;
      try { data = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8)); } catch {}
      if (!ignore) {
        setIsOwner(!!(data && data.isOwner));
        setOwnerChecked(true);
      }
    })();
    return () => { ignore = true; };
  }, [open, battlefieldId]);

  // --- Завантаження учасників напрямку
  useEffect(() => {
    if (!open || !battlefieldId || mode !== "view") return;
    let ignore = false;
    setMembers([]);
    setCustomAvatars({});
    setLoadingMembers(true);

    (async () => {
      try {
        const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
        const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);

        const payload = { battlefieldId };
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

        const resp = await fetchWithAuth("/api/battlefields/members", {
          method: "POST",
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
        });
        if (!resp.ok) throw new Error("Failed to fetch members");
        const result = await resp.json();
        const ivData = CryptoJS.enc.Base64.parse(result.iv);
        const key = bytesToWordArray(aesKey);
        const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
          iv: ivData,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        let data = null;
        try { data = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8)); } catch {}
        if (Array.isArray(data)) {
          const avatars = {};
          await Promise.all(data.map(async member => {
            if (member.avatarType === "custom" && member.id && !avatars[member.id]) {
              const url = await fetchAndDecryptCustomAvatar(member.id);
              if (url) avatars[member.id] = url;
            }
          }));
          if (!ignore) {
            setCustomAvatars(avatars);
            setMembers(data);
            setLoadingMembers(false);
          }
        } else {
          if (!ignore) {
            setMembers([]);
            setLoadingMembers(false);
          }
        }
      } catch (err) {
        if (!ignore) {
          setMembers([]);
          setLoadingMembers(false);
        }
      }
    })();

    return () => { ignore = true; };
  }, [open, battlefieldId, mode]);

  // --- Завантаження друзів для add mode
  useEffect(() => {
    if (!open || mode !== "add") return;
    setLoadingFriends(true);
    setFriends([]);
    setFriendsAvatars({});
    setBlockedList([]);
    (async () => {
      // Завантажити друзів
      try {
        const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
        const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
        const dummyPayload = { dummy: true };
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

        const resp = await fetchWithAuth("/api/contacts/friends", {
          method: "POST",
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
        });
        const result = await resp.json();
        const ivData = CryptoJS.enc.Base64.parse(result.iv);
        const key = bytesToWordArray(aesKey);
        const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
          iv: ivData,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const data = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
        setFriends(data);
        const checkRequests = async () => {
            const results = {};
            await Promise.all(
              data.map(async f => {
                if (f && f.id) {
                  results[f.id] = await checkIfJoinRequestExists(f.id);
                }
              })
            );
            setRequestsExist(results);
          };
          checkRequests();
        setLoadingFriends(false);

        data.forEach(f => {
          if (f.avatarType === "custom" && !f.avatarUrl && f.id) {
            fetchAndDecryptCustomAvatar(f.id).then(url => {
              setFriendsAvatars(prev => ({ ...prev, [f.id]: url }));
            });
          }
        });
      } catch (err) {
        setFriends([]);
        setLoadingFriends(false);
      }

      // Blocked list
      try {
        const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
        const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
        const dummyPayload = { dummy: true };
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

        const resp = await fetchWithAuth("/api/contacts/blocked", {
          method: "POST",
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
        });
        const result = await resp.json();
        const ivData = CryptoJS.enc.Base64.parse(result.iv);
        const key = bytesToWordArray(aesKey);
        const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
          iv: ivData,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const blocked = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
        setBlockedList(blocked.map(b => String(b.id)));
      } catch (err) {
        setBlockedList([]);
      }
    })();
  }, [open, mode]);

  const handleKick = async () => {
    if (!kickMember || !battlefieldId) return;
    try {
      // Отримуємо публічний ключ
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
      const payload = { battlefieldId, userId: kickMember.id };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      const resp = await fetchWithAuth("/api/battlefields/owner-kicks-member", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      if (resp.ok) {
        setKickModalOpen(false);
        setKickMember(null);
        // Оновлюємо список учасників
        setMembers(members => members.filter(m => m.id !== kickMember.id));
      }
      // (опціонально: додай сповіщення про успіх/помилку)
    } catch (err) {
      // (опціонально: додай сповіщення про помилку)
    }
  };
  

  async function checkIfJoinRequestExists(receiverId) {
    if (!battlefieldId || !receiverId) return false;
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { receiverId, battlefieldId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      const resp = await fetchWithAuth("/api/battlefields/does-join-request-exist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      if (!resp.ok) return false;
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      let data = null;
      try { data = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8)); } catch {}
      return !!(data && data.exists);
    } catch {
      return false;
    }
  }
  

  // --- Пошук користувача по ідентифікатору
  const handleIdentifierChange = async (e) => {
    let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, IDENTIFIER_LENGTH);
    setIdentifier(v);
    setStatus("idle");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setSendResult("");

    if (v.length === IDENTIFIER_LENGTH) {
      setStatus("loading");
      try {
        const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
        const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
        const payload = { identifier: v };
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

        const resp = await fetchWithAuth("/api/contacts/find", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
        });
        if (!resp.ok) {
          setStatus("error");
          setFoundUser(null);
          setCustomAvatarUrl(null);
          return;
        }

        const respText = await resp.text();
        let data;
        try { data = JSON.parse(respText); } catch (e) { setStatus("error"); return; }
        const ivData = CryptoJS.enc.Base64.parse(data.iv);
        const key = bytesToWordArray(aesKey);
        const decrypted = CryptoJS.AES.decrypt(data.ciphertext, key, {
          iv: ivData,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
        let user;
        try { user = JSON.parse(jsonStr); } catch (e) { setStatus("error"); return; }

        setStatus("found");
        setFoundUser(user);

        const requestExists = await checkIfJoinRequestExists(user.id);
        setRequestsExist(prev => ({ ...prev, [user.id]: requestExists }));


        if (user.avatarType === "custom" && !user.avatarUrl) {
          fetchAndDecryptCustomAvatar(user.id).then(setCustomAvatarUrl);
        }
      } catch {
        setStatus("error");
        setCustomAvatarUrl(null);
      }
    }
  };

  const handleCancelSearch = () => {
    setIdentifier("");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setStatus("idle");
    setSendResult("");
  };

  // --- Вибір друга (toggle)
  const toggleSelected = (id) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // --- Відправка заявки(ів) на вступ
  const handleSendRequest = async () => {
    setSending(true);
    setSendResult("");
    // Тут фільтруємо, щоб не додавати тих, хто вже учасник
    const actualReceivers = [
      ...(selectedIds.length ? selectedIds.filter(id => !memberIds.has(id)) : []),
      ...(status === "found" && foundUser && !selectedIds.includes(foundUser.id) && !memberIds.has(foundUser.id) ? [foundUser.id] : [])
    ];
    if (actualReceivers.length === 0) {
      setSendResult("No users selected.");
      setSending(false);
      return;
    }
  
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      const sessionAesKey = generateRandomBytes(16);
      const sessionIv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, pubKeyPem);
  
      const payload = {
        battlefieldId,
        receivers: actualReceivers
      };
  
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, sessionAesKey, sessionIv);
  
      const resp = await fetchWithAuth("/api/battlefields/add-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      if (!resp.ok) {
        setSendResult("Failed to send request(s).");
      } else {
        setSendResult("Invitation(s) sent!");
        setTimeout(() => {
          handleSetMode("view");
        }, 800);
      }
    } catch (err) {
      setSendResult("Failed to send request(s).");
    }
    setSending(false);
  };
  

  // --- Кастом-аватарки
  async function fetchAndDecryptCustomAvatar(userId) {
    try {
      const token = localStorage.getItem("jwt");
      const fileRes = await fetch(`/api/profile/avatar-file/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!fileRes.ok) throw new Error("Cannot get avatar file");
      const fileBuffer = await fileRes.arrayBuffer();

      const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
      const rsaKeyBase64 = await rsaKeyRes.text();
      const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const JSEncrypt = (await import("jsencrypt")).default;
      const sessionAesKey = generateRandomBytes(16);
      const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(rsaKeyPem);
      const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

      const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedSessionAesKey }),
      });
      const { iv, ciphertext } = await resp.json();

      const keyBytes = sessionAesKey;
      const ivWord = CryptoJS.enc.Base64.parse(iv);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
        iv: ivWord,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const avatarAesKeyBytes = Uint8Array.from(
        decrypted.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decrypted.sigBytes)
      );

      const fileBytes = new Uint8Array(fileBuffer);
      const fileIv = fileBytes.slice(0, 16);
      const fileCipher = fileBytes.slice(16);

      const decWord = CryptoJS.AES.decrypt(
        { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
        CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
        {
          iv: CryptoJS.lib.WordArray.create(fileIv),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );

      const uint8Decrypted = Uint8Array.from(
        decWord.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decWord.sigBytes)
      );

      const blob = new Blob([uint8Decrypted], { type: "image/png" });
      return URL.createObjectURL(blob);
    } catch (err) {
      return null;
    }
  }

  // --- Список відфільтрованих
  const filteredMembers = members.filter(
    (m) => m.name && m.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const filteredFriends = addSearchQuery.length > 0
    ? friends.filter(f => (f.name || "").toLowerCase().includes(addSearchQuery.toLowerCase()))
    : friends;

  if (!open) return null;

  // --- VIEW MODE: Loading права власника
  if (mode === "view" && !ownerChecked) {
    return ReactDOM.createPortal(
      <div className="bf-members-overlay">
        <div className="bf-members-modal" ref={modalRef}>
          <div className="bf-members-header">
            <img src="/icons/contactsIcon.png" alt="Members" className="bf-members-header-icon" />
            <span>Battlefield Members</span>
          </div>
          <div className="bf-members-empty-text" style={{ margin: "3.2rem 0" }}>
            Checking permissions...
          </div>
        </div>
      </div>,
      document.getElementById("modal-root")
    );
  }
  // --- VIEW MODE: Loading учасників
  if (mode === "view" && loadingMembers) {
    return ReactDOM.createPortal(
      <div className="bf-members-overlay">
        <div className="bf-members-modal" ref={modalRef}>
          <div className="bf-members-header">
            <img src="/icons/contactsIcon.png" alt="Members" className="bf-members-header-icon" />
            <span>Battlefield Members</span>
          </div>
          <div className="bf-members-empty-text" style={{ margin: "3.2rem 0" }}>
            Loading members...
          </div>
        </div>
      </div>,
      document.getElementById("modal-root")
    );
  }

  // --- РЕНДЕР
  return ReactDOM.createPortal(
    <div className="bf-members-overlay">
      <div className="bf-members-modal" ref={modalRef}>
        <button className="bf-members-close-btn" onClick={onClose}>×</button>
        <AnimatedHeightWrapper activeKey={mode}>
          {/* --- VIEW: СПИСОК УЧАСНИКІВ --- */}
          {mode === "view" && (
            <>
              <div className="bf-members-header">
                <img src="/icons/contactsIcon.png" alt="Members" className="bf-members-header-icon" />
                <span>Battlefield Members</span>
              </div>
              <hr className="divider" />
              <input
                className="bf-members-search-input"
                type="text"
                placeholder="Find"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                autoFocus
              />
              <AnimatedHeightWrapper activeKey={filteredMembers.map(m => m.id).join(",") + searchQuery + isOwner}>
                <div className="bf-members-list" style={{ marginBottom: "1rem", marginTop: "1.1rem" }}>
                  {filteredMembers.length === 0 ? (
                    <div className="bf-members-empty-text">No members found.</div>
                  ) : (
                    filteredMembers.map((member) => (
                      <div className="bf-members-item" key={member.id}>
                        <img
                          src={member.avatarType === "custom" && customAvatars[member.id]
                            ? customAvatars[member.id]
                            : member.avatarUrl || "/avatars/default.png"}
                          alt={member.name}
                          className="bf-members-avatar"
                        />
                        <div className="bf-members-info">
                          <div className="bf-members-name">{member.name}</div>
                          <div className="bf-members-role">
                            {member.isOwner ? "Owner" : member.role}
                          </div>
                        </div>
                        {isOwner && !member.isOwner && (
                        <div className="bf-members-actions">
                            <button
                            className="bf-members-remove-btn"
                            title="Remove from battlefield"
                            tabIndex={-1}
                            onClick={() => {
                                setKickMember(member);
                                setKickModalOpen(true);
                            }}
                            >
                            <img
                                src="/icons/rejectIcon.png"
                                alt="Remove"
                                style={{
                                width: 26,
                                height: 26,
                                opacity: .9,
                                }}
                            />
                            </button>
                        </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </AnimatedHeightWrapper>
              <div style={{ width: "100%", margin: "0.7rem 0 0.2rem 0", display: "flex", justifyContent: "center" }}>
            <button
                className="bf-members-main-action-btn"
                style={{
                width: "85%",
                margin: "0 auto",
                background: "#242e36",
                color: "#00e0d1",
                fontWeight: 600,
                boxShadow: "none",
                border: "1.3px solid #20374b"
                }}
                onClick={() => handleSetMode("add")}
            >
                + Add New Member
            </button>
            </div>
              <hr className="divider" />
              <div className="bf-members-bottom-btn-row">
                <button
                  className="bf-members-main-action-btn"
                  style={{ width: "100%" }}
                  onClick={onClose}
                >
                  Back
                </button>
              </div>
            </>
          )}

          {/* --- ADD: ДОДАВАННЯ НОВОГО УЧАСНИКА --- */}
          {mode === "add" && (
            <div className="bf-members-add-section">
              <div className="bf-members-header">
                <img src="/icons/contactsIcon.png" alt="Members" className="bf-members-header-icon" />
                <span>Adding new member</span>
              </div>
              <hr className="divider" />

              <div className="input-title" style={{ marginBottom: 8 }}>Find user by identifier:</div>
              <div className={`identifier-input-wrapper${status === "error" ? " error" : ""}`}>
                <input
                  className="bf-members-search-input"
                  maxLength={IDENTIFIER_LENGTH}
                  style={{ fontSize: "2.0rem", letterSpacing: "0.19em" }}
                  placeholder="ABC123"
                  value={identifier}
                  onChange={handleIdentifierChange}
                  disabled={status === "found"}
                  autoFocus
                />
              </div>
              {status === "loading" && <div className="loading-text">Searching...</div>}
              {status === "error" && <div className="error-text">User not found</div>}
              {status === "found" && foundUser && (
                <div className="found-user-block">
                  <div className="found-user">
                    <img
                      src={foundUser.avatarType === "custom"
                        ? (customAvatarUrl || "/avatars/avatar1.png")
                        : (foundUser.avatarUrl || "/avatars/avatar1.png")}
                      alt="avatar"
                      className="avatar-preview"
                    />
                    <div className="user-info">
                      <div className="found-name">{foundUser.name}</div>
                      <div className="found-role">{foundUser.role}</div>
                    </div>
                    <div className="action-icons-row">
                    {memberIds.has(foundUser.id) ? (
                        <span className="self-info-add-member" style={{
                        color: "#90f2a7",
                        background: "#203b26",
                        borderRadius: 9,
                        fontWeight: 600,
                        fontSize: "1.90rem",
                        padding: "5px 15px"
                        }}>
                        Already a member
                        </span>
                    ) : requestsExist[foundUser.id] ? (
                        <img
                        src="/icons/acceptIcon.png"
                        alt="Request already sent"
                        style={{
                          border: "2.2px solid #4ff495",
                          borderRadius: "50%",
                          background: "#262",
                          width: 38,
                          height: 38,
                          display: "inline-block",
                          verticalAlign: "middle",
                          boxShadow: "0 0 4px #33eebbe0",
                          padding: 4,
                          filter: "none",
                          cursor: "not-allowed",
                          opacity: 0.77,
                          transition: "box-shadow 0.14s"
                        }}
                        title="Request already sent"
                        draggable={false}
                      />
                      
                      ) : (
                        <img
                          src={selectedIds.includes(foundUser.id) ? "/icons/acceptIcon.png" : "/icons/addMemberIcon.png"}
                          className="icon-btn"
                          alt={selectedIds.includes(foundUser.id) ? "Selected" : "Send request"}
                          title={selectedIds.includes(foundUser.id) ? "Remove from selection" : "Send request to join"}
                          style={
                            selectedIds.includes(foundUser.id)
                              ? {
                                  border: "2.2px solid #4ff495",
                                  borderRadius: "50%",
                                  background: "#262",
                                  padding: 2,
                                  filter: "none",
                                  cursor: "pointer"
                                }
                              : {
                                  filter: "invert(48%) sepia(86%) saturate(2287%) hue-rotate(136deg) brightness(99%) contrast(101%)",
                                  cursor: "pointer"
                                }
                          }
                          onClick={() => toggleSelected(foundUser.id)}
                        />
                      )}
                    </div>
                  </div>
                  <button
                    className="contacts-cancel-btn"
                    type="button"
                    style={{ marginTop: 16 }}
                    onClick={handleCancelSearch}
                  >
                    Cancel
                  </button>
                </div>
              )}

              {/* --- Список друзів для вибору --- */}
                {!(status === "found" && foundUser) && (
                <>
                    <hr className="divider" />
                    <div className="input-title" style={{ marginBottom: 8, textAlign: "center" }}>
                    Send requests to your friends:
                    </div>
                    <div className="requests-list" style={{ maxHeight: 170 }}>
                    {loadingFriends ? (
                        <div className="loading-text">Loading friends...</div>
                    ) : filteredFriends.length === 0 ? (
                        <div className="empty-text">You have no friends yet.</div>
                    ) : (
                        filteredFriends
                        .filter(friend => friend && friend.id && friend.name && friend.role)
                        .map(friend => {
                            const alreadyMember = memberIds.has(friend.id);
                            return (
                            <div key={friend.id} className="request-item friend-card">
                                <img
                                src={
                                    friend.avatarType === "custom"
                                    ? (friendsAvatars[friend.id] || "/avatars/avatar1.png")
                                    : (friend.avatarUrl || "/avatars/avatar1.png")
                                }
                                alt="avatar"
                                className="avatar-preview"
                                />
                                <div className="info">
                                <div className="name">{friend.name}</div>
                                <div className="role">{friend.role}</div>
                                </div>
                                <div className="actions">
                                {blockedList.includes(String(friend.id)) ? (
                                    <span className="self-info blocked" style={{
                                    color: "#ff5555",
                                    background: "#251819",
                                    borderRadius: 9,
                                    fontWeight: 600,
                                    padding: "4px 10px"
                                    }}>
                                    Blocked
                                    </span>
                                ) : alreadyMember ? (
                                    <span className="self-info" style={{
                                    color: "#90f2a7",
                                    background: "#203b26",
                                    borderRadius: 9,
                                    fontWeight: 600,
                                    fontSize: "1.02rem",
                                    padding: "5px 13px"
                                    }}>
                                    Already a member
                                    </span>
                                    ) : requestsExist[friend.id] ? (
                                        <img
                                        src="/icons/acceptIcon.png"
                                        alt="Request already sent"
                                        style={{
                                          border: "2.2px solid #4ff495",
                                          borderRadius: "50%",
                                          background: "#262",
                                          width: 34,
                                          height: 34,
                                          display: "inline-block",
                                          verticalAlign: "middle",
                                          boxShadow: "0 0 3px #31ffbb7a",
                                          padding: 3,
                                          filter: "none",
                                          cursor: "not-allowed",
                                          opacity: 0.77,
                                          transition: "box-shadow 0.14s"
                                        }}
                                        title="Request already sent"
                                        draggable={false}
                                      />
                                      

                                    ) : (
                                        <button
                                          className="icon-action-btn"
                                          title={selectedIds.includes(friend.id) ? "Remove from selection" : "Send Request"}
                                          style={{
                                            background: "none",
                                            border: "none",
                                            cursor: "pointer"
                                          }}
                                          onClick={() => toggleSelected(friend.id)}
                                        >
                                          <img
                                            src={selectedIds.includes(friend.id) ? "/icons/acceptIcon.png" : "/icons/addMemberIcon.png"}
                                            alt={selectedIds.includes(friend.id) ? "Selected" : "Add member"}
                                            style={selectedIds.includes(friend.id)
                                              ? {
                                                  border: "2.2px solid #4ff495",
                                                  borderRadius: "50%",
                                                  background: "#262",
                                                  padding: 2,
                                                  filter: "none"
                                                }
                                              : {
                                                  filter: "invert(48%) sepia(86%) saturate(2287%) hue-rotate(136deg) brightness(99%) contrast(101%)"
                                                }
                                            }
                                          />
                                        </button>
                                      )}
                                </div>
                            </div>
                            );
                        })
                    )}
                    </div>
                </>
                )}

              <input
                    className="bf-members-search-input"
                    type="text"
                    placeholder="Find friend"
                    value={addSearchQuery}
                    onChange={e => setAddSearchQuery(e.target.value)}
                    style={{ marginBottom: 10, marginTop: 10 }}
                  />
                  {addSearchQuery.length > 0 && (
                    <div className="centered-cancel-btn">
                      <button
                        className="contacts-cancel-btn"
                        type="button"
                        onClick={() => setAddSearchQuery("")}
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                  <hr className="divider" />
              {/* --- Відправити заявку --- */}
              <button
                className="bf-members-main-action-btn"
                style={{
                  marginTop: 14,
                  width: "100%",
                  background: "#00e0d1",
                  color: "#20364d",
                  fontWeight: 700,
                  fontSize: "1.06rem"
                }}
                onClick={handleSendRequest}
                disabled={sending}
              >
                {sending ? "Sending..." : "Send Invitation"}
              </button>
              {!!sendResult && (
                <div style={{
                  margin: "10px 0 0 0",
                  color: sendResult === "Invitation(s) sent!" ? "#38f396" : "#ff6868",
                  textAlign: "center",
                  fontWeight: 600
                }}>{sendResult}</div>
              )}
              <button
                className="bf-members-main-action-btn"
                style={{
                  marginTop: 20,
                  width: "100%",
                  background: "#232932",
                  color: "#fff"
                }}
                onClick={() => handleSetMode("view")}
                disabled={sending}
              >
                Back to Members
              </button>
            </div>
          )}
        </AnimatedHeightWrapper>
      </div>
      <KickMemberConfirmModal
        open={kickModalOpen}
        member={kickMember}
        onKick={handleKick}
        onCancel={() => { setKickModalOpen(false); setKickMember(null); }}
        />
    </div>,
    document.getElementById("modal-root")
  );
}
