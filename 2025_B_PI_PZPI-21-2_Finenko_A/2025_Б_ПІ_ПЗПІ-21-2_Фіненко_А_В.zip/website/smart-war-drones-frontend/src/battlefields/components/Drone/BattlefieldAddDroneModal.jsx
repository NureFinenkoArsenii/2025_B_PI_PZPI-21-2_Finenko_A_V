import React, { useRef, useEffect, useCallback, useState } from "react";
import AnimatedHeightWrapper from "../../../components/AnimatedHeightWrapper";
import "../../battlefieldStyles/Drone/BattlefieldAddDroneModal.scss";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
  decryptWithAES_fromResponse,
} from "../../../utils/passwordCrypto";
import { fetchWithAuth } from "../../../utils/tokenManager";
import attackImg from "../../../map/media/attackdrone.png";
import transportImg from "../../../map/media/transportdrone.png";
import scoutImg from "../../../map/media/scout-drone.png";
import anotherImg from "../../../map/media/anothertype.png";


function getDroneAvatarUrl(type) {
  switch ((type || "").trim().toLowerCase()) {
    case "attack":
      return attackImg;
    case "transport":
      return transportImg;
    case "scout":
      return scoutImg;
    default:
      return anotherImg;
  }
}
function getTypeClass(type) {
  switch ((type || "").trim().toLowerCase()) {
    case "attack":
      return "attack";
    case "transport":
      return "transport";
    case "scout":
      return "scout";
    default:
      return "another";
  }
}

export default function BattlefieldAddDroneModal({
  open,
  onClose,
  battlefieldId,
  onDronesAdded,
  dronesInBattlefield = []   // ← додано
}) {
  const modalRef = useRef(null);
  const [search, setSearch] = useState("");
  const [droneList, setDroneList] = useState([]);
  const [expandedDroneId, setExpandedDroneId] = useState(null);
  const [droneStats, setDroneStats] = useState({});
  const [loadingStatsId, setLoadingStatsId] = useState(null);
  const [selectedDroneIds, setSelectedDroneIds] = useState([]);

  // Фільтрація
  const filteredDrones = search.trim()
    ? droneList.filter((d) =>
        (d.DroneName || "").toLowerCase().includes(search.trim().toLowerCase())
      )
    : droneList;

  // --- Закриття по кліку поза модалкою та Esc ---
  const handleClickOutside = useCallback(
    (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) onClose();
    },
    [onClose]
  );
  const handleEsc = useCallback(
    (e) => {
      if (e.key === "Escape") onClose();
    },
    [onClose]
  );

  const handleSelectDrone = (droneId) => {
    setSelectedDroneIds((prev) =>
      prev.includes(droneId) ? prev.filter(id => id !== droneId) : [...prev, droneId]
    );
  };

  useEffect(() => {
    if (!open) return;
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [open, handleClickOutside, handleEsc]);

  // === Основна частина: Отримати список дронів при відкритті ===
  useEffect(() => {
    if (!open) return;
    fetchDrones().then(setDroneList);
    setExpandedDroneId(null);
    setDroneStats({});
  }, [open]);

  async function fetchDrones() {
    const res = await fetchWithAuth("/api/map/drone/public-key");
    const base64 = await res.text();
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
      .match(/.{1,64}/g)
      .join("\n")}\n-----END PUBLIC KEY-----`;

    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);

    const { ciphertext, iv } = encryptJsonWithAES_forPassword({}, aesKey, aesIv);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

    const response = await fetchWithAuth("/api/map/drone/getAll", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({
        EncryptedKey: encryptedKey,
        Iv: iv,
        Ciphertext: ciphertext,
      }),
    });

    if (!response.ok) return [];
    const encryptedResponse = await response.json();
    const decrypted = decryptWithAES_fromResponse(encryptedResponse, aesKey);

    return decrypted || [];
  }

  const handleCloseModal = async () => {
    if (selectedDroneIds.length > 0) {
      console.log("[FRONT] Відправляємо обрані дрони:", selectedDroneIds, "battlefieldId:", battlefieldId);
      await sendSelectedDronesToServer();
      if (onDronesAdded) onDronesAdded();
    } else {
      console.log("[FRONT] Жодного дрона не вибрано для додавання.");
    }
    onClose();
  };

  useEffect(() => {
    if (!open && selectedDroneIds.length > 0) {
      console.log("[FRONT] Modal closed, sending drones...", selectedDroneIds);
      sendSelectedDronesToServer();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function sendSelectedDronesToServer() {
    if (!battlefieldId || selectedDroneIds.length === 0) return;
  
    console.log("[FRONT] Початок запиту на сервер з дронами:", selectedDroneIds, "battlefieldId:", battlefieldId);
  
    // 1. Отримати публічний ключ для шифрування AES-ключа (battlefields!)
    const res = await fetchWithAuth("/api/battlefields/public-key");
    const base64 = await res.text();
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
    // 2. Генеруємо сесійний AES-ключ та IV
    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);
  
    // 3. Шифруємо payload: { battlefieldId, droneIds }
    const payload = { battlefieldId, droneIds: selectedDroneIds };
    const { ciphertext, iv } = encryptJsonWithAES_forPassword(payload, aesKey, aesIv);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
  
    // 4. Відправляємо запит
    console.log("[FRONT] Надсилаємо тіло запиту:", { EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext });
    const resp = await fetchWithAuth("/api/battlefields/add-drones-to-battlefield", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({
        EncryptedKey: encryptedKey,
        Iv: iv,
        Ciphertext: ciphertext,
      }),
    });
  
    console.log("[FRONT] Відповідь від сервера:", resp.status, resp.statusText);
    if (resp.ok) {
      const data = await resp.json();
      console.log("[FRONT] Успішно:", data);
      setSelectedDroneIds([]);
    } else {
      try {
        const err = await resp.text();
        console.error("[FRONT] Помилка відповіді:", err);
      } catch {
        console.error("[FRONT] Помилка відповіді, не вдалося прочитати body");
      }
    }
  }
  

  async function fetchDroneStats(droneId) {
    setLoadingStatsId(droneId);
    const res = await fetchWithAuth("/api/map/drone/public-key");
    const base64 = await res.text();
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
      .match(/.{1,64}/g)
      .join("\n")}\n-----END PUBLIC KEY-----`;

    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);

    const { ciphertext, iv } = encryptJsonWithAES_forPassword({ droneId }, aesKey, aesIv);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

    const response = await fetchWithAuth("/api/map/stats/getByDroneId", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
    });

    if (!response.ok) {
      setDroneStats((prev) => ({ ...prev, [droneId]: null }));
      setLoadingStatsId(null);
      return;
    }

    const encryptedResponse = await response.json();
    const decrypted = decryptWithAES_fromResponse(encryptedResponse, aesKey);
    setDroneStats((prev) => ({ ...prev, [droneId]: decrypted }));
    setLoadingStatsId(null);
  }

  // Головна зміна — єдиний id обраного дрона, або null
  const handleDroneClick = (drone) => {
    if (expandedDroneId === drone.Id) {
      setExpandedDroneId(null);
    } else {
      setExpandedDroneId(drone.Id);
      if (!droneStats[drone.Id]) fetchDroneStats(drone.Id);
    }
  };

  if (!open) return null;

  return (
    <div className="battlefield-add-drones-overlay">
      <div className="battlefield-add-drones-modal" ref={modalRef}>
        <AnimatedHeightWrapper activeKey={expandedDroneId || "list"}>
          {/* ====== LIST ====== */}
          {!expandedDroneId && (
            <>
              <div className="battlefield-add-drones-header-row">
                <img src="/icons/droneIcon.png" alt="" className="battlefield-add-drones-header-icon" />
                <div className="battlefield-add-drones-header">Adding Drones</div>
              </div>
              <hr className="battlefield-add-drones-divider" />
              <input
                className="battlefield-add-drones-search"
                placeholder="Search drone by name…"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
              <div className="battlefield-add-drones-list-container">
                {filteredDrones.length === 0 ? (
                  <span className="battlefield-add-drones-nodrones">No drones found.</span>
                ) : (
                  filteredDrones.map((d, i) => (
                    <div key={i} className="battlefield-drone-list-item-col">
                      <div
                        className="battlefield-drone-list-item"
                        style={{ cursor: "pointer", marginBottom: "0.7rem", position: "relative" }}
                      >
                        <img
                          src={d.AvatarUrl || getDroneAvatarUrl(d.DroneType)}
                          alt="drone avatar"
                          className="battlefield-drone-avatar"
                          onClick={() => handleDroneClick(d)}
                        />
                        <div className="battlefield-drone-info" onClick={() => handleDroneClick(d)}>
                          <div className="battlefield-drone-main-row">
                            <span className="battlefield-drone-name">{d.DroneName}</span>
                          </div>
                          <div className="battlefield-drone-band-row">
                            <span className="battlefield-drone-band-label">Band:</span>{" "}
                            <span>{d.FrequencyBand}</span>
                          </div>
                        </div>
                        {/* === Add button або лейбочка already added === */}
                        {dronesInBattlefield && dronesInBattlefield.includes(d.Id) ? (
                          <div
                            className="battlefield-drone-already-added-label"
                            style={{
                              position: "absolute",
                              right: 12,
                              top: "50%",
                              transform: "translateY(-50%)",
                              background: "#2e3856",
                              color: "#9ee9ff",
                              fontWeight: 600,
                              fontSize: 15,
                              borderRadius: 13,
                              padding: "3.5px 14px",
                              pointerEvents: "none"
                            }}
                          >
                            already added
                          </div>
                        ) : (
                          <button
                            className={
                              selectedDroneIds.includes(d.Id)
                                ? "battlefield-drone-accept-btn selected"
                                : "battlefield-drone-add-btn"
                            }
                            style={{
                              position: "absolute",
                              right: 12,
                              top: "50%",
                              transform: "translateY(-50%)",
                              background: "transparent",
                              border: "none",
                              padding: 0,
                              cursor: "pointer"
                            }}
                            onClick={() => handleSelectDrone(d.Id)}
                            tabIndex={-1}
                          >
                            <img
                              src={
                                selectedDroneIds.includes(d.Id)
                                  ? "/icons/acceptIcon.png"
                                  : "/icons/addMemberIcon.png"
                              }
                              alt="add"
                              style={{
                                width: 34,
                                height: 34,
                                borderRadius: "50%",
                                border: selectedDroneIds.includes(d.Id)
                                  ? "2.3px solid #26d642"
                                  : "2.3px solid #242932",
                                background: selectedDroneIds.includes(d.Id) ? "#112d1a" : "#232932",
                                transition: "all 0.18s"
                              }}
                            />
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
              <hr className="battlefield-add-drones-divider" />
            </>
          )}
          {/* ====== SINGLE DRONE ====== */}
          {expandedDroneId && (() => {
            const d = droneList.find(dr => dr.Id === expandedDroneId);
            if (!d) return null;
            return (
              <>
                <div className="battlefield-add-drones-header-row">
                  <img src="/icons/droneIcon.png" alt="" className="battlefield-add-drones-header-icon" />
                  <div className="battlefield-add-drones-header">Drone Details</div>
                </div>
                <div className="battlefield-drone-list-item-col" style={{ margin: "0 auto" }}>
                  <div
                    className="battlefield-drone-list-item expanded"
                    onClick={() => handleDroneClick(d)}
                    style={{
                      cursor: "pointer",
                      marginBottom: "0.7rem",
                    }}
                  >
                    <img
                      src={d.AvatarUrl || getDroneAvatarUrl(d.DroneType)}
                      alt="drone avatar"
                      className="battlefield-drone-avatar"
                    />
                    <div className="battlefield-drone-info">
                      <span className={`battlefield-drone-type-label ${getTypeClass(d.DroneType)}`}>
                        {d.DroneType}
                      </span>
                      <div className="battlefield-drone-main-row">
                        <span className="battlefield-drone-name">{d.DroneName}</span>
                      </div>
                      <div className="battlefield-drone-band-row">
                        <span className="battlefield-drone-band-label">Band:</span>{" "}
                        <span>{d.FrequencyBand}</span>
                      </div>
                      <div className="battlefield-drone-band-row">
                        <span className="battlefield-drone-band-label">Safety:</span>{" "}
                        <span>{d.SafetyCode}</span>
                      </div>
                    </div>
                  </div>
                  <div className="battlefield-drone-detail-expanded inner-detail">
                    {loadingStatsId === d.Id ? (
                      <div style={{ textAlign: "center", color: "#bbb", padding: "14px 0" }}>
                        Loading stats...
                      </div>
                    ) : (
                      <div>
                        {Array.isArray(droneStats[d.Id]) ? (
                          <table className="battlefield-stats-table">
                            <tbody>
                              {droneStats[d.Id].map((stat, idx) => (
                                <tr key={idx}>
                                  <td style={{ color: "#77e7e7", fontWeight: 600, paddingRight: 12, fontSize: 15 }}>
                                    {stat.StatsType}
                                  </td>
                                  <td style={{ color: "#fff", fontWeight: 600, fontSize: 15 }}>
                                    {stat.StatsInformation === "Initial value" ? (
                                      <span style={{ color: "#8e8e8e", fontStyle: "italic" }}>No data</span>
                                    ) : (
                                      stat.StatsInformation
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        ) : (
                          <div style={{ color: "#ffbaba", padding: 10, textAlign: "center" }}>
                            No stats found.
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </>
            );
          })()}
        </AnimatedHeightWrapper>
        <div className="battlefield-add-drones-footer">
          <button className="battlefield-add-drones-back-btn" onClick={handleCloseModal}>
            Back to the Battlefield
          </button>
        </div>
      </div>
    </div>
  );
  
}
