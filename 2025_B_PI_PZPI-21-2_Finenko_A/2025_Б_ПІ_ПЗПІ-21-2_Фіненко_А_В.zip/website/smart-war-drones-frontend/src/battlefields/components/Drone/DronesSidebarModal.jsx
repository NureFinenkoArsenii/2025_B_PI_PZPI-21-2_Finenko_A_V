import { useState, useEffect } from "react";
import "../../battlefieldStyles/Drone/DronesSidebarModal.scss";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  decryptWithAES_fromResponse,
} from "../../../utils/passwordCrypto";
import { fetchWithAuth, getUserIdFromToken } from "../../../utils/tokenManager";
import BattlefieldAddDroneModal from "./BattlefieldAddDroneModal";
import ConfirmDeleteDroneModal from "./ConfirmDeleteDroneModal"; // новий імпорт

export default function DronesSidebarModal({ battlefieldId }) {
  // --- стан ---
  const [collapsed, setCollapsed] = useState(true);
  const [role, setRole] = useState("");
  const [loadingRole, setLoadingRole] = useState(false);
  const [error, setError] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [drones, setDrones] = useState([]);
  const [loadingDrones, setLoadingDrones] = useState(false);
  const [expandedDroneId, setExpandedDroneId] = useState(null);
  const [droneStats, setDroneStats] = useState({});
  const [loadingStatsId, setLoadingStatsId] = useState(null);
  // --- для видалення ---
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [droneToDelete, setDroneToDelete] = useState(null);

  // --- userId і creatorId ---
  const [userId, setUserId] = useState("");
  const [creatorId, setCreatorId] = useState("");

  async function fetchDroneStats(droneId) {
    setLoadingStatsId(droneId);
    try {
      // 1. Публічний ключ для battlefields (!!!)
      const keyResp = await fetchWithAuth("/api/battlefields/public-key");
      const base64 = await keyResp.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);
  
      const payload = { droneId };
      const { ciphertext, iv } = encryptJsonWithAES_forPassword(payload, aesKey, aesIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
  
      const resp = await fetchWithAuth("/api/battlefields/battlefield-drone-stats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
      });
  
      if (!resp.ok) throw new Error();
      const encryptedResponse = await resp.json();
      const result = decryptWithAES_fromResponse(encryptedResponse, aesKey);
  
      setDroneStats(prev => ({ ...prev, [droneId]: result }));
    } catch {
      setDroneStats(prev => ({ ...prev, [droneId]: null }));
    }
    setLoadingStatsId(null);
  }

  // --- отримання ролі і userId ---
  async function fetchUserRole() {
    setLoadingRole(true);
    setError("");
    try {
      const publicKeyResp = await fetchWithAuth("/api/profile/public-key");
      const publicKeyBase64 = await publicKeyResp.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${publicKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);

      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
      const { ciphertext, iv } = encryptJsonWithAES_forPassword({}, aesKey, aesIv);

      const resp = await fetchWithAuth("/api/profile/get-role", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
      });

      if (!resp.ok) throw new Error("Server error");
      const encryptedResponse = await resp.json();
      const result = decryptWithAES_fromResponse(encryptedResponse, aesKey);

      if (typeof result.role === "string") setRole(result.role);
      else {
        setRole("");
        setError("Role not found in response.");
      }
    } catch {
      setError("Failed to get user role.");
      setRole("");
    }
    setLoadingRole(false);
  }

  // --- отримання userId з токену при монтуванні ---
  useEffect(() => {
    const id = getUserIdFromToken && getUserIdFromToken();
    setUserId(id);
  }, []);

  // --- отримання дронів з creatorId напрямку ---
  useEffect(() => {
    if (!collapsed && battlefieldId) {
      fetchBattlefieldDrones();
    }
    // eslint-disable-next-line
  }, [collapsed, battlefieldId]);

  async function fetchBattlefieldDrones() {
    setLoadingDrones(true);
    setDrones([]);
    setCreatorId(""); // скинь creator перед новим фетчем
    try {
      const keyResp = await fetchWithAuth("/api/battlefields/public-key");
      const base64 = await keyResp.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);

      const payload = { battlefieldId };
      const { ciphertext, iv } = encryptJsonWithAES_forPassword(payload, aesKey, aesIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

      const resp = await fetchWithAuth("/api/battlefields/get-battlefield-drones", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
      });

      if (!resp.ok) throw new Error("Server error");
      const encryptedResponse = await resp.json();
      // result: { drones: [...], creatorId: "" }  <-- допиши так у відповіді з бекенду
      const result = decryptWithAES_fromResponse(encryptedResponse, aesKey);
      if (result && result.drones && result.creatorId) {
        setDrones(result.drones);
        setCreatorId(result.creatorId);
      } else if (Array.isArray(result)) {
        setDrones(result);
      } else {
        setDrones([]);
      }
    } catch (e) {
      setError("Failed to fetch drones.");
      setDrones([]);
    }
    setLoadingDrones(false);
  }

  // --- Видалення дрона ---
  async function handleDeleteDrone(drone) {
    if (!battlefieldId || !drone?.Id) return;
    try {
      const keyResp = await fetchWithAuth("/api/battlefields/public-key");
      const base64 = await keyResp.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);

      const payload = { battlefieldId, droneId: drone.Id };
      const { ciphertext, iv } = encryptJsonWithAES_forPassword(payload, aesKey, aesIv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

      const resp = await fetchWithAuth("/api/battlefields/remove-drone-from-battlefield", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
      });

      if (resp.ok) {
        setShowDeleteModal(false);
        setDroneToDelete(null);
        // оновити список
        fetchBattlefieldDrones();
      }
    } catch {
      // можна вивести ерор
      setShowDeleteModal(false);
      setDroneToDelete(null);
    }
  }

  // --- чи користувач може видаляти цей дрон ---
  function canDeleteDrone(drone) {
    console.log("[canDeleteDrone]", { drone, userId, creatorId });
    if (!drone || !userId) return false;
    if (creatorId && creatorId === userId) return true;
    if (drone.OperatorId && drone.OperatorId === userId) return true;
    return false;
  }

  // --- розгортання списку ---
  const handleExpand = () => {
    setCollapsed(false);
    if (!role && !loadingRole) fetchUserRole();
  };

  return (
    <>
      <div className={`drones-sidebar-modal${collapsed ? " collapsed" : ""}`}>
        {collapsed ? (
          <button
            className="drones-sidebar-modal__circle"
            title="Show drones"
            onClick={handleExpand}
          >
            <img src="/icons/droneIcon.png" alt="Show drones" />
          </button>
        ) : (
          <div className="drones-sidebar-modal__content">
            <div className="drones-sidebar-modal__header">
              <div className="header-left">
                <img src="/icons/droneIcon.png" alt="" className="header-icon" />
                <span className="header-title">Drones</span>
                {!loadingRole && role === "operator" && (
                  <button
                    className="add-member-btn"
                    title="Add drone"
                    onClick={() => setShowAddModal(true)}
                    type="button"
                  >
                    <img src="/icons/addMemberIcon.png" alt="Add" />
                  </button>
                )}
              </div>
              <button
                className="collapse-btn"
                title="Hide drones"
                onClick={() => setCollapsed(true)}
                type="button"
              >
                &times;
              </button>
            </div>
            <div className="drones-sidebar-modal__list">
              {loadingRole ? (
                <span className="no-drones-placeholder">Loading role…</span>
              ) : error ? (
                <span className="no-drones-placeholder">{error}</span>
              ) : loadingDrones ? (
                <span className="no-drones-placeholder">Loading drones…</span>
              ) : drones.length === 0 ? (
                <span className="no-drones-placeholder">No drones in this battlefield.</span>
              ) : (
                drones.map((drone, i) => (
                  <div key={drone.Id || i} className="battlefield-drone-list-item-col">
                    <div
                      className={`battlefield-drone-list-item${expandedDroneId === drone.Id ? " expanded" : ""}`}
                      onClick={() => {
                        setExpandedDroneId(expandedDroneId === drone.Id ? null : drone.Id);
                        if (!droneStats[drone.Id]) fetchDroneStats(drone.Id);
                      }}
                      style={{ cursor: "pointer", marginBottom: "0.7rem", position: "relative" }}
                    >
                      <img
                        src={drone.AvatarUrl || "/map/media/anothertype.png"}
                        alt="drone avatar"
                        className="battlefield-drone-avatar"
                      />
                      <div className="battlefield-drone-info">
                        <div className="battlefield-drone-main-row">
                          <span className="battlefield-drone-name">{drone.DroneName}</span>
                        </div>
                        <div className="battlefield-drone-band-row">
                          <span className="battlefield-drone-band-label">Band:</span>{" "}
                          <span>{drone.FrequencyBand}</span>
                        </div>
                      </div>
                      {/* --- ІКОНКА ВИДАЛЕННЯ --- */}
                      {canDeleteDrone(drone) && (
                        <button
                          className="battlefield-drone-delete-btn"
                          title="Delete drone"
                          style={{
                            position: "absolute",
                            top: 8,
                            right: 10,
                            zIndex: 3,
                            background: "none",
                            border: "none",
                            padding: 0,
                            cursor: "pointer",
                            opacity: 0.83,
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setDroneToDelete(drone);
                            setShowDeleteModal(true);
                          }}
                        >
                          <img
                            src="/icons/rejectIcon.png"
                            alt="Delete"
                            style={{
                              width: 27,
                              height: 27,
                              filter: "drop-shadow(0 0 2px #ee4141b8)",
                              transition: "opacity 0.14s",
                            }}
                          />
                        </button>
                      )}
                    </div>
                    {expandedDroneId === drone.Id && (
                      <div className="battlefield-drone-detail-expanded inner-detail">
                        {loadingStatsId === drone.Id ? (
                          <div style={{ textAlign: "center", color: "#bbb", padding: "14px 0" }}>
                            Loading stats...
                          </div>
                        ) : (
                          Array.isArray(droneStats[drone.Id]) ? (
                            <table className="battlefield-stats-table">
                              <tbody>
                                {droneStats[drone.Id].map((stat, idx) => (
                                  <tr key={idx}>
                                    <td style={{ color: "#77e7e7", fontWeight: 600, paddingRight: 12, fontSize: 15 }}>
                                      {stat.StatsType}
                                    </td>
                                    <td style={{ color: "#fff", fontWeight: 600, fontSize: 15 }}>
                                      {stat.StatsInformation === "Initial value" ? (
                                        <span style={{ color: "#8e8e8e", fontStyle: "italic" }}>No data</span>
                                      ) : (
                                        stat.StatsInformation
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          ) : (
                            <div style={{ color: "#ffbaba", padding: 10, textAlign: "center" }}>
                              No stats found.
                            </div>
                          )
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
      <BattlefieldAddDroneModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        battlefieldId={battlefieldId}
        onDronesAdded={fetchBattlefieldDrones} // додаємо
        dronesInBattlefield={drones.map(d => d.Id)}
      />
      <ConfirmDeleteDroneModal
        open={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setDroneToDelete(null);
        }}
        onConfirm={() => handleDeleteDrone(droneToDelete)}
      />
    </>
  );
}
