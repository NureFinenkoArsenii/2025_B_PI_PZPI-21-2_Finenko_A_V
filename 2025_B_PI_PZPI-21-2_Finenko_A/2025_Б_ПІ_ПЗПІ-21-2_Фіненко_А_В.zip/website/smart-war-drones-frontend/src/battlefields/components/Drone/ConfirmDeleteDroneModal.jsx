import { useEffect, useRef } from "react";
import "../../battlefieldStyles/Drone/ConfirmDeleteDroneModal.scss";

export default function ConfirmDeleteDroneModal({ open, onClose, onConfirm }) {
  const modalRef = useRef();

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) onClose();
    };
    const handleEsc = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="confirm-delete-drone-overlay">
      <div className="confirm-delete-drone-modal" ref={modalRef}>
        <div className="confirm-delete-drone-title">
          Are you sure you want to delete the drone?
        </div>
        <div className="confirm-delete-drone-actions">
          <button className="delete-btn" onClick={onConfirm}>Delete</button>
          <button className="cancel-btn" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
