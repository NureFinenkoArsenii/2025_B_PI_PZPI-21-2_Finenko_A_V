import React, { useState, useRef, useEffect } from 'react';
import { MapContainer, TileLayer, FeatureGroup } from 'react-leaflet';
import { useTranslation } from 'react-i18next';
import { EditControl } from 'react-leaflet-draw';
import 'leaflet-draw/dist/leaflet.draw.css';
import '../../battlefieldStyles/Map/MapView.scss';
import CryptoJS from "crypto-js";
import {
  encryptJsonWithAES_forPassword,
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  bytesToWordArray,
} from '../../../utils/passwordCrypto';
import { fetchWithAuth } from '../../../utils/tokenManager';

function MapView({
  focusOnUkraine,
  drawingMode,
  setFocusOnUkraine,
  battlefieldId,
}) {
  const { t } = useTranslation();
  const mapRef = useRef(null);
  const featureGroupRef = useRef(new window.L.FeatureGroup());

  // 1. Об'єднаний стан центра та масштабу
  const [mapView, setMapView] = useState({
    center: [48.3794, 31.1656],
    zoom: 6,
  });

  const [tileLayer, setTileLayer] = useState(
    localStorage.getItem('selectedTileLayer') ||
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
  );
  const [isMapSelectorOpen, setIsMapSelectorOpen] = useState(false);
  const [isCursorPointer, setIsCursorPointer] = useState(false);

  const tileLayers = {
    OpenStreetMap: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    Stadia: 'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png',
    CartoDBVoyager: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    MapboxDark:
      'https://api.mapbox.com/styles/v1/mapbox/dark-v10/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
    MapboxSatellite:
      'https://api.mapbox.com/styles/v1/mapbox/satellite-streets-v11/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
    MapboxTraffic:
      'https://api.mapbox.com/styles/v1/mapbox/traffic-day-v2/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
  };

  const handleTileLayerChange = (newTileLayer) => {
    setTileLayer(newTileLayer);
    localStorage.setItem('selectedTileLayer', newTileLayer);
  };

  // 2. Контролер — гарантовано оновить мапу при будь-якій зміні центра чи зуму
  function MapController({ center, zoom, mapRef }) {
    useEffect(() => {
      if (mapRef.current) {
        mapRef.current.setView(center, zoom);
      }
    }, [center, zoom, mapRef]);
    return null;
  }

  // 3. Завантаження налаштувань з бекенду
  useEffect(() => {
    if (!battlefieldId) return;
  
    async function fetchBattlefieldSettings() {
      // 1. Отримати публічний ключ для battlefields
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      // 2. Згенерувати AES-ключ і IV
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
  
      // 3. Зашифрувати AES-ключ через RSA
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
      // 4. Зашифрувати payload
      const payload = { battlefieldId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      // 5. Відправити на сервер
      const res = await fetchWithAuth('/api/battlefields/get-by-id', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      const data = await res.json();
      // 6. Дешифрувати відповідь
      //   - data.ciphertext, data.iv (це новий IV від сервера)
      const ivData = CryptoJS.enc.Base64.parse(data.iv);
      const key = bytesToWordArray(aesKey);
  
      const decrypted = CryptoJS.AES.decrypt(data.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const battlefield = JSON.parse(jsonStr);
      
  
      // Далі твоя логіка центру, zoom, стилю карти
      let center = [48.3794, 31.1656];
        if (battlefield.mapFocus) {
        if (typeof battlefield.mapFocus === 'string') {
            try {
            center = JSON.parse(battlefield.mapFocus);
            if (!Array.isArray(center) || center.length !== 2 || center.some(isNaN)) {
                center = [48.3794, 31.1656];
            }
            } catch {
            center = [48.3794, 31.1656];
            }
        } else if (Array.isArray(battlefield.mapFocus)) {
            center = battlefield.mapFocus;
        }
        }
      let zoom = 6;
      if (battlefield.mapSize) {
        const parsedZoom = parseInt(battlefield.mapSize, 10);
        if (!isNaN(parsedZoom)) zoom = parsedZoom;
      }
      setMapView({ center, zoom });
  
      if (battlefield.mapStyle) {
        if (tileLayers[battlefield.mapStyle]) {
          setTileLayer(tileLayers[battlefield.mapStyle]);
        } else if (battlefield.mapStyle.startsWith('http')) {
          setTileLayer(battlefield.mapStyle);
        }
      }
    }
  
    fetchBattlefieldSettings();
    // eslint-disable-next-line
  }, [battlefieldId]);
  

  // 4. Фокус на Україну (reset to default)
  useEffect(() => {
    if (focusOnUkraine) {
      setMapView({ center: [48.3794, 31.1656], zoom: 6 });
      setFocusOnUkraine(false);
    }
  }, [focusOnUkraine, setFocusOnUkraine]);


  return (
    <div className={`map-container ${drawingMode ? 'drawing-mode' : ''}`}>
      <MapContainer
        key={mapView.center[0] + '-' + mapView.center[1] + '-' + mapView.zoom}
        center={mapView.center}
        zoom={mapView.zoom}
        style={{ height: '100vh', width: '100%' }}
        whenCreated={(mapInstance) => {
          mapRef.current = mapInstance;
        }}
        className={isCursorPointer ? 'cursor-drop-point' : ''}
      >
        <MapController center={mapView.center} zoom={mapView.zoom} mapRef={mapRef} />
        <TileLayer url={tileLayer} attribution="&copy; OpenStreetMap contributors" />
        <FeatureGroup ref={featureGroupRef}>
          <EditControl
            position="topleft"
            onCreated={(e) => {
              const layer = e.layer;
              featureGroupRef.current.addLayer(layer);
            }}
            draw={{
              rectangle: false,
              polygon: false,
              circle: false,
              circlemarker: false,
              marker: false,
              polyline: {
                shapeOptions: {
                  color: '#3388ff',
                  weight: 4,
                  opacity: 1.0,
                },
              },
            }}
            edit={{
              featureGroup: featureGroupRef.current,
              edit: false,
              remove: false,
            }}
          />
        </FeatureGroup>
      </MapContainer>
      {!drawingMode && (
        <div className={`map-style-selector ${isMapSelectorOpen ? 'open' : ''}`}>
          <h3 onClick={() => setIsMapSelectorOpen(!isMapSelectorOpen)}>{'Maps'}</h3>
          {isMapSelectorOpen && (
            <div className="map-options">
              {Object.keys(tileLayers).map((layerName) => (
                <button key={layerName} onClick={() => handleTileLayerChange(tileLayers[layerName])}>
                  {t(`map_layers.${layerName.toLowerCase()}`)}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default MapView;
