import React, { useState, useEffect } from 'react';
import MapView from './components/Map/MapView';
import DrawingBoard from './components/InteractionColumn/DrawingBoard';
import './battlefieldStyles/battlefield.scss';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useParams } from 'react-router-dom';
import BattlefieldMembersModal from "./components/InteractionColumn/BattlefieldMembersModal";
import BattlefieldGlobalChat from "./components/Chat/BattlefieldGlobalChat";
import DronesSidebarModal from "./components/Drone/DronesSidebarModal";

function Battlefield() {
    const navigate = useNavigate();
    const [showTitle, setShowTitle] = useState(true);
    const [overlayVisible, setOverlayVisible] = useState(false);
    const [titleVisible, setTitleVisible] = useState(false);
    const [isNormalMode, setIsNormalMode] = useState(false);
    const [focusOnUkraine, setFocusOnUkraine] = useState(false);
    const [drawingMode, setDrawingMode] = useState(false);
    const [dronePositions, setDronePositions] = useState({});
    const { id: battlefieldId } = useParams();
    const [showMembersModal, setShowMembersModal] = useState(false);

    useEffect(() => {
        const header = document.querySelector('.header');

        setTimeout(() => {
            header.classList.add('fade-out');
            setTimeout(() => {
                header.classList.add('hidden');
                setShowTitle(false);
            }, 1500);
        }, 750);

        header.addEventListener('click', () => {
            header.classList.add('hidden');
            setShowTitle(false);
        });
    }, []);

    const handleFocusOnUkraine = () => {
        setFocusOnUkraine(true);
        setTimeout(() => {
            setFocusOnUkraine(false);
        }, 500);
    };

    const startNormalMode = () => {
        setOverlayVisible(true);
        setTitleVisible(true);
        setIsNormalMode(true);

        setTimeout(() => {
            if (!titleVisible) {
                deactivatePlanningMode();
            }
        }, 2500);
    };

    const handleTitleClick = () => {
        setTitleVisible(false);
        setOverlayVisible(false);

        if (isNormalMode) {
            deactivatePlanningMode();
        } else {
            activatePlanningMode();
        }
    };

    const handleRefreshClick = () => {
        navigate('/workplace');
    };

    return (
            <div className="app">
                {!drawingMode && showTitle && (
                    <header className="header">
                        <div className="title" onClick={handleTitleClick}>Smart War Drones</div>
                    </header>
                )}
                <div className="content">
                    {!drawingMode && (
                        <div className="interaction-column">
                            <div className="interaction-title">{'Instruments'}</div>
                            <div className="interaction-menu">
                                <button onClick={handleFocusOnUkraine}>{'Focus on Ukraine'}</button>
                                <button onClick={() => setShowMembersModal(true)}>{'Members'}</button>
                                <button onClick={() => setDrawingMode(!drawingMode)}>
                                    {drawingMode ? 'Close Drawing' : 'Drawing'}
                                </button>
                                <button onClick={handleRefreshClick}>{'Exit'}</button>
                            </div>
                        </div>
                    )}

                    <div className="map-container">
                        <MapView
                            focusOnUkraine={focusOnUkraine}
                            setFocusOnUkraine={setFocusOnUkraine}
                            drawingMode={drawingMode}
                            dronePositions={dronePositions}
                            setDronePositions={setDronePositions}
                            battlefieldId={battlefieldId}
                        />
                    </div>

                    {drawingMode && <DrawingBoard onExit={() => setDrawingMode(false)} />}

                </div>

                {!drawingMode && (
                    <AnimatePresence>
                        {overlayVisible && (
                            <motion.div
                                className="planning-overlay"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                transition={{ duration: 1.5 }}
                            >
                                <AnimatePresence>
                                    {titleVisible && (
                                        <motion.div
                                            className={`planning-title ${isNormalMode ? 'blue-outline' : ''}`}
                                            initial={{ opacity: 0, scale: 0.8 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            exit={{ opacity: 0, scale: 0.8 }}
                                            transition={{ duration: 1.5 }}
                                            onClick={handleTitleClick}
                                        >
                                            Smart War Drones
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </motion.div>
                        )}
                    </AnimatePresence>
                )}
                 {!drawingMode && (
                  <>
                    <DronesSidebarModal battlefieldId={battlefieldId}/>
                    <BattlefieldGlobalChat battlefieldId={battlefieldId} />
                  </>
                )}
                <BattlefieldMembersModal open={showMembersModal} onClose={() => setShowMembersModal(false)} battlefieldId={battlefieldId}/>
            </div>
    );
}

export default Battlefield;
