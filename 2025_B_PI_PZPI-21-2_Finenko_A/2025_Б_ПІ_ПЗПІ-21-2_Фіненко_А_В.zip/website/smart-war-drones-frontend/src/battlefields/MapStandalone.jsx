import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

/**
 * MapStandalone — автономний компонент Leaflet-карти.
 *
 * @param {Object} props
 * @param {Function} onReady — callback(mapInstance)
 * @param {Function} onMoveEnd — callback({center, zoom}) при зміні карти
 * @param {Array} center — [lat, lng] центру
 * @param {number} zoom — рівень масштабування
 * @param {string} tileLayer — url для шару
 */
export default function MapStandalone({
  onReady,
  onMoveEnd,
  center = [48.3794, 31.1656],
  zoom = 6,
  tileLayer,
  ...props
}) {
  const mapRef = useRef(null);
  const leafletMapRef = useRef(null);
  const tileLayerRef = useRef(null);

  // 1. Створюємо мапу лише 1 раз
  useEffect(() => {
    if (!mapRef.current) return;
    leafletMapRef.current = L.map(mapRef.current, {
      center,
      zoom,
      zoomControl: true,
      attributionControl: false,
    });

    // Початковий tileLayer
    tileLayerRef.current = L.tileLayer(tileLayer, { attribution: "" }).addTo(leafletMapRef.current);

    if (onReady) onReady(leafletMapRef.current);

    // Слухачі
    function handleMoveOrZoom() {
      const map = leafletMapRef.current;
      if (onMoveEnd && map) {
        const c = map.getCenter();
        onMoveEnd({ center: [c.lat, c.lng], zoom: map.getZoom() });
      }
    }
    leafletMapRef.current.on("moveend", handleMoveOrZoom);
    leafletMapRef.current.on("zoomend", handleMoveOrZoom);

    // CleanUp
    return () => {
      leafletMapRef.current?.off();
      leafletMapRef.current?.remove();
      leafletMapRef.current = null;
      tileLayerRef.current = null;
    };
    // Тільки при першому mount!
    // eslint-disable-next-line
  }, []);

  // 2. Зміна центру/зуму без пересоздання карти
  useEffect(() => {
    const map = leafletMapRef.current;
    if (!map) return;
    const curr = map.getCenter();
    // Щоб не смикати, тільки якщо реально змінився
    if (
      Math.abs(curr.lat - center[0]) > 1e-6 ||
      Math.abs(curr.lng - center[1]) > 1e-6 ||
      map.getZoom() !== zoom
    ) {
      map.setView(center, zoom);
    }
  }, [center, zoom]);

  // 3. Заміна tileLayer без пересоздання карти
  useEffect(() => {
    const map = leafletMapRef.current;
    if (!map) return;
    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }
    tileLayerRef.current = L.tileLayer(tileLayer, { attribution: "" });
    tileLayerRef.current.addTo(map);
  }, [tileLayer]);

  return (
    <div
      ref={mapRef}
      style={{ width: "100vw", height: "100vh" }}
      {...props}
    />
  );
}
