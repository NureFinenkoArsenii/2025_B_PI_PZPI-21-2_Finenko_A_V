import React, { useRef, useState, useEffect, useCallback } from "react";
import leafletImage from "leaflet-image";
import "../styles/map/_chooseFocusAndScale.scss";
import MapStandalone from "./MapStandalone";

const TILE_LAYERS = {
  OpenStreetMap: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
  Stadia: 'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png',
  CartoDBVoyager: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
  MapboxDark: 'https://api.mapbox.com/styles/v1/mapbox/dark-v10/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
  MapboxSatellite: 'https://api.mapbox.com/styles/v1/mapbox/satellite-streets-v11/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
  MapboxTraffic: 'https://api.mapbox.com/styles/v1/mapbox/traffic-day-v2/tiles/{z}/{x}/{y}?access_token=pk.eyJ1Ijoibm93YW1hcnMiLCJhIjoiY2x6emprdjdsMWUydDJrc2I3MDA1YzRybCJ9.BVai6DspgQwJSp0inh19Ow',
};

export default function ChooseFocusAndScale({ onDone, onCancel }) {
  const [tileLayer, setTileLayer] = useState(TILE_LAYERS.OpenStreetMap);
  const [center, setCenter] = useState([48.3794, 31.1656]);
  const [zoom, setZoom] = useState(6);
  const mapInstanceRef = useRef(null);
  const [loading, setLoading] = useState(false);

  // ESC для закриття
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") onCancel();
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [onCancel]);

  const handleMapReady = useCallback((instance) => {
    mapInstanceRef.current = instance;
    setTimeout(() => {
      instance.invalidateSize();
    }, 180);
  }, []);

  // === MAIN BUTTON: зробити preview і автокроп ===
  const handleChoose = useCallback(() => {
    const mapInstance = mapInstanceRef.current;
    if (!mapInstance) {
      alert("Map is not ready. Try again in 1-2 seconds.");
      return;
    }
    setLoading(true);
    const centerObj = mapInstance.getCenter();
    const center = [centerObj.lat, centerObj.lng]; // <- Ось тут!
    const zoom = mapInstance.getZoom();
  
    leafletImage(mapInstance, function (err, canvas) {
      if (err) {
        setLoading(false);
        alert("Failed to render map image");
        return;
      }
  
      const w = canvas.width;
      const h = canvas.height;
      const size = Math.min(w, h);
      const x = Math.floor((w - size) / 2);
      const y = Math.floor((h - size) / 2);
  
      // Локально тут!
      const avatarCanvas = document.createElement('canvas');
      avatarCanvas.width = size;
      avatarCanvas.height = size;
      const ctx = avatarCanvas.getContext('2d');
      ctx.drawImage(canvas, x, y, size, size, 0, 0, size, size);
  
      const previewUrl = avatarCanvas.toDataURL("image/png");
      avatarCanvas.toBlob((blob) => {
        setLoading(false);
        const file = new File([blob], "preview.png", { type: "image/png" });
        onDone({
          center,
          zoom,
          tileLayer,
          previewUrl,
          croppedFile: blob
        });
      }, "image/png");
    });
  }, [tileLayer, onDone]);
  

  // --- RENDER ---
  return (
    <div className="choose-focus-fullscreen-overlay">
      <button className="close-fullscreen-btn" onClick={onCancel} title="Cancel (ESC)">×</button>
      <div className="fullscreen-map-root">
        <MapStandalone
          key={tileLayer}
          center={center}
          zoom={zoom}
          tileLayer={tileLayer}
          onReady={handleMapReady}
          onMoveEnd={({ center, zoom }) => {
            setCenter(center);
            setZoom(zoom);
          }}
        />
        <div className="fullscreen-map-style-panel">
          {Object.entries(TILE_LAYERS).map(([name, url]) => (
            <button
              key={name}
              className={tileLayer === url ? "selected" : ""}
              onClick={() => setTileLayer(url)}
            >
              {name}
            </button>
          ))}
        </div>
        <div className="fullscreen-map-actions">
          <button
            className="choose-btn"
            onClick={handleChoose}
            disabled={!mapInstanceRef.current || loading}
          >
            {loading ? "Loading..." : (!mapInstanceRef.current ? "Loading map..." : "Set the position and style")}
          </button>
          <button className="cancel-btn" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
