import { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { getUserRole, fetchWithAuth } from "../utils/tokenManager";
import JSEncrypt from 'jsencrypt';
import CryptoJS from "crypto-js";
import "../styles/components/_navbarWorkplace.scss";
import DronesModal from "../pages/DronesModal";

export default function NavbarWorkplace({ onProfileClick, onContactsClick, unreadChatsCount, avatarProps, friendRequestCount }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState("/avatars/avatar1.png");
  const avatarRef = useRef();
  const role = getUserRole();
  const navigate = useNavigate();
  const location = useLocation();
  const [isDronesModalOpen, setIsDronesModalOpen] = useState(false);

  const isMessages = location.pathname === "/workplace/messages";


  function getContactsIconSrc() {
    if (!friendRequestCount || friendRequestCount <= 0) return "/icons/contactsIcon.png";
    if (friendRequestCount >= 10) return "/icons/contactsIconMoreThanNine.png";
    return `/icons/contactsIcon${friendRequestCount}.png`;
  }

  function getMessagesIconSrc() {
    if (!unreadChatsCount || unreadChatsCount <= 0) return "/icons/messageIcon.png";
    if (unreadChatsCount > 9) return "/icons/messageIconMoreThanNine.png";
    return `/icons/messageIcon${unreadChatsCount}.png`;
  }

  // Логіка для кастомного аватара
  useEffect(() => {
    let currentBlobUrl = null;
    async function decryptAvatar() {
      if (!avatarProps) return;
      if (avatarProps.avatarType === "default") {
        setAvatarUrl(avatarProps.avatarUrl); // Без ?t=!
      } else if (avatarProps.avatarType === "custom" && avatarProps.encryptedBlob) {
        try {
          // 1. Отримуємо публічний RSA для avatar-image
          const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
          const rsaKeyBase64 = await rsaKeyRes.text();
          const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
          function generateRandomBytes(length) {
            const array = new Uint8Array(length);
            window.crypto.getRandomValues(array);
            return array;
          }
          const sessionAesKey = generateRandomBytes(16);
          const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
          const encryptor = new JSEncrypt();
          encryptor.setPublicKey(rsaKeyPem);
          const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);
  
          const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${avatarProps.userId}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ encryptedSessionAesKey }),
          });
          const { iv, ciphertext } = await resp.json();
  
          const keyBytes = sessionAesKey;
          const ivWord = CryptoJS.enc.Base64.parse(iv);
          const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
            iv: ivWord,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          });
  
          const avatarAesKeyBytes = Uint8Array.from(
            decrypted.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decrypted.sigBytes)
          );
          const fileBytes = new Uint8Array(avatarProps.encryptedBlob);
          const fileIv = fileBytes.slice(0, 16);
          const fileCipher = fileBytes.slice(16);
  
          const decWord = CryptoJS.AES.decrypt(
            { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
            CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
            {
              iv: CryptoJS.lib.WordArray.create(fileIv),
              mode: CryptoJS.mode.CBC,
              padding: CryptoJS.pad.Pkcs7,
            }
          );
          const uint8Decrypted = Uint8Array.from(
            decWord.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decWord.sigBytes)
          );
          const blob = new Blob([uint8Decrypted], { type: "image/png" });
          currentBlobUrl = URL.createObjectURL(blob);
          setAvatarUrl(currentBlobUrl); // <--- БЕЗ ?t=
        } catch (err) {
          setAvatarUrl("/avatars/avatar1.png");
          console.error("❌ Decrypt error:", err);
        }
      }
    }
    decryptAvatar();
    return () => {
      if (currentBlobUrl) URL.revokeObjectURL(currentBlobUrl);
    };
  }, [avatarProps]);

  const handleLogoClick = () => {
    window.location.href = "/";
  };

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleClickOutside = (e) => {
    if (avatarRef.current && !avatarRef.current.contains(e.target)) {
      setMenuOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("❌ Logout request failed", err);
    }
    localStorage.clear();
    navigate("/");
  };

  return (
    <nav className="navbar-workplace">
      <div className="logo" onClick={handleLogoClick}>
        SWD
      </div>
      <div className="icons" ref={avatarRef}>
      {isMessages ? (
          <img
            src="/icons/battlefieldsIcon.png"
            alt="Battlefields"
            title="Back to Battlefields"
            onClick={() => navigate("/workplace")}
          />
        ) : (
          <img
            src={getMessagesIconSrc()}
            alt="Messages"
            title="Messages"
            onClick={() => navigate("/workplace/messages")}
          />
        )}
        <img
        src={getContactsIconSrc()}
        alt="Contacts"
        title="Contacts"
        onClick={onContactsClick}
        />
        <img
          src={avatarUrl}
          alt="Avatar"
          title="Profile"
          className="avatar"
          onClick={toggleMenu}
        />

        {menuOpen && (
          <div className="dropdown-menu">
            <div
              className="dropdown-item"
              onClick={() => {
                onProfileClick();
                setMenuOpen(false);
              }}
            >
              <img src="/icons/profileIcon.png" alt="Profile" />
              <span>Profile</span>
            </div>
            <div 
              className="dropdown-item"
              onClick={() => {
                onContactsClick();
                setMenuOpen(false);
              }}
            >
              <img src="/icons/contactsIcon.png" alt="Contacts" />
              <span>Contacts</span>
            </div>
            <div
              className="dropdown-item"
              onClick={() => {
                navigate("/workplace/messages");
                setMenuOpen(false);
              }}
            >
              <img src="/icons/messageIcon.png" alt="Messages" />
              <span>Messages</span>
            </div>
            <div
              className="dropdown-item"
              onClick={() => {
                navigate("/workplace");
                setMenuOpen(false);
              }}
            >
              <img src="/icons/battlefieldsIcon.png" alt="Battlefields" />
              <span>Battlefields</span>
            </div>
            {role === "operator" && (
              <div className="dropdown-item" onClick={() => { setIsDronesModalOpen(true); setMenuOpen(false); }}>
                <img src="/icons/droneIcon.png" alt="My Drones" />
                <span>My Drones</span>
              </div>
            )}
            <div
              className="dropdown-item"
              onClick={() => {
                navigate("/workplace/map");
                setMenuOpen(false);
              }}
            >
              <img src="/icons/mapIcon.png" alt="Go to Map" />
              <span>Go to Map</span>
            </div>
            <div className="dropdown-item" onClick={handleLogout}>
              <img src="/icons/logOutIcon.png" alt="Log Out" />
              <span>Log Out</span>
            </div>
          </div>
        )}
      </div>
      <DronesModal open={isDronesModalOpen} onClose={() => setIsDronesModalOpen(false)} />
    </nav>
  );
}
