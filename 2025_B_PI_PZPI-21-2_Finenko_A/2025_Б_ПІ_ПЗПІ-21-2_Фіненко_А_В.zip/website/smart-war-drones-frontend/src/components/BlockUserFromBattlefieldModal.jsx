import { useEffect, useRef } from "react";
import "../styles/components/DeleteBattlefieldModal.scss"; // Можна використати ці ж стилі

export default function BlockUserFromBattlefieldModal({ open, onClose, onBlock, userName, blocking = false }) {
  const modalRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="delete-modal-backdrop">
      <div className="delete-modal" ref={modalRef}>
        <div className="delete-modal-title" style={{ color: "#fff" }}>
          You are going to block the user
        </div>
        {userName && (
          <div className="delete-modal-bf-name">
            <b>{userName}</b>
          </div>
        )}
        <div className="delete-modal-actions">
          <button className="modal-btn modal-btn-delete" onClick={onBlock} disabled={blocking}>
            Block
          </button>
          <button className="modal-btn" onClick={onClose} disabled={blocking}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
