import * as THREE from "three";
import { useThree } from "@react-three/fiber";


export default function WorkplaceScene() {
  const { viewport } = useThree();

  return (
    <mesh>
      <planeGeometry args={[viewport.width, viewport.height]} />
      <meshBasicMaterial color="#0a0f1c" side={THREE.DoubleSide} />
    </mesh>
  );
}
