import { useEffect, useRef } from "react";
import ReactDOM from "react-dom";
import "../styles/pages/_messages.scss";

// Використовуємо confirm-modal/confirm-box стилі!
export default function ChatDeleteModal({
  open,
  chat,
  customAvatars,
  deleteForBoth,
  setDeleteForBoth,
  onDelete,
  onCancel
}) {
  const modalRef = useRef();

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onCancel();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onCancel]);

  if (!open || !chat) return null;

  let avatarUrl = "/avatars/avatar1.png";
  if (chat.avatarType === "custom" && customAvatars?.[chat.id]) {
    avatarUrl = customAvatars[chat.id];
  } else if (chat.avatarUrl) {
    avatarUrl = chat.avatarUrl;
  }

  return ReactDOM.createPortal(
    <div className="confirm-modal danger-modal">
      <div className="confirm-box" ref={modalRef} tabIndex={0}>
        <img
            src={avatarUrl}
            alt="avatar"
            className="avatar-preview"
            style={{ margin: "0 auto 14px", width: 54, height: 54, objectFit: "cover", borderRadius: "50%" }}
        />
        <div style={{ fontWeight: 600, fontSize: "1.17rem", marginBottom: 12, color: "#fff" }}>
          Do you really want to delete the chat?
        </div>
        <div style={{ margin: "0 0 17px 0", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <input
            type="checkbox"
            id="deleteForBoth"
            checked={deleteForBoth}
            onChange={e => setDeleteForBoth(e.target.checked)}
            style={{ accentColor: "#0057b7", width: 18, height: 18, marginRight: 10 }}
          />
          <label htmlFor="deleteForBoth" style={{ color: "#addbff", fontSize: "1.04rem", cursor: "pointer" }}>
            Delete also for&nbsp;<b>{chat.name || "user"}</b>?
          </label>
        </div>
        <div className="confirm-actions">
          <button
            style={{ background: "#e16171" }}
            onClick={onDelete}
          >Delete</button>
          <button
            style={{ background: "#293750" }}
            onClick={onCancel}
          >Cancel</button>
        </div>
      </div>
    </div>,
    document.getElementById("modal-root") // не забудь про <div id="modal-root"></div> в index.html
  );
}
