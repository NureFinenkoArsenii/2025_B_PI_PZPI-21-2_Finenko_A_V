import { useState, useRef, useEffect } from "react";
import ReactDOM from "react-dom";
import "../styles/pages/_messages.scss";

export default function EditMessageModal({ open, message, onEdit, onCancel, decryptField, sharedSecretBytes }) {
  const modalRef = useRef();
  const [value, setValue] = useState("");
  const [touched, setTouched] = useState(false);

  useEffect(() => {
    if (open && message) {
      // Заповнюємо текст
      setValue(decryptField(message.ciphertext, sharedSecretBytes, message.iv));
      setTouched(false);
    }
  }, [open, message, decryptField, sharedSecretBytes]);

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onCancel();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onCancel]);

  if (!open || !message) return null;

  return ReactDOM.createPortal(
    <div className="confirm-modal">
      <div className="confirm-box" ref={modalRef}>
        <div style={{ fontWeight: 600, fontSize: "1.17rem", marginBottom: 18, color: "#fff" }}>
          You are editing the message
        </div>
        <input
          className="edit-message-input"
          style={{
            width: "100%",
            minHeight: 44,
            fontSize: "1.08rem",
            borderRadius: 8,
            border: "1.5px solid #333c5c",
            background: "#212d44",
            color: "#e9f5ff",
            marginBottom: 20,
            padding: "10px 14px"
          }}
          type="text"
          value={value}
          onChange={e => {
            setValue(e.target.value);
            setTouched(true);
          }}
          autoFocus
        />
        <div className="confirm-actions" style={{ marginTop: 10 }}>
          <button
            style={{
              background: touched && value.trim() !== decryptField(message.ciphertext, sharedSecretBytes, message.iv) ? "#47bae6" : "#3a4661",
              color: "#06262c",
              minWidth: 70,
              cursor: touched && value.trim() !== decryptField(message.ciphertext, sharedSecretBytes, message.iv) ? "pointer" : "not-allowed",
              opacity: touched && value.trim() !== decryptField(message.ciphertext, sharedSecretBytes, message.iv) ? 1 : 0.7,
              fontWeight: 600,
            }}
            onClick={() => {
              if (touched && value.trim() !== decryptField(message.ciphertext, sharedSecretBytes, message.iv)) {
                onEdit(value);
              }
            }}
            disabled={!touched || value.trim() === decryptField(message.ciphertext, sharedSecretBytes, message.iv)}
          >
            Edit
          </button>
          <button
            style={{ background: "#293750" }}
            onClick={onCancel}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}
