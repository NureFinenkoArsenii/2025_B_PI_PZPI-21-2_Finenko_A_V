import { useEffect, useRef } from "react";

export default function DeleteDroneModal({ open, title, confirmText, cancelText, loading, error, onConfirm, onClose }) {
    const modalRef = useRef();
  
    useEffect(() => {
      if (!open) return;
      function handleKeyDown(e) {
        if (e.key === "Escape") onClose();
      }
      function handleClickOutside(e) {
        if (modalRef.current && !modalRef.current.contains(e.target)) {
          onClose();
        }
      }
      document.addEventListener("keydown", handleKeyDown);
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("keydown", handleKeyDown);
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [open, onClose]);
  
    if (!open) return null;
  
    return (
      <div className="confirm-modals">
        <div className="confirm-box" ref={modalRef}>
          <p>{title || "Are you sure?"}</p>
          {error && <div style={{ color: "#ffbaba", margin: "8px 0" }}>{error}</div>}
          <div className="confirm-actions">
            <button
              style={{ background: "#e16171" }}
              disabled={loading}
              onClick={onConfirm}
            >
              {loading ? "Deleting..." : (confirmText || "Delete")}
            </button>
            <button
              style={{ background: "#293750" }}
              disabled={loading}
              onClick={onClose}
            >
              {cancelText || "Cancel"}
            </button>
          </div>
        </div>
      </div>
    );
  }
