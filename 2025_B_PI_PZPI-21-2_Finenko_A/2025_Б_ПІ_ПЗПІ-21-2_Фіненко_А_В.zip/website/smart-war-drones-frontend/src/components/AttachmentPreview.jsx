import React, { useState, useEffect } from "react";

export default function AttachmentPreview({ meta }) {
  const [thumbUrl, setThumbUrl] = useState(null);

  useEffect(() => {
    let url = null;
    let isActive = true;
    async function load() {
      if (meta.fileType && meta.fileType.startsWith("image/") && meta.thumbnailUrl) {
        const token = localStorage.getItem("jwt");
        const resp = await fetch(`/api/messages/preview-attachment?file=${encodeURIComponent(meta.thumbnailUrl)}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (resp.ok) {
          url = URL.createObjectURL(await resp.blob());
          if (isActive) setThumbUrl(url);
        }
      }
    }
    load();
    return () => {
      isActive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [meta]);

  if (meta.fileType && meta.fileType.startsWith("image/")) {
    if (thumbUrl) {
      return (
        <img
          src={thumbUrl}
          alt={meta.fileName}
          style={{
            width: 54, height: 54, objectFit: "cover",
            borderRadius: 10, marginRight: 12, background: "#18223c",
            border: "1.5px solid #263a50", boxShadow: "0 2px 11px #131f36aa"
          }}
        />
      );
    }
    return (
      <img
        src="/icons/anotherFileTypeMessage.png"
        alt="Image"
        style={{ width: 34, height: 34, marginRight: 12, opacity: 0.8 }}
      />
    );
  }
  if (meta.fileType && meta.fileType.startsWith("video/")) {
    return (
      <img
        src="/icons/videoMessageIcon.png"
        alt="Video"
        style={{ width: 38, height: 38, marginRight: 13, filter: "drop-shadow(0 2px 10px #0a1223cc)" }}
      />
    );
  }
  if (meta.fileType && meta.fileType.startsWith("audio/")) {
    return (
      <img
        src="/icons/musicMessageIcon.png"
        alt="Audio"
        style={{ width: 34, height: 34, marginRight: 16, filter: "drop-shadow(0 2px 8px #0a122399)" }}
      />
    );
  }
  return (
    <img
      src="/icons/anotherFileTypeMessage.png"
      alt="File"
      style={{ width: 31, height: 31, marginRight: 16, opacity: 0.87 }}
    />
  );
}
