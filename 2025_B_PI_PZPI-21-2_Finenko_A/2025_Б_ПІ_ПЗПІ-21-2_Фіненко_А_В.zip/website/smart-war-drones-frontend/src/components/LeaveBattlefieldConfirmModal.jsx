import { useEffect, useRef } from "react";
import "../styles/components/_leaveBattlefieldConfirmModal.scss";

export default function LeaveBattlefieldConfirmModal({ open, battlefield, onLeave, onCancel, leaving }) {
  const modalRef = useRef();

  // Закриття по Esc чи кліку поза модалкою
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => { if (e.key === "Escape") onCancel(); };
    const onClick = (e) => { if (modalRef.current && !modalRef.current.contains(e.target)) onCancel(); };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("mousedown", onClick);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("mousedown", onClick);
    };
  }, [open, onCancel]);

  if (!open) return null;
  return (
    <div className="leave-bf-overlay">
      <div className="leave-bf-modal" ref={modalRef}>
        <div className="leave-bf-title">
          Are you sure you want to leave the battlefield
          {battlefield?.name ? <> <b>{battlefield.name}</b>?</> : "?"}
        </div>
        <div className="leave-bf-actions">
          <button className="leave-btn" onClick={onLeave} disabled={leaving}>{leaving ? "Leaving..." : "Leave"}</button>
          <button className="cancel-btn" onClick={onCancel} disabled={leaving}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
