import { useState, useRef } from "react";
import "../styles/components/_avatarSelector.scss";
import ReactAvatarEditor from "react-avatar-editor";

export default function AvatarSelector({ selected, onSelect, onUploadCustom }) {
  const [image, setImage] = useState(null);
  const [scale, setScale] = useState(1);
  const editorRef = useRef(null);

  const avatars = Array.from({ length: 10 }, (_, i) => `/avatars/avatar${i + 1}.png`);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) setImage(file);
  };

  const handleApplyCustom = () => {
    if (editorRef.current) {
      editorRef.current.getImageScaledToCanvas().toBlob((blob) => {
        if (blob) onUploadCustom(blob);
      });
      setImage(null);
    }
  };

  const handleCancelCustom = () => {
    setImage(null);
    setScale(1);
  };

  return (
    <div className="avatar-selector">
      <div className="custom-upload-block">
        <label className="custom-upload-btn">
          <input
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={handleFileChange}
          />
          <span>Upload your own</span>
        </label>
      </div>

      {/* Поки обрано зображення для завантаження — показуємо лише редактор */}
      {image ? (
        <div className="editor-block">
          <ReactAvatarEditor
            ref={editorRef}
            image={image}
            width={200}
            height={200}
            border={50}
            borderRadius={100}
            scale={scale}
          />
          <input
            type="range"
            min="1"
            max="3"
            step="0.1"
            value={scale}
            onChange={(e) => setScale(parseFloat(e.target.value))}
            className="scale-slider"
          />
          <div className="editor-actions">
            <button onClick={handleApplyCustom} className="apply-avatar-btn">Apply</button>
            <button onClick={handleCancelCustom} className="cancel-avatar-btn">Cancel</button>
          </div>
        </div>
      ) : (
        <>
          <hr className="divider" />
          <div className="avatar-special-label">
            <span>or Select One Special</span>
          </div>
          <div className="avatar-grid">
            {avatars.map((src) => (
              <img
                key={src}
                src={src}
                className={`avatar-option ${selected === src ? "selected" : ""}`}
                onClick={() => onSelect(src)}
                alt="Avatar"
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
