import { useEffect, useRef } from "react";
import ReactDOM from "react-dom";
import "../styles/pages/_messages.scss";

export default function MessageDeleteModal({
  open,
  message,
  onDelete,
  onCancel,
  deleteForBoth,
  setDeleteForBoth
}) {
  const modalRef = useRef();

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onCancel();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onCancel]);

  if (!open || !message) return null;

  return ReactDOM.createPortal(
    <div className="confirm-modal danger-modal">
      <div className="confirm-box" ref={modalRef} tabIndex={0}>
        <div style={{ fontWeight: 600, fontSize: "1.17rem", marginBottom: 12, color: "#fff" }}>
          Do you really want to delete this message?
        </div>
        <div style={{ margin: "0 0 17px 0", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <input
            type="checkbox"
            id="deleteMsgForBoth"
            checked={deleteForBoth}
            onChange={e => setDeleteForBoth(e.target.checked)}
            style={{ accentColor: "#0057b7", width: 18, height: 18, marginRight: 10 }}
          />
          <label htmlFor="deleteMsgForBoth" style={{ color: "#addbff", fontSize: "1.04rem", cursor: "pointer" }}>
            Delete also for <b>other user</b>?
          </label>
        </div>
        <div className="confirm-actions">
          <button style={{ background: "#e16171" }} onClick={onDelete}>Delete</button>
          <button style={{ background: "#293750" }} onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}
