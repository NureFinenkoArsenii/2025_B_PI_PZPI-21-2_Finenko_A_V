import { useEffect } from "react";
import "../styles/components/PreviewImageModal.scss"; // стиль нижче

export default function PreviewImageModal({ src, alt, open, onClose }) {
    useEffect(() => {
      if (!open) return;
      const onKeyDown = (e) => {
        if (e.key === "Escape") onClose();
      };
      window.addEventListener("keydown", onKeyDown);
      return () => window.removeEventListener("keydown", onKeyDown);
    }, [open, onClose]);
  
    if (!open) return null;
  
    return (
      <div className="preview-image-modal-overlay" onClick={onClose}>
        {/* Хрестик прямо тут */}
        <button
          className="preview-image-modal-close"
          onClick={onClose}
          title="Закрити"
          // щоб клік по хрестику не закривав по overlay
          onClickCapture={e => { e.stopPropagation(); onClose(); }}
        >
          ×
        </button>
        <div
          className="preview-image-modal-content"
          onClick={e => e.stopPropagation()}
        >
          <img src={src} alt={alt || "Preview"} />
        </div>
      </div>
    );
  }
  