import { useEffect, useRef } from "react";

// Простий, стиль як confirm-modal у твоєму проекті
export default function MessageConfirmModal({ open, user, onConfirm, onCancel }) {
  const modalRef = useRef();

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onCancel();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onCancel]);

  if (!open || !user) return null;

  return (
    <div
      className="confirm-modal"
      onMouseDown={e => e.stopPropagation()}  // <--- додаємо stopPropagation
    >
      <div className="confirm-box" ref={modalRef}>
        <img
          src={user.avatarUrl || user.avatarPreviewUrl || "/avatars/avatar1.png"}
          alt="avatar"
          className="avatar-preview"
          style={{ margin: "0 auto 16px", width: 62, height: 62 }}
        />
        <div style={{ fontSize: "1.18rem", fontWeight: 600, marginBottom: 4 }}>{user.name}</div>
        <div style={{ color: "#47bae6", marginBottom: 2 }}>{user.role}</div>
        <div style={{ color: "#bbb", fontSize: "0.97rem", marginBottom: 18, whiteSpace: "pre-line" }}>{user.bio}</div>
        <hr className="divider" />
        <p>Do you want to write a message to this user?</p>
        <div className="confirm-actions" style={{ marginTop: 16, display: "flex", gap: 18, justifyContent: "center" }}>
          <button
            style={{ background: "#00e0d1", color: "#06262c", minWidth: 84 }}
            onClick={onConfirm}
          >Message</button>
          <button
            style={{ background: "#232c41" }}
            onClick={onCancel}
          >Cancel</button>
        </div>
      </div>
    </div>
  );
}
