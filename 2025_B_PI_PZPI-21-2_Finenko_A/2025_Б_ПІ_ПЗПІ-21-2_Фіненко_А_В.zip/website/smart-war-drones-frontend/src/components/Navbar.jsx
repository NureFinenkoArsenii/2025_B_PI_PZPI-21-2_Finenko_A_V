import { useState, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import "../styles/components/_navbar.scss";

export default function Navbar() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  const handleResize = () => setIsMobile(window.innerWidth < 768);

  useEffect(() => {
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleLogoClick = () => {
    setMenuOpen(false);
    window.location.href = "/";
  };

  const handleLinkClick = () => setMenuOpen(false);

  return (
    <>
      <nav className="navbar">
        <div className="logo" onClick={handleLogoClick}>
          SWD
        </div>

        {isMobile && (
          <div className={`menu-toggle ${menuOpen ? "open" : ""}`} onClick={() => setMenuOpen(!menuOpen)}>
            <span></span>
            <span></span>
            <span></span>
          </div>
        )}

        {!isMobile && (
          <div className="nav-items">
            <NavLink to="/" className={({ isActive }) => (isActive ? "active" : "")}>Home</NavLink>
            <NavLink to="/mobile" className={({ isActive }) => (isActive ? "active" : "")}>Mobile App</NavLink>
            <NavLink to="/about" className={({ isActive }) => (isActive ? "active" : "")}>About</NavLink>
            <NavLink to="/contact" className={({ isActive }) => (isActive ? "active" : "")}>Contact</NavLink>
          </div>
        )}
      </nav>

      {menuOpen && isMobile && (
        <div className="mobile-menu">
          <div className="close-btn" onClick={() => setMenuOpen(false)}>×</div>
          
          <NavLink to="/" onClick={handleLinkClick} className={({ isActive }) => (isActive ? "active" : "")}>Home</NavLink>
          <NavLink to="/mobile" onClick={handleLinkClick} className={({ isActive }) => (isActive ? "active" : "")}>Mobile App</NavLink>
          <NavLink to="/about" onClick={handleLinkClick} className={({ isActive }) => (isActive ? "active" : "")}>About</NavLink>
          <NavLink to="/contact" onClick={handleLinkClick} className={({ isActive }) => (isActive ? "active" : "")}>Contact</NavLink>
        </div>
      )}
    </>
  );
}
