import { useEffect, useRef, useState } from "react";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
} from "../utils/passwordCrypto";
import { fetchWithAuth } from "../utils/tokenManager";

export default function BlockUserModal({ open, userId, onBlock, onClose }) {
  const blockModalRef = useRef();
  const [blocking, setBlocking] = useState(false);

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onClose();
    }
    function handleClickOutside(e) {
      if (blockModalRef.current && !blockModalRef.current.contains(e.target)) {
        onClose();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onClose]);

  async function handleBlock() {
    setBlocking(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { userId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      await fetchWithAuth("/api/contacts/block", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      onBlock && onBlock();
      onClose();
    } catch (err) {
      alert("Failed to block user: " + err?.message);
    }
    setBlocking(false);
  }

  if (!open) return null;

  return (
    <div className="confirm-modal">
      <div className="confirm-box" ref={blockModalRef}>
        <p>Do you really want to BAN the person?</p>
        <div className="confirm-actions">
          <button
            style={{ background: "#e16171" }}
            disabled={blocking}
            onClick={handleBlock}
          >
            Block
          </button>
          <button
            style={{ background: "#293750" }}
            disabled={blocking}
            onClick={onClose}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
