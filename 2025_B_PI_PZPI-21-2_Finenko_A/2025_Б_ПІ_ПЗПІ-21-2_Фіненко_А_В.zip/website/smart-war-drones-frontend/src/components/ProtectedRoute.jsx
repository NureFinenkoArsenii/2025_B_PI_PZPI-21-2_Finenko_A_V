import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getValidAccessToken } from "../utils/tokenManager";

export default function ProtectedRoute({ children }) {
  const [checking, setChecking] = useState(true);
  const [isValid, setIsValid] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    async function checkAuth() {
      const token = await getValidAccessToken();
      if (!token) {
        navigate("/");
      } else {
        setIsValid(true);
      }
      setChecking(false);
    }

    checkAuth();
  }, [navigate]);

  if (checking) return <p>Auth checking...</p>;

  return isValid ? children : null;
}
