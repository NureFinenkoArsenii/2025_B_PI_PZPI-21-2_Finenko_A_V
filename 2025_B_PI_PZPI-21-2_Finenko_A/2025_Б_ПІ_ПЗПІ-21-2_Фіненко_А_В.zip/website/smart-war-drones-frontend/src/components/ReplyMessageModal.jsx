// src/components/ReplyMessageModal.jsx
import { useState, useRef, useEffect } from "react";
import ReactDOM from "react-dom";
import "../styles/pages/_messages.scss";

export default function ReplyMessageModal({ open, onReply, onCancel }) {
  const modalRef = useRef();
  const [value, setValue] = useState("");

  useEffect(() => {
    if (open) setValue("");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    function handleKeyDown(e) {
      if (e.key === "Escape") onCancel();
    }
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onCancel();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open, onCancel]);

  if (!open) return null;

  return ReactDOM.createPortal(
    <div className="confirm-modal">
      <div className="confirm-box" ref={modalRef}>
        <div style={{ fontWeight: 600, fontSize: "1.17rem", marginBottom: 18, color: "#fff" }}>
          You are replying to the message
        </div>
        <input
          className="edit-message-input"
          style={{
            width: "100%",
            minHeight: 44,
            fontSize: "1.08rem",
            borderRadius: 8,
            border: "1.5px solid #333c5c",
            background: "#212d44",
            color: "#e9f5ff",
            marginBottom: 20,
            padding: "10px 14px"
          }}
          type="text"
          placeholder="Write your reply..."
          value={value}
          onChange={e => setValue(e.target.value)}
          autoFocus
        />
        <div className="confirm-actions" style={{ marginTop: 10 }}>
          <button
            style={{
              background: value.trim() ? "#47bae6" : "#3a4661",
              color: "#06262c",
              minWidth: 70,
              cursor: value.trim() ? "pointer" : "not-allowed",
              opacity: value.trim() ? 1 : 0.7,
              fontWeight: 600,
            }}
            onClick={() => {
              if (value.trim()) onReply(value);
            }}
            disabled={!value.trim()}
          >
            Send
          </button>
          <button
            style={{ background: "#293750" }}
            onClick={onCancel}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}
