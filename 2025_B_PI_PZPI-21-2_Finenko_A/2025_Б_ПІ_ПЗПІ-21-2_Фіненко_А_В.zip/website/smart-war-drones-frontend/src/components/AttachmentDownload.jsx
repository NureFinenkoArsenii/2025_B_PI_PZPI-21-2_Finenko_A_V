import React, { useState } from "react";

export default function AttachmentDownload({ meta }) {
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState(null);

  const handleDownload = async (e) => {
    e.preventDefault();
    setError(null);
    setDownloading(true);

    try {
      // Якщо потрібна авторизація, додаємо токен (приклад для fetch)
      const token = localStorage.getItem("jwt");
      const resp = await fetch(`/api/messages/download-attachment?file=${encodeURIComponent(meta.fileUrl)}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!resp.ok) throw new Error("Download failed");

      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);

      // Створюємо тимчасову ссилку та тригеримо скачування
      const link = document.createElement("a");
      link.href = url;
      link.download = meta.fileName || "file";
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);
    } catch (err) {
      setError("Не вдалося завантажити файл");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <span>
      <a
        href={`/api/messages/download-attachment?file=${encodeURIComponent(meta.fileUrl)}`}
        onClick={handleDownload}
        style={{
          color: "#7ec0ee",
          textDecoration: "underline",
          marginLeft: 13,
          fontWeight: 500,
          fontSize: "0.98em",
          cursor: downloading ? "not-allowed" : "pointer",
          opacity: downloading ? 0.7 : 1,
        }}
        target="_blank"
        rel="noopener noreferrer"
        tabIndex={-1}
      >
        {downloading ? "Wait..." : (
        <img
            src="/icons/downloadIcon.png"
            alt="Download"
            style={{
            width: 30,
            height: 30,
            marginTop: -2,
            display: "inline-block",
            verticalAlign: "middle",
            opacity: 0.93,
            }}
        />
        )}

      </a>
      {error && (
        <span style={{ color: "#e16171", marginLeft: 6, fontSize: "0.95em" }}>
          {error}
        </span>
      )}
    </span>
  );
}
