import { useEffect, useRef } from "react";
import "../styles/components/DeleteBattlefieldModal.scss"; // Стилі для модалки

export default function DeleteBattlefieldModal({ open, onClose, onDelete, battlefieldName, deleting = false }) {
  const modalRef = useRef(null);

  // Закриття на Esc
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  // Клік поза модалкою
  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="delete-modal-backdrop">
      <div className="delete-modal" ref={modalRef}>
        <div className="delete-modal-title">Are you sure you want to delete the battlefield?</div>
        {battlefieldName && (
          <div className="delete-modal-bf-name">
            <b>{battlefieldName}</b>
          </div>
        )}
        <div className="delete-modal-actions">
        <button className="modal-btn modal-btn-delete" onClick={onDelete} disabled={deleting}>Delete</button>
        <button className="modal-btn" onClick={onClose} disabled={deleting}>Cancel</button>
        </div>
      </div>
    </div>
  );
}
