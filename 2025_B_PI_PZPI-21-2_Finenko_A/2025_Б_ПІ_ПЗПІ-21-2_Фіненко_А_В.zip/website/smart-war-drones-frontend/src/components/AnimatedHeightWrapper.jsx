import { useRef, useLayoutEffect, useState } from "react";
import { motion } from "framer-motion";

export default function AnimatedHeightWrapper({ children, activeKey }) {
  const ref = useRef();
  const [height, setHeight] = useState("auto");

  useLayoutEffect(() => {
    if (ref.current) {
      const newHeight = ref.current.offsetHeight;
      setHeight(newHeight);
    }
  }, [activeKey, children]);

  return (
    <motion.div
      animate={{ height }}
      initial={false}
      transition={{ duration: 0.35, ease: "easeInOut" }}
      style={{ overflow: "hidden", width: "100%" }}
    >
      <div ref={ref} key={activeKey}>
        {children}
      </div>
    </motion.div>
  );
}
