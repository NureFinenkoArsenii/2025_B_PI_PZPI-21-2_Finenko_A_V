import { Canvas } from "@react-three/fiber";
import DustScene from "../components/DustScene";
import { Outlet, useLocation } from "react-router-dom";
import Navbar from "../components/Navbar";
import { AnimatePresence } from "framer-motion";
import "../styles/layout/_layout.scss";

export default function Layout() {
  const location = useLocation();

  return (
    <div className="layout-container">
      <div className="background-canvas">
        <Canvas camera={{ position: [0, 0, 1] }}>
          <DustScene />
        </Canvas>
      </div>

      <div className="foreground">
        <Navbar />
        <div className="content-layer">
          <AnimatePresence mode="wait">
            <Outlet key={location.pathname} />
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
