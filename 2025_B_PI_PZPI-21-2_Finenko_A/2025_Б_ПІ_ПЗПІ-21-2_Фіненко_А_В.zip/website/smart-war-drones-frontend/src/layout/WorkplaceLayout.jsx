import { useState, useEffect } from "react";
import ProfileView from "../pages/ProfileView";
import NavbarWorkplace from "../components/NavbarWorkplace";
import "../styles/layout/_workplaceLayout.scss";
import ContactsModal from "../pages/ContactsModal";
import ProfileModal from "../pages/ProfileModal";

export default function WorkplaceLayout({ avatarProps, setAvatarProps, children, isMessagesMode, friendRequestCount, unreadChatsCount, refreshFriendRequestCount }) {
  const [isProfileVisible, setIsProfileVisible] = useState(false);

  const handleProfileClick = () => setIsProfileVisible(true);
  const handleBackToWorkplace = () => setIsProfileVisible(false);
  const [isContactsVisible, setIsContactsVisible] = useState(false);

  useEffect(() => {
    if (isProfileVisible || isContactsVisible) {
      document.body.classList.add("modal-open");
    } else {
      document.body.classList.remove("modal-open");
    }
    return () => document.body.classList.remove("modal-open");
  }, [isProfileVisible, isContactsVisible]);

  const refreshAvatar = async () => {
    try {
      const res = await fetch("/api/pages/workplace", {
        headers: { Authorization: `Bearer ${localStorage.getItem("jwt")}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.avatarType === "default") {
          setAvatarProps({ avatarType: "default", avatarUrl: data.avatarUrl || "/avatars/avatar1.png" });
        } else if (data.avatarType === "custom") {
          const fileRes = await fetch(`/api/profile/avatar-file/${data.userId}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("jwt")}` }
          });
          const encryptedBlob = fileRes.ok ? await fileRes.arrayBuffer() : null;
          setAvatarProps({
            avatarType: "custom",
            encryptedBlob,
            userId: data.userId
          });
        }
      }
    } catch (e) {
      console.error("[WorkplaceLayout] refreshAvatar error:", e);
      setAvatarProps({ avatarType: "default", avatarUrl: "/avatars/avatar1.png" });
    }
  };

  return (
    <div className="workplace-layout">
      <NavbarWorkplace onProfileClick={handleProfileClick} onContactsClick={() => setIsContactsVisible(true)} avatarProps={avatarProps} friendRequestCount={friendRequestCount} unreadChatsCount={unreadChatsCount}/>
      <div className={`workplace-content${isMessagesMode ? " messages-mode" : ""}`}>
        {children}
      </div>
      <ProfileModal 
        open={isProfileVisible} 
        onClose={() => setIsProfileVisible(false)}
        refreshAvatar={refreshAvatar}
      />
      <ContactsModal 
        open={isContactsVisible} 
        onClose={() => setIsContactsVisible(false)}
        refreshFriendRequestCount={refreshFriendRequestCount}
      />
    </div>
  );
}
