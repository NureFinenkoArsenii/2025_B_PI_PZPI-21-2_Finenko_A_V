import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";

export function generateRandomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

export function bytesToWordArray(bytes) {
  return CryptoJS.lib.WordArray.create(bytes);
}

export function encryptJsonWithAES(jsonObject, keyBytes, ivBytes) {
    const plaintext = JSON.stringify(jsonObject);
    const key = bytesToWordArray(keyBytes);
    const iv = bytesToWordArray(ivBytes);
  
    const encrypted = CryptoJS.AES.encrypt(plaintext, key, {
      iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    return {
      ciphertext: encrypted.toString(),
      iv: iv.toString(CryptoJS.enc.Base64) // уніфікація
    };
  }
  

  export function encryptAESKeyWithRSA(aesKeyBytes, rsaPublicKeyPem) {
    const encrypt = new JSEncrypt();
    encrypt.setPublicKey(rsaPublicKeyPem);
    const base64Key = window.btoa(String.fromCharCode(...aesKeyBytes)); 
    return encrypt.encrypt(base64Key); 
  }
  
