import JSEncrypt from "jsencrypt";
import CryptoJS from "crypto-js";

// Генерація ключів RSA через JSEncrypt (2048 біт)
export function generateKeyPair() {
  const crypt = new JSEncrypt({ default_key_size: 2048 });
  const privateKey = crypt.getPrivateKey(); // PEM, PKCS#1
  const publicKey = crypt.getPublicKey();   // PEM

  // Обрізаємо заголовок і футер з публічного ключа, щоб отримати Base64 без PEM
  // (якщо потрібно в твоєму API)
  const publicKeyBase64 = publicKey
    .replace("-----BEGIN PUBLIC KEY-----", "")
    .replace("-----END PUBLIC KEY-----", "")
    .replace(/\n/g, "");

  return {
    publicKeyBase64,
    privateKey, // PEM PKCS#1 для jsencrypt decrypt
  };
}

// Розшифрування RSA PKCS#1 через JSEncrypt
export function decryptWithPrivateKeyJSEncrypt(privateKeyPem, encryptedBase64) {
  const decryptor = new JSEncrypt();
  decryptor.setPrivateKey(privateKeyPem);
  const decrypted = decryptor.decrypt(encryptedBase64);
  if (!decrypted) {
    throw new Error("RSA decryption failed");
  }
  return decrypted;
}

export function createEncryptedMessage(jsonObj, rsaPublicKeyPem) {
  const aesKey = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(16));

  const payload = JSON.stringify(jsonObj);
  const aesKeyWA = CryptoJS.lib.WordArray.create(aesKey);
  const ivWA = CryptoJS.lib.WordArray.create(iv);
  const enc = CryptoJS.AES.encrypt(payload, aesKeyWA, {
    iv: ivWA,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  const encryptor = new JSEncrypt();
  encryptor.setPublicKey(rsaPublicKeyPem);
  const aesKeyB64 = btoa(String.fromCharCode(...aesKey));
  const encryptedKey = encryptor.encrypt(aesKeyB64);

  return {
    encryptedKey,
    iv: CryptoJS.enc.Base64.stringify(ivWA),
    ciphertext: enc.toString(),
    _aesKeyBytes: aesKey // Використовуй це для розшифрування відповіді!
  };
}
