import JSEncrypt from "jsencrypt";
import CryptoJS from "crypto-js";

export function generateRandomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

export function encryptJsonWithAES_forPassword(jsonObject, keyBytes, ivBytes) {
  // Переконуємось, що текст кодується у форматі UTF-8
  const plaintext = JSON.stringify(jsonObject);
  const keyWordArray = CryptoJS.lib.WordArray.create(keyBytes);
  const ivWordArray = CryptoJS.lib.WordArray.create(ivBytes);

  const encrypted = CryptoJS.AES.encrypt(plaintext, keyWordArray, {
    iv: ivWordArray,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  return {
    ciphertext: encrypted.toString(), // Віддаємо зашифрований текст у вигляді Base64
    iv: CryptoJS.enc.Base64.stringify(ivWordArray),
  };
}

export function encryptAESKeyWithRSA_forPassword(aesKeyBytes, rsaPublicKeyPem) {
  const encryptor = new JSEncrypt();
  encryptor.setPublicKey(rsaPublicKeyPem);

  // 🔐 Коректне кодування без WordArray – працює з .NET
  const base64Key = btoa(String.fromCharCode(...aesKeyBytes));
  return encryptor.encrypt(base64Key);
}

export function bytesToWordArray(u8arr) {
  const words = [];
  for (let i = 0; i < u8arr.length; i += 4) {
    words.push(
      (u8arr[i] << 24) |
      (u8arr[i + 1] << 16) |
      (u8arr[i + 2] << 8) |
      (u8arr[i + 3])
    );
  }
  return CryptoJS.lib.WordArray.create(words, u8arr.length);
}

export function decryptWithAES_fromResponse({ iv, ciphertext }, aesKeyBytes) {
  const keyWordArray = CryptoJS.lib.WordArray.create(aesKeyBytes);
  const ivWordArray = CryptoJS.enc.Base64.parse(iv);

  const decrypted = CryptoJS.AES.decrypt(ciphertext, keyWordArray, {
    iv: ivWordArray,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  const plaintext = decrypted.toString(CryptoJS.enc.Utf8);
  return JSON.parse(plaintext); // масив дронів
}