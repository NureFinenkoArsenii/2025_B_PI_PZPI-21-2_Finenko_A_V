import { jwtDecode } from "jwt-decode";

export async function getValidAccessToken() {
  const token = localStorage.getItem("jwt");
  if (!token) return null;

  try {
    const decoded = jwtDecode(token);
    const now = Date.now() / 1000;

    if (decoded.exp < now + 60) {
      // accessToken скоро закінчиться, оновлюємо
      const res = await fetch("/api/auth/refresh", {
        method: "POST",
        credentials: "include", // <== важливо! додає cookie з refreshToken
      });

      if (res.ok) {
        const newToken = await res.text();
        localStorage.setItem("jwt", newToken);
        return newToken;
      } else {
        localStorage.removeItem("jwt");
        return null;
      }
    }

    return token;
  } catch (err) {
    console.error("❌ Failed to decode accessToken", err);
    localStorage.removeItem("jwt");
    return null;
  }
}

export async function fetchWithAuth(url, options = {}) {
  const token = await getValidAccessToken();
  if (!token) throw new Error("No valid token");

  // Якщо FormData — не ставимо Content-Type
  const isFormData = options.body instanceof FormData;

  const headers = {
    ...options.headers,
    Authorization: `Bearer ${token}`,
    ...(isFormData ? {} : { "Content-Type": "application/json" })
  };
  return fetch(url, { ...options, headers });
}

  
  export function getUserRole() {
    const token = localStorage.getItem("jwt");
    if (!token) return null;
  
    try {
      const decoded = jwtDecode(token);
      return (
        decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] ||
        decoded["role"] ||
        null
      );
    } catch {
      return null;
    }
  }
  
  export function getUserIdFromToken() {
    const token = localStorage.getItem("jwt");
    if (!token) return null;
  
    try {
      const decoded = jwtDecode(token);
      return (
        decoded["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"] ||
        decoded["sub"] ||
        null
      );
    } catch {
      return null;
    }
  }
