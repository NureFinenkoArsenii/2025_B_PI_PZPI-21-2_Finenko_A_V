import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";

export function generateRandomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

export function bytesToWordArray(bytes) {
  return CryptoJS.lib.WordArray.create(bytes);
}

export function encryptDataAES(data, keyBytes, ivBytes) {
  const plaintext = JSON.stringify(data);
  const key = bytesToWordArray(keyBytes);
  const iv = bytesToWordArray(ivBytes);

  const encrypted = CryptoJS.AES.encrypt(plaintext, key, {
    iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  return {
    ciphertext: encrypted.toString(),
    iv: iv.toString(CryptoJS.enc.Base64),
  };
}

export function encryptAESKeyWithRSA(aesKeyBytes, publicKeyPem) {
  const rsa = new JSEncrypt();
  rsa.setPublicKey(publicKeyPem);

  const base64Key = btoa(String.fromCharCode(...aesKeyBytes));
  return rsa.encrypt(base64Key);
}
