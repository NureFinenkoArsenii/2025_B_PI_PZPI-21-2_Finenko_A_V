import React, { useRef, useEffect, useState, useCallback } from "react";
import ReactDOM from "react-dom";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import ChooseFocusAndScale from "../battlefields/ChooseFocusAndScale";
import "../styles/pages/_battlefieldModal.scss";
import { fetchWithAuth } from "../utils/tokenManager";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
} from "../utils/passwordCrypto";

const getLayerName = (url) => {
  if (!url) return "";
  if (url.includes("openstreetmap")) return "OpenStreetMap";
  if (url.includes("stadiamaps")) return "Stadia";
  if (url.includes("cartocdn")) return "CartoDBVoyager";
  if (url.includes("dark-v10")) return "MapboxDark";
  if (url.includes("satellite-streets-v11")) return "MapboxSatellite";
  if (url.includes("traffic-day-v2")) return "MapboxTraffic";
  return url.slice(0, 32) + "...";
};

export default function EditBattlefieldModal({
  open,
  onClose,
  battlefield,
  onEdit,
}) {
  const modalRef = useRef(null);
  const [mode, setMode] = useState("editing"); // "editing" | "focus"
  const [name, setName] = useState(battlefield?.name || "");
  const [about, setAbout] = useState(battlefield?.about || "");
  const [loading, setLoading] = useState(false);
  const [focusInfo, setFocusInfo] = useState(null); // {center, zoom, tileLayer, previewUrl, croppedFile?}
  const [initialFocusInfo, setInitialFocusInfo] = useState(null);
  const [showMapModal, setShowMapModal] = useState(false);

  // Скидаємо стейти при відкритті модалки/нового battlefield
  useEffect(() => {
    if (!open) return;
    setMode("editing");
    setName(battlefield?.name || "");
    setAbout(battlefield?.about || "");
    const _focus = battlefield
      ? {
          center: battlefield.mapFocus ? JSON.parse(battlefield.mapFocus) : [48.3794, 31.1656],
          zoom: battlefield.mapSize ? Number(battlefield.mapSize) : 6,
          tileLayer: battlefield.mapStyle || "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          previewUrl: battlefield.resolvedPreviewUrl || "/battlefieldPreview/defaultBattlefieldPreview.png",
          croppedFile: undefined,
        }
      : null;
    setFocusInfo(_focus);
    setInitialFocusInfo(_focus);
    setShowMapModal(false);
  }, [open, battlefield]);

  // Перевіряємо, чи змінились карта або превʼю
  const isMapOrPreviewChanged = () => {
    if (!focusInfo || !initialFocusInfo) return false;
    return (
      JSON.stringify(focusInfo.center) !== JSON.stringify(initialFocusInfo.center) ||
      focusInfo.zoom !== initialFocusInfo.zoom ||
      focusInfo.tileLayer !== initialFocusInfo.tileLayer ||
      (focusInfo.croppedFile !== undefined && focusInfo.croppedFile !== null)
    );
  };

  const hasChanges =
    name.trim() !== (battlefield?.name || "") ||
    about !== (battlefield?.about || "") ||
    isMapOrPreviewChanged();

  // Закриття по кліку поза модалкою та Esc
  const handleClickOutside = useCallback(
    (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    },
    [onClose]
  );
  const handleEsc = useCallback(
    (e) => {
      if (e.key === "Escape") onClose();
    },
    [onClose]
  );
  useEffect(() => {
    if (!open) return;
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [handleClickOutside, handleEsc, open]);

  // --- Зберегти зміни
  const handleEdit = async () => {
    setLoading(true);
    try {
      // 1. Ключі
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);

      // 2. Payload
      let payload = {
        BattlefieldId: battlefield.id,
        Name: name,
        About: about,
      };
      if (isMapOrPreviewChanged()) {
        payload = {
          ...payload,
          MapFocus: JSON.stringify(focusInfo.center),
          MapSize: focusInfo.zoom.toString(),
          MapStyle: focusInfo.tileLayer,
        };
      }

      // 3. Шифруємо
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);

      // 4. Визначаємо croppedFile
      const croppedFile = (isMapOrPreviewChanged() && focusInfo?.croppedFile) ? focusInfo.croppedFile : null;

      // 5. Формуємо FormData
      const formData = new FormData();
      formData.append("encrypted", JSON.stringify({
        EncryptedKey: encryptedKey,
        Iv: ivBase64,
        Ciphertext: ciphertext
      }));
      if (croppedFile) {
        const arrayBuffer = await croppedFile.arrayBuffer();
        const cryptoKey = await window.crypto.subtle.importKey(
          "raw",
          aesKey,
          { name: "AES-CBC" },
          false,
          ["encrypt"]
        );
        const encryptedBuffer = await window.crypto.subtle.encrypt(
          { name: "AES-CBC", iv },
          cryptoKey,
          arrayBuffer
        );
        const encryptedBlob = new Blob([encryptedBuffer], { type: croppedFile.type });
        formData.append("preview", encryptedBlob, "preview.png");
      }
      

      // Debug (опціонально)
      // console.log("Payload to encrypt:", payload);
      // if (croppedFile) console.log("FormData.preview:", croppedFile);

      const resp = await fetchWithAuth("/api/battlefields/edit-battlefield", {
        method: "POST",
        body: formData,
      });
      if (!resp.ok) throw new Error(await resp.text());

      onEdit && onEdit();
    } catch (err) {
      alert("Failed to update battlefield: " + (err?.message || err));
    } finally {
      setLoading(false);
    }
  };

  // --- Render ---
  if (!open) return null;

  return ReactDOM.createPortal(
    <div className="battlefield-overlay">
      <div className="battlefield-modal" ref={modalRef} tabIndex={-1}>
        <button className="close-btn" onClick={onClose}>
          ×
        </button>
        <AnimatedHeightWrapper activeKey={mode}>
          {/* HEADER */}
          <div className="battlefield-header-row" style={{ marginBottom: 14 }}>
            <img
              src="/icons/editBattlefieldInfoIcon.png"
              alt="edit battlefield icon"
              className="battlefield-header-icon"
            />
            <div className="battlefield-header" style={{ fontSize: "1.5rem" }}>
              {mode === "editing" && "Editing the Battlefield"}
              {mode === "focus" && "Focusing and Scaling"}
            </div>
          </div>
          <hr className="divider" />

          {/* --- EDITING --- */}
          {mode === "editing" && (
            <div className="battlefield-section">
              <input
                type="text"
                className="battlefield-input"
                placeholder="Name your battlefield"
                value={name}
                onChange={e => setName(e.target.value)}
                autoFocus
                maxLength={36}
                style={{ marginBottom: 12 }}
              />
              <textarea
                className="battlefield-textarea"
                placeholder="Purpose of the battlefield (About)"
                value={about}
                onChange={e => setAbout(e.target.value)}
                rows={3}
              />
              <hr className="divider" />
              <button
                className="battlefield-add-btn"
                type="button"
                style={{ fontWeight: 600, fontSize: "1.08rem" }}
                onClick={() => setMode("focus")}
              >
                <img src="/icons/mapIcon.png" alt="Map" className="battlefield-btn-icon" />
                Focus and Scale
              </button>
              <hr className="divider" />
              <div className="battlefield-actions-row">
                <button
                  className="battlefield-add-btn battlefield-primary-btn"
                  style={{
                    width: "100%",
                    opacity: hasChanges ? 1 : 0.5,
                    pointerEvents: hasChanges ? "auto" : "none",
                  }}
                  onClick={handleEdit}
                  disabled={loading || !hasChanges}
                >
                  {loading ? "Saving..." : "Edit the Battlefield"}
                </button>
              </div>
            </div>
          )}

          {/* --- FOCUS --- */}
          {mode === "focus" && (
            <div className="battlefield-section">
              <div
                className="battlefield-explanation"
                style={{
                  marginBottom: 18,
                  color: "#eee",
                  fontSize: "1.14rem",
                  fontWeight: 500,
                }}
              >
                Change typical position on the map when the battlefield opened:
              </div>
              <button
                className="battlefield-add-btn"
                type="button"
                style={{
                  width: "60%",
                  fontWeight: 600,
                  fontSize: "1.08rem",
                  marginBottom: 16,
                }}
                onClick={() => setShowMapModal(true)}
              >
                <img src="/icons/mapIcon.png" alt="Map" className="battlefield-btn-icons" />
                Change on the map
              </button>
              <div
                className="battlefield-avatar-tip"
                style={{
                  fontSize: "0.96rem",
                  color: "#80fff0",
                  fontStyle: "italic",
                  marginBottom: 16,
                  textAlign: "center",
                }}
              >
                An avatar for the battlefield will be selected automatically*
              </div>
              {focusInfo && (
                <>
                  <hr className="divider" />
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      marginTop: 16,
                    }}
                  >
                    <img
                      src={focusInfo.previewUrl}
                      alt="Battlefield Avatar"
                      style={{
                        width: 116,
                        height: 116,
                        objectFit: "cover",
                        borderRadius: 18,
                        marginBottom: 14,
                        border: "3px solid #313741",
                        boxShadow: "0 2px 16px #000b",
                        background: "#252b33",
                      }}
                    />
                    <div style={{ color: "#90f3e6", marginBottom: 4, fontSize: "0.98rem" }}>
                      <b>Coordinates: </b>
                      {focusInfo.center && Array.isArray(focusInfo.center)
                        ? `${Number(focusInfo.center[0]).toFixed(5)}, ${Number(focusInfo.center[1]).toFixed(5)}`
                        : "—"}
                    </div>
                    <div style={{ color: "#d0edff", marginBottom: 4, fontSize: "0.98rem" }}>
                      <b>Zoom:</b> {focusInfo.zoom}
                    </div>
                    <div style={{ color: "#ffd590", fontSize: "0.98rem" }}>
                      <b>Map style:</b> {getLayerName(focusInfo.tileLayer)}
                    </div>
                  </div>
                </>
              )}
              <button
                className="battlefield-add-btn battlefield-back-btn"
                type="button"
                style={{
                  width: "100%",
                  background: "#232932",
                  color: "#fff",
                  fontWeight: 600,
                  fontSize: "1.02rem",
                  marginTop: 24,
                }}
                onClick={() => setMode("editing")}
              >
                Back to Editing
              </button>
            </div>
          )}
        </AnimatedHeightWrapper>

        {/* Map modal (ChooseFocusAndScale) — повертає croppedFile */}
        {showMapModal && (
          <ChooseFocusAndScale
            onDone={info => {
              setFocusInfo(info); // info містить croppedFile!
              setShowMapModal(false);
            }}
            onCancel={() => setShowMapModal(false)}
          />
        )}
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}
