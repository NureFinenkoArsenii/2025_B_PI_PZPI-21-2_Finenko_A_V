import { useEffect, useState, useRef } from "react";
import { fetchWithAuth } from "../utils/tokenManager";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import BlockUserModal from "../components/BlockUserModal";

export default function FriendRequests({ refreshFriendRequestCount }) {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Reject modal
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectRequestId, setRejectRequestId] = useState(null);
  const rejectModalRef = useRef();

  // Accept modal
  const [showAcceptModal, setShowAcceptModal] = useState(false);
  const [acceptRequestId, setAcceptRequestId] = useState(null);
  const [acceptSenderId, setAcceptSenderId] = useState(null);
  const acceptModalRef = useRef();

  // Block modal
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [blockUserId, setBlockUserId] = useState(null);

  useEffect(() => { loadRequests(); }, []);

  async function loadRequests() {
    setLoading(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);

      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/requests", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setRequests(data);
      if (refreshFriendRequestCount) refreshFriendRequestCount();
      setLoading(false);
    } catch (err) {
      console.error("❌ Failed to load requests", err);
    }
    setLoading(false);
  }

  // --- CUSTOM AVATAR LOGIC (повертаємо!) ---
  useEffect(() => {
    requests.forEach(async (req, idx) => {
      if (req.avatarType === "custom" && !req.avatarUrl && req.senderIdPlain) {
        try {
          const token = localStorage.getItem("jwt");
          const fileRes = await fetch(`/api/profile/avatar-file/${req.senderIdPlain}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (!fileRes.ok) throw new Error("Cannot get avatar file");
          const fileBuffer = await fileRes.arrayBuffer();

          const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
          const rsaKeyBase64 = await rsaKeyRes.text();
          const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

          const sessionAesKey = generateRandomBytes(16);
          const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
          const encryptor = new JSEncrypt();
          encryptor.setPublicKey(rsaKeyPem);
          const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

          const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${req.senderIdPlain}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ encryptedSessionAesKey }),
          });
          const { iv, ciphertext } = await resp.json();

          const keyBytes = sessionAesKey;
          const ivWord = CryptoJS.enc.Base64.parse(iv);
          const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
            iv: ivWord,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          });

          const avatarAesKeyBytes = Uint8Array.from(
            decrypted.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decrypted.sigBytes)
          );

          const fileBytes = new Uint8Array(fileBuffer);
          const fileIv = fileBytes.slice(0, 16);
          const fileCipher = fileBytes.slice(16);

          const decWord = CryptoJS.AES.decrypt(
            { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
            CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
            {
              iv: CryptoJS.lib.WordArray.create(fileIv),
              mode: CryptoJS.mode.CBC,
              padding: CryptoJS.pad.Pkcs7,
            }
          );

          const uint8Decrypted = Uint8Array.from(
            decWord.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decWord.sigBytes)
          );

          const blob = new Blob([uint8Decrypted], { type: "image/png" });
          const url = URL.createObjectURL(blob);

          setRequests(prev =>
            prev.map((r, i) => i === idx ? { ...r, avatarUrl: url } : r)
          );
        } catch (err) {
          console.error("❌ Failed to fetch/decrypt custom avatar:", err);
        }
      }
    });
    // eslint-disable-next-line
  }, [requests.length]);

  function getFirstTwoLines(text) {
    if (!text) return "";
    const lines = text.split('\n');
    if (lines.length <= 2) return text;
    return lines.slice(0, 2).join('\n') + '…';
  }

  async function handleAccept(requestId, senderId) {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const payload = { requestId, senderId };

      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);

      await fetchWithAuth("/api/contacts/accept", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      loadRequests();
    } catch (err) {
      console.error("❌ Accept failed", err);
    }
  }

  async function handleReject(requestId) {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const payload = { requestId };

      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);

      await fetchWithAuth("/api/contacts/reject", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      loadRequests();
    } catch (err) {
      console.error("❌ Reject failed", err);
    }
    setShowRejectModal(false);
    setRejectRequestId(null);
  }

  if (loading) return <div className="loading-text">Loading requests...</div>;
  if (requests.length === 0) return <div className="empty-text">There are no friend requests now</div>;

  return (
    <div className="requests-list">
      {requests.map((req, idx) => (
        <div key={req.requestId} className="request-item">
          <img
            src={
              req.avatarType === "custom"
                ? (req.avatarUrl || "/avatars/avatar1.png")
                : (req.avatarUrl || "/avatars/avatar1.png")
            }
            alt="avatar"
            className="avatar-preview"
          />
          <div className="info">
            <div className="name">{req.name}</div>
            <div className="role">{req.role}</div>
            <div className="bio">
              {getFirstTwoLines(
                typeof req.bio === "string"
                  ? req.bio
                  : typeof req.bio?.bio === "string"
                  ? req.bio.bio
                  : ""
              )}
            </div>
          </div>
          <div className="actions">
            <button
              className="icon-action-btn"
              title="Accept"
              onClick={() => {
                setAcceptRequestId(req.requestId);
                setAcceptSenderId(req.senderId);
                setShowAcceptModal(true);
              }}
            >
              <img src="/icons/acceptIcon.png" alt="Accept" />
            </button>
            <button
              className="icon-action-btn"
              title="Reject"
              onClick={() => {
                setRejectRequestId(req.requestId);
                setShowRejectModal(true);
              }}
            >
              <img src="/icons/rejectIcon.png" alt="Reject" />
            </button>
            <button
              className="icon-action-btn"
              title="Block user"
              onClick={() => {
                setBlockUserId(req.senderIdPlain);
                setShowBlockModal(true);
              }}
            >
              <img src="/icons/blockUserIcon.png" alt="Block user" />
            </button>
          </div>
        </div>
      ))}

      {showRejectModal && (
        <div className="confirm-modal">
          <div className="confirm-box" ref={rejectModalRef}>
            <p>Do you wanna Reject the request?</p>
            <div className="confirm-actions">
              <button
                style={{ background: "#e16171" }}
                onClick={() => handleReject(rejectRequestId)}
              >Reject</button>
              <button
                style={{ background: "#293750" }}
                onClick={() => {
                  setShowRejectModal(false);
                  setRejectRequestId(null);
                }}
              >Cancel</button>
            </div>
          </div>
        </div>
      )}

      {showAcceptModal && (
        <div className="confirm-modal">
          <div className="confirm-box" ref={acceptModalRef}>
            <p>Do you want to Add the user to Friends?</p>
            <div className="confirm-actions">
              <button
                style={{ background: "#1fe1b2", color: "#0c2b1b" }}
                onClick={() => {
                  handleAccept(acceptRequestId, acceptSenderId);
                  setShowAcceptModal(false);
                  setAcceptRequestId(null);
                  setAcceptSenderId(null);
                }}
              >Add</button>
              <button
                style={{ background: "#293750" }}
                onClick={() => {
                  setShowAcceptModal(false);
                  setAcceptRequestId(null);
                  setAcceptSenderId(null);
                }}
              >Cancel</button>
            </div>
          </div>
        </div>
      )}

      <BlockUserModal
        open={showBlockModal}
        userId={blockUserId}
        onBlock={loadRequests}
        onClose={() => {
          setShowBlockModal(false);
          setBlockUserId(null);
        }}
      />
    </div>
  );
}
