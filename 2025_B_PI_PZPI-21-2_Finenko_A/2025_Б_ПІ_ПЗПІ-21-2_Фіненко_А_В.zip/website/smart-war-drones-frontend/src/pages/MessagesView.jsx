import Split from "react-split";
import "../styles/pages/_messages.scss";
import { useState, useEffect, useCallback, useRef } from "react";
import NewChatModal from "./NewChatModal";
import { fetchWithAuth, getUserIdFromToken } from "../utils/tokenManager";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import { createEncryptedMessage } from "../utils/cryptoUtils";
import ChatDeleteModal from "../components/ChatDeleteModal";
import MessageDeleteModal from "../components/MessageDeleteModal";
import EditMessageModal from "../components/EditMessageModal";
import ReplyMessageModal from "../components/ReplyMessageModal";
import { HubConnectionBuilder, LogLevel } from "@microsoft/signalr";
import React from "react";
import { FaPaperclip } from "react-icons/fa";
import AttachmentPreview from "../components/AttachmentPreview";
import AttachmentDownload from "../components/AttachmentDownload";
import ReactDOM from "react-dom";
import MessageConfirmModal from "../components/MessageConfirmModal";


const SPLIT_SIZES_KEY = "swdr-messages-split-sizes";

export default function MessagesView({ onUnreadChatsCountChange }) {
  const [search, setSearch] = useState("");
  const [chats, setChats] = useState([]);
  const [selectedChatId, setSelectedChatId] = useState(null);
  const [activeChatData, setActiveChatData] = useState(null);
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [messagesPublicKey, setMessagesPublicKey] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const prevMsgsCountRef = useRef(0);
  const messagesEndRef = useRef(null);
  const [showMessageConfirmModal, setShowMessageConfirmModal] = useState(false);
  const [selectedUserForChat, setSelectedUserForChat] = useState(null);
  const [customAvatars, setCustomAvatars] = useState({});
  const [contextMenu, setContextMenu] = useState({ visible: false, x: 0, y: 0, chatId: null });
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteForBoth, setDeleteForBoth] = useState(false); // Чи "для обох"
  const [chatToDelete, setChatToDelete] = useState(null); // Інфа про чат
  const [msgContextMenu, setMsgContextMenu] = useState({ visible: false, x: 0, y: 0, msgId: null });
  const [showMsgDeleteModal, setShowMsgDeleteModal] = useState(false);
  const [msgToDelete, setMsgToDelete] = useState(null);
  const [deleteMsgForBoth, setDeleteMsgForBoth] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [pendingFiles, setPendingFiles] = useState([]); // [{file, previewUrl, meta}]
  const [uploading, setUploading] = useState(false);
  const [editMsg, setEditMsg] = useState(null); 
  const prevChatIdRef = useRef();
  const [showNewMessagesLabel, setShowNewMessagesLabel] = useState(false);
  const prevMessagesRef = useRef();
  const [showReplyModal, setShowReplyModal] = useState(false);
  const [replyMsg, setReplyMsg] = useState(null);
  const [unreadChatsCount, setUnreadChatsCount] = useState(0);
  const [signalRConnected, setSignalRConnected] = useState(false);
  const signalRConnection = useRef(null);
  const [firstUnreadId, setFirstUnreadId] = useState(null);
  const [showNewMessages, setShowNewMessages] = useState(true);
  const [highlightedMsgId, setHighlightedMsgId] = useState(null);
  const msgRefs = useRef({});
  const checkedMessages = useRef(new Set());
  const lastHighlightedMsgId = useRef(null);
  const fileInputRef = useRef();
  useEffect(() => {
    if (!chats) return;
    const count = chats.filter(chat => Number(chat.unreadCount) > 0).length;
    if (onUnreadChatsCountChange) onUnreadChatsCountChange(count);
  }, [chats, onUnreadChatsCountChange]);

  function handleOpenMsgConfirm(user) {
    setSelectedUserForChat(user);
    setShowMessageConfirmModal(true);
  }

  const getInitialSplitSizes = () => {
    try {
      const fromLS = localStorage.getItem(SPLIT_SIZES_KEY);
      if (fromLS) {
        const arr = JSON.parse(fromLS);
        // Перевірка, що це масив чисел, довжини 2 (захист від помилок)
        if (Array.isArray(arr) && arr.length === 2 && arr.every(n => typeof n === "number")) {
          return arr;
        }
      }
    } catch {}
    // Фолбек: стандартний розподіл
    return [30, 70];
  };
  
  async function handleConfirmStartChat() {
    setShowMessageConfirmModal(false);
    if (selectedUserForChat) {
      // Тут можна одразу викликати openChat(selectedUserForChat.id);
      await openChat(selectedUserForChat.id || selectedUserForChat.friendId);
      setSelectedUserForChat(null);
    }
  }
  

  function handleMessagesScroll(e) {
    if (!selectedChatId) return;
    const scrollTop = e.target.scrollTop;
    localStorage.setItem('chat-scroll-' + selectedChatId, scrollTop);
  }
  
  useEffect(() => {
    if (!selectedChatId) return;
    const messagesListEl = document.querySelector('.messages-list');
    if (!messagesListEl) return;
  
    // Пробуємо відновити scrollTop для чату
    const storedScroll = localStorage.getItem('chat-scroll-' + selectedChatId);
    if (storedScroll !== null) {
      messagesListEl.scrollTop = parseInt(storedScroll, 10);
    } else if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "auto" });
    }
  }, [selectedChatId]); // <--- !!! тільки selectedChatId
  
  useEffect(() => {
    if (!chatMessages || !activeChatData) return;
    const sharedSecretBytes = Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0));
    const myId = getUserIdFromToken();
  
    if (chatMessages.length > 0) {
      const lastMsg = chatMessages[chatMessages.length - 1];
      const senderId = decryptField(lastMsg.senderId, sharedSecretBytes, lastMsg.iv);
      // Якщо твоє, скроль до кінця
      if (senderId === myId) {
        // Чекаємо наступний кадр, щоб DOM промалювався
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
        }, 0);
      }
    }
  }, [chatMessages, activeChatData]);
  
  useEffect(() => {
    // очищати pendingFiles при mount, якщо це не FileList
    setPendingFiles([]);
  }, []);

  useEffect(() => {
    setPendingFiles([]); // або при виборі нового чату
  }, [selectedChatId]);

  useEffect(() => {
    return () => {
      pendingFiles.forEach(pf => {
        if (pf.previewUrl) URL.revokeObjectURL(pf.previewUrl);
      });
    };
  }, [pendingFiles]);

  function removePendingFile(i) {
    setPendingFiles(prev => {
      const fileToRemove = prev[i];
      if (fileToRemove?.previewUrl) URL.revokeObjectURL(fileToRemove.previewUrl);
      return prev.filter((_, idx) => idx !== i);
    });
  }

  useEffect(() => {
    if (!messagesPublicKey) return; // Чекаємо публічний ключ
  
    const myId = getUserIdFromToken();
    const conn = new HubConnectionBuilder()
      .withUrl("http://localhost:5189/hubs/friends", {
        accessTokenFactory: () => localStorage.getItem("jwt")
      })
      .withAutomaticReconnect()
      .configureLogging(LogLevel.Information)
      .build();
  
    // === SignalR Event Handlers ===
  
    // НОВЕ ПРИВАТНЕ ПОВІДОМЛЕННЯ (від іншого користувача)
    conn.on("ReceivePrivateMessage", (data) => {
      if (!activeChatData || data.chatId !== activeChatData.friendId) {
        // Якщо не у відкритому чаті — можливо показати нотифікацію
        // або просто оновити список чатів (можна loadChats().then(setChats); )
        return;
      }
      // Оновити активний чат
      openChat(data.chatId);
    });
  
    // Відправлено власне повідомлення (опціонально)
    conn.on("MessageSent", (data) => {
      if (!activeChatData || data.chatId !== activeChatData.friendId) return;
      // Можна оновити свій чат (звісно, якщо потрібно)
      openChat(data.chatId);
    });
  
    // Видалено повідомлення
    conn.on("MessageDeleted", (data) => {
      if (!activeChatData || data.chatId !== activeChatData.friendId) return;
      setChatMessages(msgs => msgs.filter(m => m.id !== data.messageId));
    });
  
    // Відредаговано повідомлення
    conn.on("MessageEdited", (data) => {
      if (!activeChatData || !data.messageId) return;
      // Просто перезавантажити чат
      openChat(activeChatData.friendId);
    });
  
    // // Прочитано повідомлення
    // conn.on("MessageChecked", (data) => {
    //   if (!activeChatData || !data.messageId) return;
    //   setChatMessages(msgs =>
    //     msgs.map(m =>
    //       m.id === data.messageId
    //         ? { ...m, isChecked: aesEncryptField(JSON.stringify(true), Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0)), m.iv) }
    //         : m
    //     )
    //   );
    // });
  
    // Чат видалено
    conn.on("ChatDeleted", (data) => {
      if (activeChatData && data.chatId === activeChatData.friendId) {
        setActiveChatData(null);
        setSelectedChatId(null);
        setChatMessages([]);
      }
      loadChats().then(setChats);
    });
  
    // Оновити список чатів (наприклад, додано новий)
    conn.on("ChatsUpdated", () => {
      loadChats().then(setChats);
    });
  
    conn.on("UnreadCountChanged", ({ chatId, unreadCount }) => {
      setChats(prevChats =>
        prevChats.map(chat =>
          chat.id === chatId
            ? { ...chat, unreadCount }
            : chat
        )
      );
    });

    // === Запуск конекції та підписка на групу ===
    conn.start()
      .then(() => {
        setSignalRConnected(true);
        conn.invoke("Subscribe", myId);
      })
      .catch(err => {
        setSignalRConnected(false);
      });
  
    signalRConnection.current = conn;
  
    // Clean up
    return () => {
      if (signalRConnection.current) {
        signalRConnection.current.stop();
        signalRConnection.current = null;
      }
      setSignalRConnected(false);
    };
  // eslint-disable-next-line
  }, [messagesPublicKey, activeChatData?.friendId]);

  function handleAttachClick() {
    fileInputRef.current?.click();
  }
  function handleFiles(files) {
    // Додаємо у pendingFiles, показуємо preview
    const arr = Array.from(files).slice(0, 4); // максимум 4 вкладення
    arr.forEach(file => {
      const url = URL.createObjectURL(file);
      setPendingFiles(prev => [...prev, { file, previewUrl: url, meta: null }]);
    });
  }
  function formatFileSize(size) {
    if (!size || isNaN(Number(size))) return "";
    const n = Number(size);
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(2)} MB`;
    return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
  }

  const [splitSizes, setSplitSizes] = useState(getInitialSplitSizes);
  const handleSplitDrag = (sizes) => {
    setSplitSizes(sizes);
    try {
      localStorage.setItem(SPLIT_SIZES_KEY, JSON.stringify(sizes));
    } catch {}
  };
  // ================= Фільтрація чатів (SIDEBAR) =================
  const filteredChats =
    search.length > 0
      ? chats.filter((chat) => (chat.name || "").toLowerCase().includes(search.toLowerCase()))
      : chats;

  // ================= UTILS =================
  function genRandomBytes(len) {
    return window.crypto.getRandomValues(new Uint8Array(len));
  }

  function decryptField(ciphertext, keyBytes, ivBase64) {
    try {
      const key = CryptoJS.lib.WordArray.create(keyBytes);
      const iv = CryptoJS.enc.Base64.parse(ivBase64);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      return decrypted.toString(CryptoJS.enc.Utf8);
    } catch {
      return "❌";
    }
  }

  async function createImageThumbnail(file, maxWidth = 200, maxHeight = 200) {
    return new Promise((resolve, reject) => {
      const img = new window.Image();
      const reader = new FileReader();
      reader.onload = e => {
        img.src = e.target.result;
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let { width, height } = img;
          const scale = Math.min(maxWidth / width, maxHeight / height, 1);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
          canvas.width = width;
          canvas.height = height;
          canvas.getContext("2d").drawImage(img, 0, 0, width, height);
          canvas.toBlob(blob => resolve(blob), "image/jpeg", 0.78);
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  useEffect(() => {
    lastHighlightedMsgId.current = null;
  }, [selectedChatId]);

  useEffect(() => {
    if (!msgContextMenu.visible) return;
    function handleClick(e) {
      const menu = document.getElementById("msg-context-menu");
      if (menu && !menu.contains(e.target)) {
        setMsgContextMenu(prev => ({ ...prev, visible: false }));
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [msgContextMenu.visible]);

  useEffect(() => {
    if (!contextMenu.visible) return;

    function handleClick(e) {
      // Якщо клік був не по самому меню
      const menu = document.getElementById("chat-context-menu");
      if (menu && !menu.contains(e.target)) {
        setContextMenu(prev => ({ ...prev, visible: false }));
      }
    }

    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [contextMenu.visible]);

  async function handleDeleteChat() {
    if (!chatToDelete) return;
    try {
      const token = localStorage.getItem("jwt");
      const resp = await fetchWithAuth("/api/messages/delete-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          friendId: chatToDelete.id,
          deleteForBoth: deleteForBoth,
        }),
      });
      // Обробка відповіді (навіть якщо вже видалено)
      setShowDeleteModal(false);
      setActiveChatData(null);
      setSelectedChatId(null);
      setChatMessages([]);
      // Оновлюємо список чатів
      const chatsArr = await loadChats();
      setChats(chatsArr);
    } catch (err) {
      alert("Failed to delete chat: " + (err?.message || ""));
      setShowDeleteModal(false);
    }
  }

  useEffect(() => {
    if (showDeleteModal) setDeleteForBoth(false);
  }, [showDeleteModal]);

  async function fetchAndDecryptCustomAvatar(userId, cb) {
    try {
      const token = localStorage.getItem("jwt");
      const fileRes = await fetch(`/api/profile/avatar-file/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!fileRes.ok) throw new Error("Cannot get avatar file");
      const fileBuffer = await fileRes.arrayBuffer();
  
      const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
      const rsaKeyBase64 = await rsaKeyRes.text();
      const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      const sessionAesKey = genRandomBytes(16);
      const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(rsaKeyPem);
      const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);
  
      const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedSessionAesKey }),
      });
      const { iv, ciphertext } = await resp.json();
  
      const keyBytes = sessionAesKey;
      const ivWord = CryptoJS.enc.Base64.parse(iv);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
        iv: ivWord,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
  
      const avatarAesKeyBytes = Uint8Array.from(
        decrypted.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decrypted.sigBytes)
      );
  
      const fileBytes = new Uint8Array(fileBuffer);
      const fileIv = fileBytes.slice(0, 16);
      const fileCipher = fileBytes.slice(16);
  
      const decWord = CryptoJS.AES.decrypt(
        { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
        CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
        {
          iv: CryptoJS.lib.WordArray.create(fileIv),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );
  
      const uint8Decrypted = Uint8Array.from(
        decWord.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decWord.sigBytes)
      );
  
      const blob = new Blob([uint8Decrypted], { type: "image/png" });
      const url = URL.createObjectURL(blob);
  
      cb(url);
    } catch (err) {
      cb(null);
    }
  }
  
  useEffect(() => {
    filteredChats.forEach(chat => {
      if (
        chat.avatarType === "custom" &&
        !customAvatars[chat.id]
      ) {
        fetchAndDecryptCustomAvatar(chat.id, url =>
          setCustomAvatars(prev => ({ ...prev, [chat.id]: url }))
        );
      }
    });
  }, [filteredChats, customAvatars]);
  
  useEffect(() => {
    if (
      activeChatData &&
      activeChatData.friendAvatarType === "custom" &&
      !customAvatars[activeChatData.friendId]
    ) {
      fetchAndDecryptCustomAvatar(activeChatData.friendId, url =>
        setCustomAvatars(prev => ({ ...prev, [activeChatData.friendId]: url }))
      );
    }
  }, [activeChatData, customAvatars]);

  async function reloadChatsAndChat(receiverId) {
    await openChat(receiverId);
    const chatsArr = await loadChats();
    setChats(chatsArr);
  }

  // ================= LOAD CHATS (SIDEBAR) =================
  // Тут не потрібно нічого міняти
  const loadChats = useCallback(async () => {
    if (!messagesPublicKey) return [];
    const packetAesKey = genRandomBytes(16);
    const packetIv = genRandomBytes(16);
    const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(messagesPublicKey);
    const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
    const encryptedKey = encryptor.encrypt(packetAesKeyB64);

    const payloadObj = {};
    const payloadStr = JSON.stringify(payloadObj);
    const encryptedPayload = CryptoJS.AES.encrypt(payloadStr, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: CryptoJS.lib.WordArray.create(packetIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const body = {
      encryptedKey,
      iv: packetIvBase64,
      ciphertext: encryptedPayload.toString(),
    };

    const resp = await fetchWithAuth("/api/messages/get-chats", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const respJson = await resp.json();
    if (!respJson?.ciphertext || !respJson?.iv) return [];
    const respIv = CryptoJS.enc.Base64.parse(respJson.iv);
    const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: respIv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const decryptedStr = decrypted.toString(CryptoJS.enc.Utf8);
    try {
      const result = JSON.parse(decryptedStr);
      if (Array.isArray(result.chats)) return result.chats;
      return [];
    } catch {
      return [];
    }
  }, [messagesPublicKey]);


  async function fetchMessageIv(messageId) {
    if (!messagesPublicKey) throw new Error("No public key");
    const packetAesKey = genRandomBytes(16);
    const packetIv = genRandomBytes(16);
    const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(messagesPublicKey);
    const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
    const encryptedKey = encryptor.encrypt(packetAesKeyB64);
  
    const payloadStr = JSON.stringify({ messageId });
    const encryptedPayload = CryptoJS.AES.encrypt(payloadStr, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: CryptoJS.lib.WordArray.create(packetIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    const body = {
      encryptedKey,
      iv: packetIvBase64,
      ciphertext: encryptedPayload.toString(),
    };
  
    const resp = await fetchWithAuth("/api/messages/get-message-iv", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const respJson = await resp.json();
    // Дешифруємо відповідь:
    const respIv = CryptoJS.enc.Base64.parse(respJson.iv);
    const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: respIv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const result = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
    return result.iv; // тут оригінальний IV для цього повідомлення
  }
  

  // ================= OPEN/SELECT CHAT (універсальна логіка) =================

  /**
   * Головна функція для відкриття чату (старий чи новий).
   * Відправляє {friendId} на /api/messages/chat і зберігає:
   * - secret (DH)
   * - всі messages
   * - дані співрозмовника (avatar, name, role)
   */
  async function openChat(friendId) {
    if (!messagesPublicKey) return;

    // Створюємо пакет з AES-ключем і friendId
    const encMsg = createEncryptedMessage({ friendId }, messagesPublicKey);

    const resp = await fetchWithAuth("/api/messages/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        encryptedKey: encMsg.encryptedKey,
        iv: encMsg.iv,
        ciphertext: encMsg.ciphertext
      }),
    });
    const respJson = await resp.json();

    // Дешифруємо відповідь тим самим AES-ключем, який повертає createEncryptedMessage
    // (додаємо _aesKeyBytes до функції createEncryptedMessage)
    const packetAesKey = encMsg._aesKeyBytes;
    const respIv = CryptoJS.enc.Base64.parse(respJson.iv);
    const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: respIv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const chatInfo = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
    // { friendId, friendName, friendAvatarType, friendAvatarUrl, secret, messages, ... }

    setActiveChatData(chatInfo);
    setSelectedChatId(chatInfo.friendId);
    setChatMessages(
      (chatInfo.messages || []).map(m => ({ ...m, id: m.id || m._id }))
    );
  }

  // ================= EFFECT: LOAD PUBLIC KEY =================
  useEffect(() => {
    fetchWithAuth("/api/messages/public-key", { credentials: "include" })
      .then(res => res.text())
      .then(base64 => {
        const pem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
        setMessagesPublicKey(pem);
      })
      .catch(() => setMessagesPublicKey(null));
  }, []);

  // ================= EFFECT: LOAD CHATS WHEN PUBLIC KEY CHANGES =================
  useEffect(() => {
    if (!messagesPublicKey) return;
    loadChats().then(chatsArr => setChats(chatsArr));
  }, [messagesPublicKey, loadChats]);

useEffect(() => {
  if (!chatMessages || !activeChatData) return;
  const sharedSecretBytes = Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0));
  const myId = getUserIdFromToken();

  const unreadIncoming = chatMessages
    .slice()
    .filter(msg => {
      const senderId = decryptField(msg.senderId, sharedSecretBytes, msg.iv);
      if (senderId === myId) return false;
      let isChecked = false;
      try {
        isChecked = JSON.parse(decryptField(msg.isChecked || "", sharedSecretBytes, msg.iv));
      } catch {}
      return !isChecked;
    });

  if (unreadIncoming.length === 0) return;

  const observer = new window.IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const msgId = entry.target.dataset.msgid;
          // Додаємо захист — якщо вже був відмічений локально, не надсилаємо ще раз
          if (!checkedMessages.current.has(msgId)) {
            checkedMessages.current.add(msgId);
            const msg = chatMessages.find(m => m.id === msgId);
            if (msg) {
              let isChecked = false;
              try {
                isChecked = JSON.parse(decryptField(msg.isChecked || "", sharedSecretBytes, msg.iv));
              } catch {}
              if (!isChecked) {
                const encChecked = aesEncryptField(JSON.stringify(true), sharedSecretBytes, msg.iv);
                setMessageChecked(msg.id, encChecked);
              }
            }
          }
        }
      });
    },
    {
      root: document.querySelector(".messages-list"),
      threshold: 0.6
    }
  );

  unreadIncoming.forEach(msg => {
    const el = msgRefs.current[msg.id];
    if (el) {
      el.dataset.msgid = msg.id;
      observer.observe(el);
    }
  });

  return () => {
    observer.disconnect();
  };
}, [chatMessages, activeChatData]);


  async function handleDeleteMessage() {
    if (!msgToDelete || !activeChatData) return;
    if (!msgToDelete.id) {
      alert("Неможливо видалити повідомлення: некоректний id.");
      setShowMsgDeleteModal(false);
      setMsgToDelete(null);
      setDeleteMsgForBoth(false);
      return;
    }
  
    try {
      const token = localStorage.getItem("jwt");
      const body = {
        messageId: msgToDelete.id,
        friendId: activeChatData.friendId,
        deleteForBoth: deleteMsgForBoth,
      };
  
      await fetchWithAuth("/api/messages/delete-message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });
  
      setShowMsgDeleteModal(false);
      setMsgToDelete(null);
      setDeleteMsgForBoth(false);
      // Оновлюємо чат і список чатів!
      setTimeout(async () => {
        // Оновити чат (якщо його ще існує)
        await openChat(activeChatData.friendId);
        // Оновити список чатів (для Sidebar)
        const chatsArr = await loadChats();
        setChats(chatsArr);
  
        // Якщо чат був повністю видалений — скинути активний чат
        if (!chatsArr.find(c => c.id === activeChatData.friendId)) {
          setActiveChatData(null);
          setSelectedChatId(null);
          setChatMessages([]);
        }
      }, 200);
    } catch (err) {
      alert("Failed to delete message: " + (err?.message || ""));
      setShowMsgDeleteModal(false);
      setMsgToDelete(null);
      setDeleteMsgForBoth(false);
    }
  }
  
  
  useEffect(() => {
    console.log("chatMessages:", chatMessages);
  }, [chatMessages]);
  

  // ================= SEND MESSAGE =================
  async function handleSendMessage() {
    if (uploading || (!messageText.trim() && pendingFiles.length === 0) || !activeChatData || !messagesPublicKey) return;

    let attachmentsMeta = [];
    if (pendingFiles.length > 0) {
      attachmentsMeta = await Promise.all(
        pendingFiles.map(async pf => {
          if (pf.meta) return pf.meta; // вже завантажено
          const meta = await uploadAttachment(pf.file);
          return meta;
        })
      );
    }

    console.log("[Attachment] attachmentsMeta масив після upload-attachment:", attachmentsMeta);

    const ivBytes = genRandomBytes(16);
    const senderId = getUserIdFromToken();
    const receiverId = activeChatData.friendId;
    const sharedSecretBase64 = activeChatData.secret;
    const sharedSecret = Uint8Array.from(atob(sharedSecretBase64), c => c.charCodeAt(0));

    function aesEncrypt(text, key, iv) {
      const str = typeof text === "string" ? text : JSON.stringify(text);
      const keyWA = CryptoJS.lib.WordArray.create(key);
      const ivWA = CryptoJS.lib.WordArray.create(iv);
      const encrypted = CryptoJS.AES.encrypt(str, keyWA, {
        iv: ivWA,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      return encrypted.toString();
    }

    const now = new Date().toISOString();
    console.log("[Attachment] attachmentsMeta перед DH-шифруванням:", attachmentsMeta);

    const encryptedAttachments = aesEncrypt(JSON.stringify(attachmentsMeta), sharedSecret, ivBytes);
console.log("[Attachment] encryptedAttachments для поля attachments:", encryptedAttachments);
    const msgObj = {
      senderId: aesEncrypt(senderId, sharedSecret, ivBytes),
      receiverId: aesEncrypt(receiverId, sharedSecret, ivBytes),
      ciphertext: aesEncrypt(messageText, sharedSecret, ivBytes),
      iv: CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(ivBytes)),
      createdAt: aesEncrypt(now, sharedSecret, ivBytes),
      isEdited: aesEncrypt(JSON.stringify(false), sharedSecret, ivBytes),
      lastEditTime: aesEncrypt("", sharedSecret, ivBytes),
      messageType: aesEncrypt("text", sharedSecret, ivBytes),
      deletedFor: aesEncrypt(JSON.stringify([]), sharedSecret, ivBytes),
      attachments: encryptedAttachments,
      replyId: aesEncrypt(JSON.stringify(null), sharedSecret, ivBytes),
      isChecked: aesEncrypt(JSON.stringify(false), sharedSecret, ivBytes),
      senderIdPlain: senderId,
      receiverIdPlain: receiverId,
    };

    

    // Шифруємо пакет з повідомленням (ще один AES+RSA раунд)
    const packetAesKey = genRandomBytes(16);
    const packetIv = genRandomBytes(16);
    const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
    const msgObjStr = JSON.stringify(msgObj);
    const msgObjEnc = CryptoJS.AES.encrypt(msgObjStr, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: CryptoJS.lib.WordArray.create(packetIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(messagesPublicKey);
    const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
    const encryptedKey = encryptor.encrypt(packetAesKeyB64);

    const body = {
      encryptedKey,
      iv: packetIvBase64,
      ciphertext: msgObjEnc.toString(),
    };

    console.log("[Attachment] msgObj перед AES+RSA:", msgObj);

    await fetchWithAuth("/api/messages/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    setMessageText("");
    // Reload messages: відкриваємо чат знову, щоб гарантовано оновити список
    setTimeout(() => reloadChatsAndChat(receiverId), 200);
    setPendingFiles([]);
  }

  async function setMessageChecked(messageId, newIsChecked) {
    if (!messagesPublicKey) return;
    const packetAesKey = genRandomBytes(16);
    const packetIv = genRandomBytes(16);
    const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(messagesPublicKey);
    const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
    const encryptedKey = encryptor.encrypt(packetAesKeyB64);
  
    const payloadStr = JSON.stringify({ messageId, newIsChecked });
    const encryptedPayload = CryptoJS.AES.encrypt(payloadStr, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: CryptoJS.lib.WordArray.create(packetIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    const body = {
      encryptedKey,
      iv: packetIvBase64,
      ciphertext: encryptedPayload.toString(),
    };
  
    await fetchWithAuth("/api/messages/set-checked", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  }
  
  function aesEncryptField(value, keyBytes, ivBase64) {
    const str = typeof value === "string" ? value : JSON.stringify(value);
    const keyWA = CryptoJS.lib.WordArray.create(keyBytes);
    const ivWA = CryptoJS.enc.Base64.parse(ivBase64);
    const encrypted = CryptoJS.AES.encrypt(str, keyWA, { iv: ivWA, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
    return encrypted.toString();
  }
  
  async function uploadAttachment(file) {
    setUploading(true);
    const token = localStorage.getItem("jwt");
    const sessionAesKey = genRandomBytes(16);
    const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
    const sessionIv = genRandomBytes(16);
  
    // 1. Шифруємо файл (як було)
    const arrayBuffer = await file.arrayBuffer();
    const wordArray = CryptoJS.lib.WordArray.create(arrayBuffer);
    const encrypted = CryptoJS.AES.encrypt(wordArray, CryptoJS.lib.WordArray.create(sessionAesKey), {
      iv: CryptoJS.lib.WordArray.create(sessionIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const encryptedBytes = Uint8Array.from(
      atob(encrypted.ciphertext.toString(CryptoJS.enc.Base64)), c => c.charCodeAt(0)
    );
  
    // 2. Генеруємо прев’ю (тільки якщо image/*)
    let encryptedThumbnailBytes = null;
    let thumbnailExt = "";
    if (file.type.startsWith("image/")) {
      const thumbnailBlob = await createImageThumbnail(file, 220, 220); // або 120x120
      thumbnailExt = ".thumb.jpg";
      const thumbBuffer = await thumbnailBlob.arrayBuffer();
      const thumbWordArray = CryptoJS.lib.WordArray.create(thumbBuffer);
      const encryptedThumb = CryptoJS.AES.encrypt(thumbWordArray, CryptoJS.lib.WordArray.create(sessionAesKey), {
        iv: CryptoJS.lib.WordArray.create(sessionIv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      encryptedThumbnailBytes = Uint8Array.from(
        atob(encryptedThumb.ciphertext.toString(CryptoJS.enc.Base64)), c => c.charCodeAt(0)
      );
    }
  
    // 3. Метадані, одразу шифруємо AES
    const metaObj = {
      fileName: file.name,
      fileType: file.type,
      size: String(file.size),
      fileUrl: "", // тимчасово пусто
      thumbnailUrl: "" // тимчасово пусто, сервер заповнить
    };
    const metaJson = JSON.stringify(metaObj);
    const metaEnc = CryptoJS.AES.encrypt(metaJson, CryptoJS.lib.WordArray.create(sessionAesKey), {
      iv: CryptoJS.lib.WordArray.create(sessionIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    // 4. Шифруємо sessionAesKey RSA
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(messagesPublicKey);
    const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);
  
    // 5. Формуємо formData
    const formData = new FormData();
    formData.append("encryptedFile", new Blob([encryptedBytes]), file.name + ".enc");
    if (encryptedThumbnailBytes) {
      formData.append("encryptedThumbnail", new Blob([encryptedThumbnailBytes]), file.name + thumbnailExt);
    }
    formData.append("encryptedKey", encryptedSessionAesKey);
    formData.append("iv", btoa(String.fromCharCode(...sessionIv)));
    formData.append("meta", metaEnc.toString());
  
    const resp = await fetchWithAuth("/api/messages/upload-attachment", {
      method: "POST",
      body: formData,
    });
  
    const { attachment } = await resp.json();
    const metaDec = CryptoJS.AES.decrypt(
      attachment,
      CryptoJS.lib.WordArray.create(sessionAesKey),
      {
        iv: CryptoJS.lib.WordArray.create(sessionIv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    ).toString(CryptoJS.enc.Utf8);
  
    setUploading(false);
    return JSON.parse(metaDec);
  }

async function handleSendReply(replyText, repliedMsg) {
    if (!replyText.trim() || !activeChatData || !messagesPublicKey || !repliedMsg) return;
    let attachmentsMeta = [];
    if (pendingFiles.length > 0) {
      attachmentsMeta = await Promise.all(
        pendingFiles.map(async pf => {
          if (pf.meta) return pf.meta; // вже завантажено
          const meta = await uploadAttachment(pf.file);
          return meta;
        })
      );
    }

    console.log("[Attachment] attachmentsMeta масив після upload-attachment:", attachmentsMeta);
    const ivBytes = genRandomBytes(16);
    const senderId = getUserIdFromToken();
    const receiverId = activeChatData.friendId;
    const sharedSecretBase64 = activeChatData.secret;
    const sharedSecret = Uint8Array.from(atob(sharedSecretBase64), c => c.charCodeAt(0));
  
    function aesEncrypt(text, key, iv) {
      const str = typeof text === "string" ? text : JSON.stringify(text);
      const keyWA = CryptoJS.lib.WordArray.create(key);
      const ivWA = CryptoJS.lib.WordArray.create(iv);
      const encrypted = CryptoJS.AES.encrypt(str, keyWA, {
        iv: ivWA,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      return encrypted.toString();
    }
  
    const now = new Date().toISOString();
  
    const msgObj = {
      senderId: aesEncrypt(senderId, sharedSecret, ivBytes),
      receiverId: aesEncrypt(receiverId, sharedSecret, ivBytes),
      ciphertext: aesEncrypt(replyText, sharedSecret, ivBytes),
      iv: CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(ivBytes)),
      createdAt: aesEncrypt(now, sharedSecret, ivBytes),
      isEdited: aesEncrypt(JSON.stringify(false), sharedSecret, ivBytes),
      lastEditTime: aesEncrypt("", sharedSecret, ivBytes),
      messageType: aesEncrypt("text", sharedSecret, ivBytes),
      deletedFor: aesEncrypt(JSON.stringify([]), sharedSecret, ivBytes),
      attachments: aesEncrypt(JSON.stringify(attachmentsMeta), sharedSecret, ivBytes),
      replyId: aesEncrypt(JSON.stringify(repliedMsg.id), sharedSecret, ivBytes),
      isChecked: aesEncrypt(JSON.stringify(false), sharedSecret, ivBytes),
      senderIdPlain: senderId,
      receiverIdPlain: receiverId,
    };

    // Шифруємо пакет з повідомленням (ще один AES+RSA раунд)
    const packetAesKey = genRandomBytes(16);
    const packetIv = genRandomBytes(16);
    const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
    const msgObjStr = JSON.stringify(msgObj);
    const msgObjEnc = CryptoJS.AES.encrypt(msgObjStr, CryptoJS.lib.WordArray.create(packetAesKey), {
      iv: CryptoJS.lib.WordArray.create(packetIv),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    const encryptor = new JSEncrypt();
  encryptor.setPublicKey(messagesPublicKey);
  const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
  const encryptedKey = encryptor.encrypt(packetAesKeyB64);

  const body = {
    encryptedKey,
    iv: packetIvBase64,
    ciphertext: msgObjEnc.toString(),
  };

  await fetchWithAuth("/api/messages/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

    setMessageText("");
    // Reload messages: відкриваємо чат знову, щоб гарантовано оновити список
    setTimeout(() => reloadChatsAndChat(receiverId), 200);
  }

  // ================= CHAT SELECTION (універсальна логіка) =================
  function handleSelectChat(chat) {
    // Просто відкриваємо чат (старий чи новий) через openChat
    openChat(chat.id);
  }

  function renderMessageAttachmentsInfo(attachments, sharedSecretBytes, ivBase64) {
    let arr = [];
    try {
      const decrypted = CryptoJS.AES.decrypt(attachments, CryptoJS.lib.WordArray.create(sharedSecretBytes), {
        iv: CryptoJS.enc.Base64.parse(ivBase64),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }).toString(CryptoJS.enc.Utf8);

      arr = JSON.parse(decrypted);
      if (!Array.isArray(arr)) arr = [];
    } catch (e) {
      arr = [];
    }
    if (arr.length === 0) return null;

    return (
      <div className="msg-attachments-info" style={{
        display: "flex",
        flexDirection: "column",
        gap: 7,
        margin: "10px 0 3px 0"
      }}>
        {arr.map((meta, i) => (
          <div
            key={i}
            style={{
              background: "#1a2948",
              borderRadius: 12,
              display: "flex",
              alignItems: "center",
              padding: "7px 13px 7px 7px",
              marginBottom: 1,
              boxShadow: "0 2px 9px #11223d18",
              border: "1px solid #22325c",
              minWidth: 0,
              maxWidth: 295
            }}
          >
            <AttachmentPreview meta={meta} />
            <div style={{
              display: "flex",
              flexDirection: "column",
              flex: 1,
              overflow: "hidden",
              minWidth: 0,
            }}>
              <span
                style={{
                  fontWeight: 600,
                  color: "#c7e1ff",
                  fontSize: "1.01em",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  maxWidth: 160,
                  marginBottom: 2
                }}
                title={meta.fileName}
              >
                {meta.fileName}
              </span>
              <span style={{
                color: "#91b8e8",
                fontSize: "0.96em",
                display: "flex",
                alignItems: "center",
                gap: 7
              }}>
                {meta.fileType}
                <span style={{
                  color: "#a5b1c7",
                  fontSize: "0.95em"
                }}>
                  {formatFileSize(meta.size)}
                </span>
                <AttachmentDownload meta={meta} />
              </span>
            </div>
          </div>
        ))}
      </div>
    );
  }

  useEffect(() => {
  if (!chatMessages || !activeChatData) return;
  const sharedSecretBytes = Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0));
  const myId = getUserIdFromToken();
  const unreadIncoming = chatMessages
    .slice()
    .sort((a, b) => {
      const tA = Date.parse(decryptField(a.createdAt, sharedSecretBytes, a.iv));
      const tB = Date.parse(decryptField(b.createdAt, sharedSecretBytes, b.iv));
      return tA - tB;
    })
    .filter(msg => {
      const senderId = decryptField(msg.senderId, sharedSecretBytes, msg.iv);
      if (senderId === myId) return false;
      let isChecked = false;
      try {
        isChecked = JSON.parse(decryptField(msg.isChecked || "", sharedSecretBytes, msg.iv));
      } catch {}
      return !isChecked;
    });

  if (unreadIncoming.length > 0) {
    const firstUnread = unreadIncoming[0];
    setFirstUnreadId(firstUnread.id);
    setHighlightedMsgId(firstUnread.id);
    setShowNewMessages(true);
    setShowNewMessagesLabel(true);
    scrollToMessage(firstUnread.id, false);
    lastHighlightedMsgId.current = firstUnread.id;
  } else {
    setFirstUnreadId(null);
    setHighlightedMsgId(null);
    setShowNewMessages(false);
    setShowNewMessagesLabel(false);
    lastHighlightedMsgId.current = null;
  }
}, [selectedChatId, activeChatData, chatMessages]);

  function scrollToMessage(msgId, smooth = true) {
    const el = msgRefs.current[msgId];
    if (el) {
      el.scrollIntoView({ behavior: smooth ? "smooth" : "auto", block: "start" });
      // Хайлайт анімацію робимо ТІЛЬКИ якщо це id, який зберігається у highlightedMsgId
      if (highlightedMsgId === msgId) {
        el.classList.add("msg-highlighted");
        setTimeout(() => el.classList.remove("msg-highlighted"), 1800);
      }
    }
  }
  

  // Для початку нового чату через NewChatModal (отримуємо дані від модалки)
  function handleStartChat(userAndSecret) {
    if (!userAndSecret.friendId && !userAndSecret.id) return;
    // Просто відкриваємо чат за id — сервер все зробить правильно
    openChat(userAndSecret.friendId || userAndSecret.id);
    setShowNewChatModal(false);
  }

  function handleOpenModal() {
    setShowNewChatModal(true);
  }
  function handleCloseModal() {
    setShowNewChatModal(false);
  }

  // ================= CHAT BODY RENDER =================
  function renderChatBody() {
    if (loadingMessages) {
      return <div className="loading-text">Loading messages...</div>;
    }
    if (!chatMessages || chatMessages.length === 0) {
      return <div className="no-messages">No messages yet in the chat</div>;
    }
    const sharedSecretBytes = Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0));
    const friendName = activeChatData.friendName || activeChatData.name || "User";


    return (
      <div className="messages-list" onClick={() => setShowNewMessagesLabel(false)}
      onScroll={handleMessagesScroll}>
        {chatMessages
          .slice()
          .sort((a, b) => {
            const tA = Date.parse(decryptField(a.createdAt, sharedSecretBytes, a.iv));
            const tB = Date.parse(decryptField(b.createdAt, sharedSecretBytes, b.iv));
            return tA - tB; // Старіші спочатку
          })
          .map((msg, idx) => {
            const senderId = decryptField(msg.senderId, sharedSecretBytes, msg.iv);
            const messageText = decryptField(msg.ciphertext, sharedSecretBytes, msg.iv);
            const createdAt = decryptField(msg.createdAt, sharedSecretBytes, msg.iv);
            const own = senderId === getUserIdFromToken();
          
            // Додаємо розшифрування поля isEdited:
            let isEdited = false;
            try {
              isEdited = JSON.parse(decryptField(msg.isEdited, sharedSecretBytes, msg.iv));
            } catch { isEdited = false; }
          
            // Дістаємо replyId (може бути null):
            let replyId = null;
            try {
              const decryptedReply = decryptField(msg.replyId, sharedSecretBytes, msg.iv);
              replyId = JSON.parse(decryptedReply);
            } catch { replyId = null; }
          
            // Шукаємо оригінальне повідомлення, якщо replyId валідний:
            let replyMsgObj = null;
            if (replyId) {
              replyMsgObj = chatMessages.find(m => (m.id || m._id) === replyId);
            }
          
            // Якщо є оригінал, беремо текст та автора:
            let replyPreview = null;
            if (replyMsgObj) {
              const replyText = decryptField(replyMsgObj.ciphertext, sharedSecretBytes, replyMsgObj.iv);
              const replySender = decryptField(replyMsgObj.senderId, sharedSecretBytes, replyMsgObj.iv);
              replyPreview = (
                <div className="reply-preview" style={{
                  background: own ? "#3b76b2" : "#23344a",
                  color: "#d3e8ff",
                  borderLeft: "3px solid #47bae6",
                  padding: "6px 13px 4px 13px",
                  marginBottom: 7,
                  borderRadius: 9,
                  fontSize: "0.98em",
                  opacity: 0.98
                }}>
                  <span style={{ color: "#7ec0ee", fontWeight: 500, fontSize: "0.99em" }}>
                    {replySender === getUserIdFromToken() ? "You" : friendName}
                  </span>
                  <span style={{ marginLeft: 7 }}>{replyText}</span>
                </div>
              );
            }
          
            const isFirstUnread = highlightedMsgId === msg.id;

      return (
        <React.Fragment key={msg.id}>
          {(showNewMessages && msg.id === firstUnreadId) && (
                <div className="new-messages-label" onClick={() => setShowNewMessages(false)}>
                  New Messages
                </div>
              )}
              <div
                ref={el => msgRefs.current[msg.id] = el}
                data-msgid={msg.id}
                className={
                  `msg-bubble${own ? " msg-outgoing" : " msg-incoming"}${msg.id === highlightedMsgId ? " msg-highlighted" : ""}`
                }
                onContextMenu={e => {
                  e.preventDefault();
                  setMsgContextMenu({ visible: true, x: e.clientX, y: e.clientY, msgId: msg.id });
                }}
              >
                {!own && (
                  <div className="msg-sender">{friendName}</div>
                )}
                {/* --- Відповідь, якщо є --- */}
                {replyPreview}
                <div className="msg-text">{messageText}</div>
                {msg.attachments && renderMessageAttachmentsInfo(msg.attachments, sharedSecretBytes, msg.iv)}
                <div className="msg-meta">
                  <span className="msg-time">
                    {createdAt ? new Date(createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                  </span>
                  {isEdited && <span className="edited-label">edited</span>}
                  {own && (() => {
                    // Додаємо іконку "переглянуто"
                    let isChecked = false;
                    try {
                      isChecked = JSON.parse(decryptField(msg.isChecked || "", sharedSecretBytes, msg.iv));
                    } catch {}
                    // ! Шлях прописуй актуальний для public/ або src/
                    const iconUrl = isChecked
                      ? "/icons/messageSeen.png"
                      : "/icons/notSeenMessage.png";
                    return (
                      <img
                        src={iconUrl}
                        alt={isChecked ? "Seen" : "Not seen"}
                        style={{
                          width: 22,
                          height: 22,
                          marginLeft: 7,
                          verticalAlign: "middle",
                          filter: isChecked ? "none" : "grayscale(70%) brightness(0.6)",
                          opacity: isChecked ? 1 : 0.75,
                          transition: "opacity 0.22s"
                        }}
                        className="msg-seen-indicator"
                      />
                    );
                  })()}
                </div>
              </div>
              </React.Fragment>
            );
          })}
           <div ref={messagesEndRef} />
      </div>
    );
  }
  

  // ================= RENDER =================
  return (
    <div className="messages-root">
      <Split
        className="messages-split"
        sizes={splitSizes}
        minSize={[200, 320]}
        maxSize={[480, Infinity]}
        gutterSize={8}
        direction="horizontal"
        cursor="col-resize"
        snapOffset={0}
        onDrag={handleSplitDrag}  // замість setSplitSizes напряму
      >
        <div className="messages-sidebar">
          <div className="chat-search-wrapper">
            <input
              type="text"
              className="chat-search-input"
              placeholder="Find Chat"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="chats-list">
            {filteredChats.length === 0 ? (
              <div className="no-chats">No chats yet</div>
            ) : (
              filteredChats.map(chat => (
                <div
                  className={`chat-preview${chat.id === selectedChatId ? " selected" : ""}`}
                  key={chat.id}
                  onClick={() => handleSelectChat(chat)}
                  onContextMenu={e => {
                    e.preventDefault();
                    setContextMenu({ visible: true, x: e.clientX, y: e.clientY, chatId: chat.id });
                  }}
                >
                  <img
                    src={
                      chat.avatarType === "custom"
                        ? (customAvatars[chat.id] || "/avatars/avatar1.png")
                        : (chat.avatarUrl || "/avatars/avatar1.png")
                    }
                    alt="avatar"
                    className="chat-preview-avatar"
                    style={{ width: 34, height: 34, borderRadius: "50%", marginRight: 10, objectFit: "cover", background: "#23344a" }}
                  />
                  <span style={{ fontWeight: 600 }}>{chat.name}</span>
                  {chat.role && (
                    <span style={{ fontSize: "0.98em", color: "#6bc3fc", marginLeft: 8 }}>{chat.role}</span>
                  )}
                  {Number(chat.unreadCount) > 0 && (
                    <span
                      className="unread-badge"
                      style={{
                        background: "#ff3567",
                        color: "#fff",
                        borderRadius: "999px",
                        fontSize: "0.90em",
                        fontWeight: 700,
                        padding: "2px 8px",
                        marginLeft: 10,
                        marginRight: 0,
                        minWidth: 24,
                        display: "inline-block",
                        textAlign: "center"
                      }}
                      title="Unread messages"
                    >
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
          <div className="new-chat-btn" onClick={handleOpenModal}>
            + New Chat
          </div>
        </div>
        <div className="messages-chat">
          {selectedChatId && activeChatData ? (
            <>
              <div className="chat-header">
              <img
                src={
                  activeChatData.friendAvatarType === "custom"
                    ? (customAvatars[activeChatData.friendId] || "/avatars/avatar1.png")
                    : (activeChatData.friendAvatarUrl || activeChatData.avatarUrl || "/avatars/avatar1.png")
                }
                className="chat-avatar"
                alt="avatar"
              />
                <span className="chat-title">{activeChatData.friendName || activeChatData.name}</span>
              </div>
              <div className="chat-body">{renderChatBody()}</div>
              <div className="chat-input-wrapper">
                <button
                  className="attach-btn"
                  onClick={handleAttachClick}
                  title="Attach file"
                  type="button"
                  style={{ marginRight: 10, background: "none", border: "none", cursor: "pointer" }}
                  disabled={uploading}
                >
                  <FaPaperclip size={22} color="#7ec0ee" />
                </button>
                <input
                  type="file"
                  multiple
                  style={{ display: "none" }}
                  ref={fileInputRef}
                  onChange={e => handleFiles(e.target.files)}
                  accept="*"
                  disabled={uploading}
                />
                <input
                  className="chat-input"
                  type="text"
                  placeholder="Write a message..."
                  value={messageText}
                  onChange={e => setMessageText(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !uploading) handleSendMessage(); }}
                  disabled={uploading}
                  style={uploading ? { opacity: 0.7, background: "#263a50" } : undefined}
                />
                {uploading && (
                  <div style={{
                    display: "inline-block", marginRight: 10, color: "#a4c8e8", fontSize: "1em", alignSelf: "center"
                  }}>
                    <span className="uploading-spinner" style={{
                      display: "inline-block",
                      width: 18, height: 18, border: "3px solid #7ec0ee",
                      borderTop: "3px solid #2a4563", borderRadius: "50%",
                      animation: "spin 1.1s linear infinite", marginRight: 7
                    }} />
                    Uploading...
                  </div>
                )}
                <button
                  className="chat-send-btn"
                  onClick={handleSendMessage}
                  disabled={uploading}
                  style={uploading ? {
                    background: "#365474", color: "#b0bcd3", cursor: "not-allowed", opacity: 0.75
                  } : undefined}
                >
                  Send
                </button>
              </div>
            </>
          ) : (
            <div style={{ margin: "auto", textAlign: "center", color: "#a0c7ff", fontSize: "1.23rem" }}>
              No chat selected
            </div>
          )}
          {pendingFiles.length > 0 && (
            <div className="pending-attachments">
              {pendingFiles.map((pf, i) => (
                <div key={i} style={{ display: "inline-block", marginRight: 10, position: "relative" }}>
                  {pf.file.type.startsWith("image/")
                    ? <img src={pf.previewUrl} alt={pf.file.name} style={{ width: 48, height: 48, borderRadius: 7, objectFit: "cover" }} />
                    : <span style={{ color: "#eee", fontSize: "0.97em" }}>{pf.file.name}</span>
                  }
                  <button style={{
                    position: "absolute", top: 1, right: 2, background: "#222", border: "none",
                    color: "#fff", borderRadius: "50%", width: 18, height: 18, cursor: "pointer"
                  }} onClick={() => removePendingFile(i)}>
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
        {contextMenu.visible && (
          <div
            id="chat-context-menu"
            className="chat-context-menu"
            style={{
              position: "fixed",
              top: contextMenu.y,
              left: contextMenu.x,
              zIndex: 50,
              background: "#202c47",
              border: "1px solid #333c5c",
              borderRadius: 8,
              boxShadow: "0 2px 12px #002d6666",
              padding: "8px 0",
              minWidth: 162,
            }}
            // Видаляємо onMouseLeave!
          >
            <div
              className="menu-item"
              style={{ padding: "10px 18px", color: "#d6e7fd", cursor: "pointer", fontSize: "1.08rem" }}
              onClick={() => {
                setChatToDelete(filteredChats.find(c => c.id === contextMenu.chatId));
                setShowDeleteModal(true);
                setContextMenu({ ...contextMenu, visible: false });
              }}
            >
              🗑️ Delete the Chat
            </div>
          </div>
        )}
        <ChatDeleteModal
          open={showDeleteModal}
          chat={chatToDelete}
          customAvatars={customAvatars}
          deleteForBoth={deleteForBoth}
          setDeleteForBoth={setDeleteForBoth}
          onDelete={handleDeleteChat}
          onCancel={() => setShowDeleteModal(false)}
        />
        {msgContextMenu.visible && ReactDOM.createPortal(
          <div
            id="msg-context-menu"
            className="chat-context-menu"
            style={{
              position: "fixed",
              top: msgContextMenu.y,
              left: msgContextMenu.x,
              zIndex: 51,
              background: "#202c47",
              border: "1px solid #333c5c",
              borderRadius: 8,
              boxShadow: "0 2px 12px #002d6666",
              padding: "8px 0",
              minWidth: 172,
            }}
          >
            <div
              className="menu-item"
              style={{ padding: "9px 18px", color: "#d6e7fd", cursor: "pointer", fontSize: "1.06rem" }}
              onClick={() => {
                setMsgContextMenu({ ...msgContextMenu, visible: false });
                setReplyMsg(chatMessages.find(m => m.id === msgContextMenu.msgId));
                setShowReplyModal(true);
              }}
            >
              💬 Reply
            </div>
            {(() => {
            const msg = chatMessages.find(m => m.id === msgContextMenu.msgId);
            if (!msg) return null;
            const sharedSecretBytes = Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0));
            const senderId = decryptField(msg.senderId, sharedSecretBytes, msg.iv);
            if (senderId !== getUserIdFromToken()) return null;
            return (
            <div
              className="menu-item"
              style={{ padding: "9px 18px", color: "#7ec0ee", cursor: "pointer", fontSize: "1.06rem" }}
              onClick={() => {
                setMsgContextMenu({ ...msgContextMenu, visible: false });
                setEditMsg(msg);
                setShowEditModal(true);
              }}
            >
              ✏️ Edit
            </div>
            );
          })()}
            <div
              className="menu-item"
              style={{ padding: "9px 18px", color: "#e16171", cursor: "pointer", fontSize: "1.06rem" }}
              onClick={() => {
                setMsgToDelete(chatMessages.find(m => m.id === msgContextMenu.msgId));
                setShowMsgDeleteModal(true);
                setMsgContextMenu({ ...msgContextMenu, visible: false });
              }}
            >
              🗑️ Delete
            </div>
          </div>,
          document.body
        )}
        <MessageDeleteModal
          open={showMsgDeleteModal}
          message={msgToDelete}
          deleteForBoth={deleteMsgForBoth}
          setDeleteForBoth={setDeleteMsgForBoth}
          onDelete={async () => {
            console.log("Trying to delete message", msgToDelete);
            await handleDeleteMessage();
          }}
          onCancel={() => {
            setShowMsgDeleteModal(false);
            setMsgToDelete(null);
            setDeleteMsgForBoth(false);
          }}
        />
        <EditMessageModal
          open={showEditModal}
          message={editMsg}
          onEdit={async (newText) => {
            // 1. Отримуємо оригінальний IV:
            const origIvBase64 = await fetchMessageIv(editMsg.id);
            const origIvBytes = Uint8Array.from(atob(origIvBase64), c => c.charCodeAt(0));
            const sharedSecret = activeChatData ? Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0)) : null;

            // 2. Шифруємо новий текст
            const aesEncrypt = (text, key, iv) => {
              const str = typeof text === "string" ? text : JSON.stringify(text);
              const keyWA = CryptoJS.lib.WordArray.create(key);
              const ivWA = CryptoJS.lib.WordArray.create(iv);
              const encrypted = CryptoJS.AES.encrypt(str, keyWA, {
                iv: ivWA,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7,
              });
              return encrypted.toString();
            };

            const nowIso = new Date().toISOString();

            const newCiphertext = aesEncrypt(newText, sharedSecret, origIvBytes);
            const newIsEdited = aesEncrypt(JSON.stringify(true), sharedSecret, origIvBytes);
            const newLastEditTime = aesEncrypt(nowIso, sharedSecret, origIvBytes);

            // 3. Пакуємо все в encrypted запит (AES+RSA, як завжди)
            const packetAesKey = genRandomBytes(16);
            const packetIv = genRandomBytes(16);
            const packetIvBase64 = CryptoJS.enc.Base64.stringify(CryptoJS.lib.WordArray.create(packetIv));
            const encryptor = new JSEncrypt();
            encryptor.setPublicKey(messagesPublicKey);
            const packetAesKeyB64 = btoa(String.fromCharCode(...packetAesKey));
            const encryptedKey = encryptor.encrypt(packetAesKeyB64);

            const payloadObj = {
              messageId: editMsg.id,
              newCiphertext,
              newIv: origIvBase64,
              newIsEdited,
              newLastEditTime,
            };
            const payloadStr = JSON.stringify(payloadObj);
            const encryptedPayload = CryptoJS.AES.encrypt(payloadStr, CryptoJS.lib.WordArray.create(packetAesKey), {
              iv: CryptoJS.lib.WordArray.create(packetIv),
              mode: CryptoJS.mode.CBC,
              padding: CryptoJS.pad.Pkcs7,
            });

            const body = {
              encryptedKey,
              iv: packetIvBase64,
              ciphertext: encryptedPayload.toString(),
            };

            // 4. Відправляємо на сервер:
            await fetchWithAuth("/api/messages/edit-message", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
            });

            // 5. Оновлюємо чат
            setShowEditModal(false);
            setEditMsg(null);
            setTimeout(() => openChat(activeChatData.friendId), 150); // оновити чат після редагування
          }}
          onCancel={() => {
            setShowEditModal(false);
            setEditMsg(null);
          }}
          decryptField={decryptField}
          sharedSecretBytes={
            activeChatData ? Uint8Array.from(atob(activeChatData.secret), c => c.charCodeAt(0)) : null
          }
        />
        <ReplyMessageModal
          open={showReplyModal}
          onReply={async (text) => {
            await handleSendReply(text, replyMsg);
            setShowReplyModal(false);
            setReplyMsg(null);
          }}
          onCancel={() => {
            setShowReplyModal(false);
            setReplyMsg(null);
          }}
        />
      </Split>
      {showNewChatModal && (
        <NewChatModal open={showNewChatModal} onClose={handleCloseModal} onStartChat={handleStartChat} />
      )}
    </div>
  );
}
