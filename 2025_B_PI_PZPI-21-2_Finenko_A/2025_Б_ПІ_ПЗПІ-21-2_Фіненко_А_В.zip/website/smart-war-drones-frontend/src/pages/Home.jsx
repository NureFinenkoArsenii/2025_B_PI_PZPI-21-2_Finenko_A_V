import { useState, useEffect } from "react";
import PageWrapper from "../components/PageWrapper";
import { motion, AnimatePresence } from "framer-motion";
import {
  generateRandomBytes,
  encryptJsonWithAES,
  encryptAESKeyWithRSA,
} from "../utils/crypto.auth";
import { getValidAccessToken, getUserIdFromToken } from "../utils/tokenManager";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const titles = [
    "Start operating your drone system securely",
    "Prepare for mission coordination",
    "Secure access to tactical operations",
  ];

  const [randomTitle] = useState(() => {
    const last = localStorage.getItem("lastTitle");
    const available = titles.filter((t) => t !== last);
    const newTitle =
      available[Math.floor(Math.random() * available.length)];
    localStorage.setItem("lastTitle", newTitle);
    return newTitle;
  });

  const navigate = useNavigate();

  // --- Додаємо нові стейти
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuth, setIsAuth] = useState(false);
  const [userName, setUserName] = useState("");
  const [profileLoading, setProfileLoading] = useState(false);

  // --- Початкові форми/стейти
  const [mode, setMode] = useState("login");
  const [selectedRole, setSelectedRole] = useState(null);
  const [formData, setFormData] = useState({
    login: "",
    password: "",
    repeatPassword: "",
  });
  const [responseMessage, setResponseMessage] = useState(null);

  // --- Перевірка авторизації і підвантаження імені
  useEffect(() => {
    async function checkAuthAndProfile() {
      const token = await getValidAccessToken();
      if (!token) {
        setIsAuth(false);
        setAuthChecked(true);
        return;
      }
      setIsAuth(true);

      // Отримаємо ім'я захищеним способом (швидкий профіль-запит, як у ProfileView)
      setProfileLoading(true);
      try {
        const userId = getUserIdFromToken();
        if (!userId) throw new Error("No user id in token");
        // Крок 1: отримуємо публічний ключ
        const pubKeyRes = await fetch("/api/profile/public-key", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!pubKeyRes.ok) throw new Error("Failed to get public key");
        const publicKeyBase64 = await pubKeyRes.text();
        const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${publicKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

        // Крок 2: генеруємо AES ключ і шифруємо його RSA
        const aesKey = generateRandomBytes(16);
        const aesKeyBase64 = btoa(String.fromCharCode(...aesKey));
        const encryptor = new JSEncrypt();
        encryptor.setPublicKey(publicKeyPem);
        const encryptedAesKey = encryptor.encrypt(aesKeyBase64);
        if (!encryptedAesKey) throw new Error("RSA encryption of AES key failed");

        // Крок 3: Отримуємо профіль (тільки name!)
        const resProfile = await fetch(`/api/profile/${userId}`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "X-Client-AES-Key": encryptedAesKey,
          },
        });
        if (!resProfile.ok) throw new Error("Profile error");

        let encryptedProfile;
        try {
          const raw = await resProfile.text();
          encryptedProfile = JSON.parse(raw);
        } catch {
          encryptedProfile = await resProfile.json();
        }
        const iv = CryptoJS.enc.Base64.parse(encryptedProfile.Iv);
        const ciphertext = encryptedProfile.Ciphertext;
        const key = CryptoJS.lib.WordArray.create(aesKey);
        const decrypted = CryptoJS.AES.decrypt(ciphertext, key, {
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
        if (!jsonStr) throw new Error("AES decryption failed");
        const parsed = JSON.parse(jsonStr);
        setUserName(parsed.name || "user");
      } catch (err) {
        setUserName("user");
      } finally {
        setProfileLoading(false);
        setAuthChecked(true);
      }
    }
    checkAuthAndProfile();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    setResponseMessage(null);
  }, [mode]);

  const handleRoleSelect = (role) => setSelectedRole(role);
  const handleBackToRoles = () => {
    setMode("choose-role");
    setFormData({ login: "", password: "", repeatPassword: "" });
  };

  const handleInputChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleRegister = async () => {
    if (!formData.login.trim() || !formData.password.trim() || !selectedRole) {
      setResponseMessage("Please fill in all fields and select a role.");
      return;
    }
    if (formData.password !== formData.repeatPassword) {
      setResponseMessage("Passwords do not match.");
      return;
    }
    try {
      const res = await fetch("/api/auth/public-key/register", {
        method: "GET",
        credentials: "include",
      });
      const base64 = await res.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const payload = {
        login: formData.login.trim(),
        password: formData.password,
        role: selectedRole,
      };
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA(aesKey, publicKeyPem);
      const message = { encryptedKey, iv: ivBase64, ciphertext };
      const result = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(message),
      });
      if (result.ok) {
        setResponseMessage("✅ Registration successful!");
        setTimeout(() => {
          setMode("login");
          setFormData({ login: "", password: "", repeatPassword: "" });
          setSelectedRole(null);
          setResponseMessage(null);
        }, 3000);
      } else {
        const text = await result.text();
        setResponseMessage(`❌ ${text}`);
      }
    } catch (err) {
      console.error(err);
      setResponseMessage("❌ Encryption or server error.");
    }
  };

  const handleLogin = async () => {
    if (!formData.login.trim() || !formData.password.trim()) {
      setResponseMessage("Please enter both login and password.");
      return;
    }
    try {
      const res = await fetch("/api/auth/public-key/login", {
        method: "GET",
        credentials: "include",
      });
      const base64 = await res.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const payload = {
        login: formData.login.trim(),
        password: formData.password,
      };
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA(aesKey, publicKeyPem);
      const message = { encryptedKey, iv: ivBase64, ciphertext };
      const result = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(message),
      });
      if (result.ok) {
        const token = await result.text();
        localStorage.setItem("jwt", token);
        navigate("/workplace");
      } else {
        const text = await result.text();
        setResponseMessage(`❌ ${text}`);
      }
    } catch (err) {
      console.error(err);
      setResponseMessage("❌ Login encryption or server error.");
    }
  };

  // --- AUTHORIZED USER LAYOUT
  if (!authChecked) return null; // Loader/пусто до перевірки
  if (isAuth) {
    return (
      <PageWrapper>
        <div className="home-container auth-welcome">
          <motion.h1
            key="welcome-back"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="heading"
          >
            {profileLoading
              ? "Loading profile…"
              : <>Welcome back, {userName}!</>
            }
          </motion.h1>

          <motion.div
            key="continue"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="form-block"
            style={{ minHeight: 240 }}
          >
            <button
              className="button"
              style={{ fontSize: "2.2rem", padding: "1.5rem 3rem", marginTop: "2.5rem" }}
              onClick={() => navigate("/workplace")}
              disabled={profileLoading}
            >
              Continue
            </button>
          </motion.div>
          <div className="register-text" style={{ marginTop: "2.5rem" }}>
            Not needed account?{" "}
            <span
              className="link-register"
              onClick={async () => {
                try {
                  await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
                } catch {}
                localStorage.clear();
                setIsAuth(false);
                setMode("login");
              }}
            >
              Log out then
            </span>
          </div>
        </div>
      </PageWrapper>
    );
  }

  // --- НЕ авторизований (старий флоу, як у тебе)
  return (
    <PageWrapper>
      <div className="home-container">
        <AnimatePresence mode="wait">
          <motion.h1
            key={
              mode === "choose-role"
                ? "choose-title"
                : mode === "register"
                ? "register-title"
                : "login-title"
            }
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="heading"
          >
            {mode === "choose-role"
              ? "Choose your role"
              : mode === "register"
              ? "You are almost in"
              : randomTitle}
          </motion.h1>
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {mode === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="form-block"
            >
              <input
                type="text"
                name="login"
                placeholder="Login"
                className="input"
                value={formData.login}
                onChange={handleInputChange}
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="input"
                value={formData.password}
                onChange={handleInputChange}
              />
              <div className="buttons-group">
                <button className="button" onClick={handleLogin}>
                  Log In
                </button>
              </div>
              <div className="form-response-wrapper">
                {responseMessage ? (
                  <div
                    className={`form-response ${responseMessage.startsWith("✅") ? "success" : "error"}`}
                  >
                    {responseMessage}
                  </div>
                ) : (
                  <div className="register-text">
                    Don’t have an account?{" "}
                    <span
                      className="link-register"
                      onClick={() => {
                        setFormData({ login: "", password: "", repeatPassword: "" });
                        setSelectedRole(null);
                        setResponseMessage(null);
                        setMode("choose-role");
                      }}
                    >
                      Register now!
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {mode === "choose-role" && (
            <motion.div
              key="choose"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="roles-wrapper">
                <RoleCard
                  title="Drone Operator"
                  image="/assets/operator.png"
                  selected={selectedRole === "operator"}
                  onClick={() => handleRoleSelect("operator")}
                />
                <RoleCard
                  title="Officer"
                  image="/assets/officer.png"
                  selected={selectedRole === "officer"}
                  onClick={() => handleRoleSelect("officer")}
                />
              </div>
              <div className="buttons-group">
                <button
                  disabled={!selectedRole}
                  onClick={() => setMode("register")}
                  className="button"
                  style={{
                    opacity: selectedRole ? 1 : 0.5,
                    cursor: selectedRole ? "pointer" : "not-allowed",
                  }}
                >
                  Confirm Role
                </button>
              </div>
              <div className="register-text">
                <span className="link-cancel" onClick={() => setMode("login")}>
                  Cancel
                </span>
              </div>
            </motion.div>
          )}

          {mode === "register" && (
            <motion.div
              key="register"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="form-block"
            >
              <input
                type="text"
                name="login"
                placeholder="Login"
                className="input"
                value={formData.login}
                onChange={handleInputChange}
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="input"
                value={formData.password}
                onChange={handleInputChange}
              />
              <input
                type="password"
                name="repeatPassword"
                placeholder="Repeat Password"
                className="input"
                value={formData.repeatPassword}
                onChange={handleInputChange}
              />
              <div className="buttons-group">
                <button className="button" onClick={handleRegister}>
                  Register
                </button>
              </div>
              <div className="form-response-wrapper">
                {responseMessage ? (
                  <div className={`form-response ${responseMessage.startsWith("✅") ? "success" : "error"}`}>
                    {responseMessage}
                  </div>
                ) : (
                  <span className="link-cancel" onClick={handleBackToRoles}>
                    Back to Role Selection
                  </span>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageWrapper>
  );
}

// --- Рольова картка (без змін)
function RoleCard({ title, image, selected, onClick }) {
  return (
    <motion.div
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      className={`role-card ${selected ? "selected" : ""}`}
    >
      <motion.img src={image} alt={title} />
      <motion.div className="overlay">{title}</motion.div>
    </motion.div>
  );
}
