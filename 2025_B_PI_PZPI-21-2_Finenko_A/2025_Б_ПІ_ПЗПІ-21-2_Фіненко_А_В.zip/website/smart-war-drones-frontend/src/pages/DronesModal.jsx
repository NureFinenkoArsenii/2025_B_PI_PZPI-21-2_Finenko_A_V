import ReactDOM from "react-dom";
import DronesView from "../pages/DronesView";
import "../styles/pages/_dronesModal.scss"; // на всяк випадок

export default function DronesModal({ open, onClose }) {
  if (!open) return null;
  return ReactDOM.createPortal(
    <div className="drones-overlay">
      <DronesView onBack={onClose} />
    </div>,
    document.getElementById("modal-root")
  );
}
