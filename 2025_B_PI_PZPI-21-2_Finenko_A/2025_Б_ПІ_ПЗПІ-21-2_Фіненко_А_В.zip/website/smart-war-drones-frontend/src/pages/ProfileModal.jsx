import ReactDOM from "react-dom";
import ProfileView from "../pages/ProfileView";

export default function ProfileModal({ open, onClose, refreshAvatar }) {
  if (!open) return null;
  return ReactDOM.createPortal(
    (
      <div className="profile-overlay">
        <div className="profile-modal">
          <ProfileView onBack={onClose} onAvatarChanged={refreshAvatar} />
        </div>
      </div>
    ),
    document.getElementById("modal-root")
  );
}
