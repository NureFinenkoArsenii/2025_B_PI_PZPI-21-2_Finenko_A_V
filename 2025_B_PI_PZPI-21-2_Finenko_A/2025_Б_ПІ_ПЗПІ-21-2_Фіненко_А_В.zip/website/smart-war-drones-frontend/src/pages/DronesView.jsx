import { useRef, useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import "../styles/pages/_dronesModal.scss";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
  decryptWithAES_fromResponse,
} from "../utils/passwordCrypto";
import { fetchWithAuth } from "../utils/tokenManager";
import attackImg from "../map/media/attackdrone.png";
import transportImg from "../map/media/transportdrone.png";
import scoutImg from "../map/media/scout-drone.png";
import anotherImg from "../map/media/anothertype.png";
import DeleteDroneModal from "../components/DeleteDroneModal";


export default function DronesView({ onBack }) {
  const modalRef = useRef(null);
  const [mode, setMode] = useState("list"); // "list" | "add"
  const [rsaPublicKey, setRsaPublicKey] = useState("");
  const [droneList, setDroneList] = useState([]);
  const [drone, setDrone] = useState({
    name: "",
    type: "",
    band: "",
    safety: "",
  });

  const [addResponse, setAddResponse] = useState(null);
  const [expandedDroneId, setExpandedDroneId] = useState(null);
  const [droneStats, setDroneStats] = useState({});
  const [loadingStatsId, setLoadingStatsId] = useState(null);
  

  // EDIT MODE:
  const [isEditMode, setIsEditMode] = useState(false);
  const [editDrone, setEditDrone] = useState(null);
  const [editResponse, setEditResponse] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState(null);


  const [search, setSearch] = useState("");
  const filteredDrones = search.trim()
    ? droneList.filter((d) =>
        (d.DroneName || "").toLowerCase().includes(search.trim().toLowerCase())
      )
    : droneList;

  const allFilled =
    drone.name && drone.type && drone.band && isValidSafetyCode(drone.safety);

  function isValidSafetyCode(code) {
    return /^[0-9]{13}$/.test(code);
  }

  // For Edit Mode — перевірка на пусті поля та чи є зміни
  const isEditValid =
    editDrone &&
    editDrone.name &&
    editDrone.type &&
    editDrone.band &&
    (editDrone.name !== (droneList.find(d => d.Id === expandedDroneId)?.DroneName ?? "") ||
      editDrone.type !== (droneList.find(d => d.Id === expandedDroneId)?.DroneType ?? "") ||
      editDrone.band !== (droneList.find(d => d.Id === expandedDroneId)?.FrequencyBand ?? ""));

  useEffect(() => {
    if (mode === "add" && !rsaPublicKey) {
      fetchWithAuth("/api/map/drone/public-key")
        .then((res) => res.text())
        .then(setRsaPublicKey)
        .catch(() => setRsaPublicKey(""));
    }
  }, [mode, rsaPublicKey]);

  useEffect(() => {
    if (mode === "list") {
      fetchDrones().then(setDroneList);
    }
  }, [mode]);

  function getDroneAvatarUrl(type) {
    switch ((type || "").trim().toLowerCase()) {
      case "attack":
        return attackImg;
      case "transport":
        return transportImg;
      case "scout":
        return scoutImg;
      default:
        return anotherImg;
    }
  }

  function getTypeClass(type) {
    switch ((type || "").trim().toLowerCase()) {
      case "attack":
        return "attack";
      case "transport":
        return "transport";
      case "scout":
        return "scout";
      default:
        return "another";
    }
  }

  function handleChangeDroneClick(drone) {
    setIsEditMode(true);
    setEditDrone({
      name: drone.DroneName,
      type: drone.DroneType,
      band: drone.FrequencyBand,
    });
  }

  function handleCancelEdit() {
    setIsEditMode(false);
    setEditDrone(null);
  }

  // --- Закриття по кліку поза модалкою та Esc ---
  const handleClickOutside = useCallback(
    (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onBack();
      }
    },
    [onBack]
  );

  const handleEsc = useCallback(
    (e) => {
      if (e.key === "Escape") onBack();
    },
    [onBack]
  );

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [handleClickOutside, handleEsc]);

  const handleInput = (e) =>
    setDrone((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  async function fetchDrones() {
    const res = await fetchWithAuth("/api/map/drone/public-key");
    const base64 = await res.text();
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
      .match(/.{1,64}/g)
      .join("\n")}\n-----END PUBLIC KEY-----`;

    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);

    const { ciphertext, iv } = encryptJsonWithAES_forPassword({}, aesKey, aesIv);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

    const response = await fetchWithAuth("/api/map/drone/getAll", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({
        EncryptedKey: encryptedKey,
        Iv: iv,
        Ciphertext: ciphertext,
      }),
    });

    if (!response.ok) return [];
    const encryptedResponse = await response.json();
    const decrypted = decryptWithAES_fromResponse(encryptedResponse, aesKey);

    return decrypted || [];
  }

  async function handleAddDrone() {
    if (!rsaPublicKey) return;

    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);
    const avatarUrl = getDroneAvatarUrl(drone.type);
    const { ciphertext, iv } = encryptJsonWithAES_forPassword(
      {
        droneName: drone.name,
        droneType: drone.type,
        frequencyBand: drone.band,
        safetyCode: drone.safety,
        avatarUrl,
      },
      aesKey,
      aesIv
    );
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaPublicKey
      .match(/.{1,64}/g)
      .join("\n")}\n-----END PUBLIC KEY-----`;
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
    if (!encryptedKey) {
      setAddResponse("❌ RSA encryption failed");
      return;
    }
    setAddResponse(null);

    const resp = await fetchWithAuth("/api/map/drone/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
    });

    if (resp.ok) {
      setAddResponse("✅ Drone added successfully.");
      setTimeout(async () => {
        await fetchDrones().then(setDroneList);
        setMode("list");
        setDrone({ name: "", type: "", band: "", safety: "" });
        setAddResponse(null);
      }, 2000);
    } else {
      const text = await resp.text();
      setAddResponse(`❌ ${text}`);
    }
  }

  async function fetchDroneStats(droneId) {
    setLoadingStatsId(droneId);
    const res = await fetchWithAuth("/api/map/drone/public-key");
    const base64 = await res.text();
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
      .match(/.{1,64}/g)
      .join("\n")}\n-----END PUBLIC KEY-----`;

    const aesKey = generateRandomBytes(16);
    const aesIv = generateRandomBytes(16);

    const { ciphertext, iv } = encryptJsonWithAES_forPassword({ droneId }, aesKey, aesIv);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

    const response = await fetchWithAuth("/api/map/stats/getByDroneId", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("jwt")}`,
      },
      body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext }),
    });

    if (!response.ok) {
      setDroneStats((prev) => ({ ...prev, [droneId]: null }));
      setLoadingStatsId(null);
      return;
    }

    const encryptedResponse = await response.json();
    const decrypted = decryptWithAES_fromResponse(encryptedResponse, aesKey);
    setDroneStats((prev) => ({ ...prev, [droneId]: decrypted }));
    setLoadingStatsId(null);
  }

  // Головна зміна — єдиний id обраного дрона, або null
  const handleDroneClick = (drone) => {
    if (expandedDroneId === drone.Id) {
      setExpandedDroneId(null);
      setIsEditMode(false);
      setEditDrone(null);
    } else {
      setExpandedDroneId(drone.Id);
      setIsEditMode(false);
      setEditDrone(null);
      if (!droneStats[drone.Id]) fetchDroneStats(drone.Id);
    }
  };

  async function handleChangeDroneSubmit() {
    setEditResponse(null);
    try {
      // 1. Отримати RSA public key
      const res = await fetchWithAuth("/api/map/drone/public-key");
      const base64 = await res.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      // 2. AES key + IV
      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);
  
      // 3. Шифрувати payload
      const { ciphertext, iv } = encryptJsonWithAES_forPassword({
        droneId: expandedDroneId,
        name: editDrone.name,
        type: editDrone.type,
        band: editDrone.band
      }, aesKey, aesIv);
  
      // 4. Шифрувати AES-ключ через RSA
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
  
      // 5. Відправити PUT
      const resp = await fetchWithAuth("/api/map/drone/updateInfo", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("jwt")}`,
        },
        body: JSON.stringify({ EncryptedKey: encryptedKey, Iv: iv, Ciphertext: ciphertext })
      });
  
      if (resp.ok) {
        setEditResponse("✅ Drone updated successfully.");
        // Оновити список дронів через 2 секунди й повернутися в Work with your drone
        setTimeout(async () => {
          await fetchDrones().then(setDroneList);
          setIsEditMode(false);
          setEditDrone(null);
          setEditResponse(null);
        }, 2000);
      } else {
        const text = await resp.text();
        setEditResponse(`❌ ${text || "Failed to update drone."}`);
      }
    } catch (e) {
      setEditResponse("❌ Network error. Try again.");
    }
  }
  
  async function handleDeleteDrone() {
    setDeleteLoading(true);
    setDeleteError(null);
  
    try {
      // 1. Отримати публічний ключ
      const res = await fetchWithAuth("/api/map/drone/public-key");
      const base64 = await res.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      // 2. AES-ключ та IV
      const aesKey = generateRandomBytes(16);
      const aesIv = generateRandomBytes(16);
  
      // 3. Шифруємо payload (тіло)
      const { ciphertext, iv } = encryptJsonWithAES_forPassword(
        { droneId: expandedDroneId },
        aesKey,
        aesIv
      );
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);
  
      // 4. POST до серверу
      const resp = await fetchWithAuth("/api/map/drone/deleteById", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("jwt")}`,
        },
        body: JSON.stringify({
          EncryptedKey: encryptedKey,
          Iv: iv,
          Ciphertext: ciphertext,
        }),
      });
  
      if (resp.ok) {
        // Успіх: закриваємо модалку, показуємо список дронів
        setShowDeleteModal(false);
        setExpandedDroneId(null);
        setIsEditMode(false);
        setEditDrone(null);
        setDeleteLoading(false);
        // Оновити список
        await fetchDrones().then(setDroneList);
      } else {
        const err = await resp.text();
        setDeleteError(err || "Failed to delete drone.");
        setDeleteLoading(false);
      }
    } catch (e) {
      setDeleteError("Network error. Try again.");
      setDeleteLoading(false);
    }
  }

  // --- UI ---
  return (
    <motion.div
      className="drones-modal"
      ref={modalRef}
      layout
      transition={{ layout: { duration: 0.4, ease: "easeInOut" } }}
    >
      <button className="close-btn" onClick={onBack}>×</button>
      <AnimatedHeightWrapper activeKey={mode + (expandedDroneId ? "-expanded" : "") + (isEditMode ? "-edit" : "")}>
        {/* ====== LIST MODE ====== */}
        {mode === "list" && !expandedDroneId && (
          <>
            <div className="drones-header-row">
              <img src="/icons/droneIcon.png" alt="" className="drones-header-icon" />
              <div className="drones-header">Here are your drones</div>
            </div>
            <div className="drones-section">
              <input
                type="text"
                className="drones-search"
                placeholder="Search drone by name..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
              <div className="drones-list-container">
                {filteredDrones.length === 0 ? (
                  <span>No drones yet.</span>
                ) : (
                  filteredDrones.map((d, i) => (
                    <div key={i} className="drone-list-item-col">
                      <div
                        className="drone-list-item"
                        onClick={() => handleDroneClick(d)}
                        style={{ cursor: "pointer", marginBottom: "0.7rem" }}
                      >
                        <img
                          src={d.AvatarUrl || getDroneAvatarUrl(d.DroneType)}
                          alt="drone avatar"
                          className="drone-avatar"
                        />
                        <div className="drone-info">
                          <span className={`drone-type-label ${getTypeClass(d.DroneType)}`}>
                            {d.DroneType}
                          </span>
                          <div className="drone-main-row">
                            <span className="drone-name">{d.DroneName}</span>
                          </div>
                          <div className="drone-band-row">
                            <span className="drone-band-label">Band:</span>{" "}
                            <span>{d.FrequencyBand}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <button className="drones-add-btn" onClick={() => setMode("add")}>
                Add New Drone
              </button>
            </div>
          </>
        )}

        {/* ====== SINGLE DRONE: Work with your drone ====== */}
        {mode === "list" && expandedDroneId && !isEditMode && (() => {
          const d = droneList.find(dr => dr.Id === expandedDroneId);
          if (!d) return null;
          return (
            <>
              <div className="drones-header-row">
                <img src="/icons/droneIcon.png" alt="" className="drones-header-icon" />
                <div className="drones-header">Work with your drone</div>
              </div>
              <div className="drones-section">
                <div className="drone-list-item-col" style={{ margin: "0 auto" }}>
                  <div
                    className="drone-list-item expanded"
                    onClick={() => handleDroneClick(d)}
                    style={{
                      cursor: "pointer",
                      marginBottom: "0.7rem",
                    }}
                  >
                    <img
                      src={d.AvatarUrl || getDroneAvatarUrl(d.DroneType)}
                      alt="drone avatar"
                      className="drone-avatar"
                    />
                    <div className="drone-info">
                      <span className={`drone-type-label ${getTypeClass(d.DroneType)}`}>
                        {d.DroneType}
                      </span>
                      <div className="drone-main-row">
                        <span className="drone-name">{d.DroneName}</span>
                      </div>
                      <div className="drone-band-row">
                        <span className="drone-band-label">Band:</span>{" "}
                        <span>{d.FrequencyBand}</span>
                      </div>
                    </div>
                  </div>
                  <div className="drone-detail-expanded inner-detail">
                  <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
                    <button
                      className="drones-add-btn"
                      style={{
                        flex: 1,
                        fontSize: 16,
                        fontWeight: 600,
                        background: "#445566"
                      }}
                      onClick={() => handleChangeDroneClick(d)}
                    >
                      Change Drone
                    </button>
                    <button
                      className="drones-add-btn"
                      style={{
                        flex: 1,
                        fontSize: 16,
                        fontWeight: 600,
                        background: "#e16171"
                      }}
                      onClick={() => setShowDeleteModal(true)}
                    >
                      Delete Drone
                    </button>
                  </div>
                    {loadingStatsId === d.Id ? (
                      <div style={{ textAlign: "center", color: "#bbb", padding: "14px 0" }}>
                        Loading stats...
                      </div>
                    ) : (
                      <div>
                        {Array.isArray(droneStats[d.Id]) ? (
                          <table className="stats-table">
                            <tbody>
                              {droneStats[d.Id].map((stat, idx) => (
                                <tr key={idx}>
                                  <td style={{ color: "#77e7e7", fontWeight: 600, paddingRight: 12, fontSize: 15 }}>
                                    {stat.StatsType}
                                  </td>
                                  <td style={{ color: "#fff", fontWeight: 600, fontSize: 15 }}>
                                    {stat.StatsInformation === "Initial value" ? (
                                      <span style={{ color: "#8e8e8e", fontStyle: "italic" }}>No data</span>
                                    ) : (
                                      stat.StatsInformation
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        ) : (
                          <div style={{ color: "#ffbaba", padding: 10, textAlign: "center" }}>
                            No stats found.
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </>
          );
        })()}

        {/* ====== SINGLE DRONE: Change your drone ====== */}
        {mode === "list" && expandedDroneId && isEditMode && (() => {
          const d = droneList.find(dr => dr.Id === expandedDroneId);
          if (!d) return null;
          return (
            <>
              <div className="drones-header-row">
                <img src="/icons/droneIcon.png" alt="" className="drones-header-icon" />
                <div className="drones-header">Change your drone</div>
              </div>
              <div className="drones-section">
                <div className="drone-list-item-col" style={{ margin: "0 auto" }}>
                  <div className="drone-detail-expanded inner-detail">
                    {/* Name */}
                    <input
                      type="text"
                      className="drones-input"
                      placeholder="Drone Name"
                      name="name"
                      value={editDrone?.name ?? ""}
                      onChange={e =>
                        setEditDrone(prev => ({ ...prev, name: e.target.value }))
                      }
                      autoFocus
                      style={{ marginBottom: 16 }}
                    />
                    {/* Type + Quick Select */}
                    <input
                      type="text"
                      className="drones-input"
                      placeholder="Type"
                      name="type"
                      value={editDrone?.type ?? ""}
                      onChange={e =>
                        setEditDrone(prev => ({ ...prev, type: e.target.value }))
                      }
                    />
                    <div className="drones-type-row">
                      {["attack", "transport", "scout"].map(type => (
                        <button
                          key={type}
                          type="button"
                          className={`drones-type-btn${editDrone?.type === type ? " active" : ""}`}
                          onClick={() => setEditDrone(prev => ({ ...prev, type }))}
                        >
                          {type[0].toUpperCase() + type.slice(1)}
                        </button>
                      ))}
                    </div>
                    {/* Band */}
                    <input
                      type="text"
                      className="drones-input"
                      placeholder="Frequency Band"
                      name="band"
                      value={editDrone?.band ?? ""}
                      onChange={e =>
                        setEditDrone(prev => ({ ...prev, band: e.target.value }))
                      }
                      style={{ marginBottom: 16 }}
                    />
                    {/* Actions */}
                    <div className="drones-actions-row">
                      <button
                        className={`drones-add-btn drones-add${isEditValid ? "" : " drones-add-disabled"}`}
                        disabled={!isEditValid}
                        onClick={handleChangeDroneSubmit}
                      >
                        Change
                      </button>
                      <button
                        className="drones-add-btn drones-cancel"
                        onClick={handleCancelEdit}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
                {editResponse && (
                  <div className="form-response-wrappers">
                    <div className={`form-responses ${editResponse.startsWith("✅") ? "success" : "error"}`}>
                      {editResponse}
                    </div>
                  </div>
                )}
              </div>
            </>
          );
        })()}

        {/* ====== ADD MODE ====== */}
        {mode === "add" && (
          <>
            <div className="drones-header-row">
              <img src="/icons/droneIcon.png" alt="" className="drones-header-icon" />
              <div className="drones-header">Add New Drone</div>
            </div>
            <div className="drones-section">
              <hr className="divider" />
              <input
                type="text"
                className="drones-input"
                placeholder="Drone Name"
                name="name"
                value={drone.name}
                onChange={handleInput}
                autoFocus
              />
              <input
                type="text"
                className="drones-input"
                placeholder="Type"
                name="type"
                value={drone.type}
                onChange={handleInput}
              />
              <div className="drones-type-row">
                {["attack", "transport", "scout"].map(type => (
                  <button
                    key={type}
                    type="button"
                    className={`drones-type-btn${drone.type === type ? " active" : ""}`}
                    onClick={() => setDrone(prev => ({ ...prev, type }))}
                  >
                    {type[0].toUpperCase() + type.slice(1)}
                  </button>
                ))}
              </div>
              <input
                type="text"
                className="drones-input"
                placeholder="Frequency Band"
                name="band"
                value={drone.band}
                onChange={handleInput}
              />
              <div style={{ height: 12 }} />
              <input
                type="text"
                className="drones-input safety"
                placeholder="Safety Code: Use 13-character code"
                name="safety"
                value={drone.safety}
                onChange={e =>
                  setDrone(prev => ({
                    ...prev,
                    safety: e.target.value.replace(/\D/g, "")
                  }))
                }
                maxLength={13}
                inputMode="numeric"
                pattern="[0-9]*"
              />
              <div className="drones-actions-row">
                <button
                  className={`drones-add-btn drones-add${!allFilled || !rsaPublicKey ? " drones-add-disabled" : ""}`}
                  disabled={!allFilled || !rsaPublicKey}
                  onClick={handleAddDrone}
                >
                  Add
                </button>
                <button
                  className="drones-add-btn drones-cancel"
                  onClick={() => setMode("list")}
                >
                  Cancel
                </button>
              </div>
              {addResponse && (
                <div className="form-response-wrappers">
                  <div className={`form-responses ${addResponse.startsWith("✅") ? "success" : "error"}`}>
                    {addResponse}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </AnimatedHeightWrapper>
      <DeleteDroneModal
        open={showDeleteModal}
        title="Are you sure you want to delete the drone?"
        confirmText="Delete"
        cancelText="Cancel"
        loading={deleteLoading}
        error={deleteError}
        onConfirm={handleDeleteDrone}
        onClose={() => {
          setShowDeleteModal(false);
          setDeleteLoading(false);
          setDeleteError(null);
        }}
      />
    </motion.div>
  );
}
