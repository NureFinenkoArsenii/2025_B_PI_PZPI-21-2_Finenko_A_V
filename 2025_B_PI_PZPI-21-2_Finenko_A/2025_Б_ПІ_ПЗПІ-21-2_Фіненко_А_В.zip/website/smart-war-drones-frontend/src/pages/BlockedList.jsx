import { useEffect, useState, useRef } from "react";
import { fetchWithAuth } from "../utils/tokenManager";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";

export default function BlockedList({ searchQuery = "" }) {
  const [blocked, setBlocked] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUnblockModal, setShowUnblockModal] = useState(false);
  const [unblockUserId, setUnblockUserId] = useState(null);
  const [unblocking, setUnblocking] = useState(false);
  const unblockModalRef = useRef();

  const filteredBlocked = searchQuery
  ? blocked.filter(f =>
      (f.name || "")
        .toLowerCase()
        .includes(searchQuery.toLowerCase())
    )
  : blocked;

  useEffect(() => {
    if (showUnblockModal && unblockModalRef.current) {
      unblockModalRef.current.focus();
    }
  }, [showUnblockModal]);

  async function handleUnblock(userId) {
    setUnblocking(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
      const payload = { userId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      await fetchWithAuth("/api/contacts/unblock", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
  
      setShowUnblockModal(false);
      setUnblockUserId(null);
      loadBlocked();
    } catch (err) {
      alert("Failed to unblock: " + err?.message);
    }
    setUnblocking(false);
  }
  

  useEffect(() => { loadBlocked(); }, []);

  async function loadBlocked() {
    setLoading(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/blocked", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setBlocked(data);
      setLoading(false);
    } catch (err) {
      console.error("❌ Failed to load blocked users", err);
      setLoading(false);
    }
  }

  // --- CUSTOM AVATAR LOGIC ---
  useEffect(() => {
    blocked.forEach(async (user, idx) => {
      if (user.avatarType === "custom" && !user.avatarPreviewUrl && user.id) {
        try {
          const token = localStorage.getItem("jwt");
          const fileRes = await fetch(`/api/profile/avatar-file/${user.id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (!fileRes.ok) throw new Error("Cannot get avatar file");
          const fileBuffer = await fileRes.arrayBuffer();

          const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
          const rsaKeyBase64 = await rsaKeyRes.text();
          const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

          const sessionAesKey = generateRandomBytes(16);
          const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
          const encryptor = new JSEncrypt();
          encryptor.setPublicKey(rsaKeyPem);
          const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

          const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${user.id}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ encryptedSessionAesKey }),
          });
          const { iv, ciphertext } = await resp.json();

          const keyBytes = sessionAesKey;
          const ivWord = CryptoJS.enc.Base64.parse(iv);
          const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
            iv: ivWord,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          });

          const avatarAesKeyBytes = Uint8Array.from(
            decrypted.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decrypted.sigBytes)
          );

          const fileBytes = new Uint8Array(fileBuffer);
          const fileIv = fileBytes.slice(0, 16);
          const fileCipher = fileBytes.slice(16);

          const decWord = CryptoJS.AES.decrypt(
            { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
            CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
            {
              iv: CryptoJS.lib.WordArray.create(fileIv),
              mode: CryptoJS.mode.CBC,
              padding: CryptoJS.pad.Pkcs7,
            }
          );

          const uint8Decrypted = Uint8Array.from(
            decWord.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decWord.sigBytes)
          );

          const blob = new Blob([uint8Decrypted], { type: "image/png" });
          const url = URL.createObjectURL(blob);

          setBlocked(prev =>
            prev.map((u, i) =>
              i === idx ? { ...u, avatarPreviewUrl: url } : u
            )
          );
        } catch (err) {
          console.error("❌ Failed to fetch/decrypt custom avatar (blocked):", err);
        }
      }
    });
    // eslint-disable-next-line
  }, [blocked.length]);

  function getFirstTwoLines(text) {
    if (!text) return "";
    const lines = text.split('\n');
    if (lines.length <= 2) return text;
    return lines.slice(0, 2).join('\n') + '…';
  }

  if (loading) return <div className="loading-text">Loading blocked users...</div>;
  if (!filteredBlocked || filteredBlocked.length === 0)
    return <div className="empty-text">No users found</div>;

  return (
    <div className="requests-list">
      {filteredBlocked.map((user, idx) => (
        <div key={user.id} className="request-item">
          <img
            src={
              user.avatarType === "custom"
                ? (user.avatarPreviewUrl || "/avatars/avatar1.png")
                : (user.avatarUrl || "/avatars/avatar1.png")
            }
            alt="avatar"
            className="avatar-preview"
          />
          <div className="info">
            <div className="name">{user.name}</div>
            <div className="role">{user.role}</div>
            <div className="bio">{getFirstTwoLines(user.bio)}</div>
          </div>
          <div className="actions">
          <button
            className="icon-action-btn"
            title="Unblock"
            onClick={() => {
                setUnblockUserId(user.id);
                setShowUnblockModal(true);
            }}
            >
            <img src="/icons/unblockIcon.png" alt="Unblock" />
            </button>
          </div>
        </div>
      ))}

{showUnblockModal && (
  <div className="confirm-modal"
    tabIndex={-1}
    onClick={e => {
      if (e.target.classList.contains("confirm-modal")) {
        setShowUnblockModal(false);
        setUnblockUserId(null);
      }
    }}
    onKeyDown={e => {
      if (e.key === "Escape") {
        setShowUnblockModal(false);
        setUnblockUserId(null);
      }
    }}
    ref={unblockModalRef}
    style={{ display: "flex", alignItems: "center", justifyContent: "center" }}
  >
    <div className="confirm-box">
      <p>Do you want to Unblock the user?</p>
      <div className="confirm-actions">
        <button
          style={{ background: "#00e0d1", color: "#06262c" }}
          disabled={unblocking}
          onClick={() => handleUnblock(unblockUserId)}
        >
          Unblock
        </button>
        <button
          style={{ background: "#293750" }}
          disabled={unblocking}
          onClick={() => {
            setShowUnblockModal(false);
            setUnblockUserId(null);
          }}
        >
          Cancel
        </button>
      </div>
    </div>
  </div>
)}
    </div>
  );
}
