import PageWrapper from "../components/PageWrapper";
import "../styles/pages/_about.scss";

export default function About() {
  return (
    <PageWrapper>
      <div className="about-container">
        <h1>About</h1>
      </div>
    </PageWrapper>
  );
}
