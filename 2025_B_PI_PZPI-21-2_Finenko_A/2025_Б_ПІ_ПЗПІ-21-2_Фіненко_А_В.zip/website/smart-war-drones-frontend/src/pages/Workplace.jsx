import { useEffect, useState, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { getValidAccessToken, getUserRole, fetchWithAuth } from "../utils/tokenManager";
import WorkplaceLayout from "../layout/WorkplaceLayout";
import MessagesView from "./MessagesView";
import "../styles/pages/_workplace.scss";
import BattlefieldModal from "./BattlefieldModal";
import PreviewImageModal from "../components/PreviewImageModal";
import DeleteBattlefieldModal from "../components/DeleteBattlefieldModal";
import BlockUserFromBattlefieldModal from "../components/BlockUserFromBattlefieldModal";
import EditBattlefieldModal from "./EditBattlefieldModal";
import LeaveBattlefieldConfirmModal from "../components/LeaveBattlefieldConfirmModal";

// SignalR
import * as signalR from "@microsoft/signalr";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import CryptoJS from "crypto-js";

export default function Workplace() {
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState(null);
  const [avatarProps, setAvatarProps] = useState(null);
  const navigate = useNavigate();
  const [unreadChatsCount, setUnreadChatsCount] = useState(0);
  const location = useLocation();
  const [friendRequestCount, setFriendRequestCount] = useState(0);
  const [showBattlefieldModal, setShowBattlefieldModal] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [previewSrc, setPreviewSrc] = useState(""); 
  const [customAvatars, setCustomAvatars] = useState({});
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [blockModalOpen, setBlockModalOpen] = useState(false);
  const [blockTarget, setBlockTarget] = useState(null);
  const [blocking, setBlocking] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [battlefieldToEdit, setBattlefieldToEdit] = useState(null);
  const [leaveModalOpen, setLeaveModalOpen] = useState(false);
  const [leaveTarget, setLeaveTarget] = useState(null);
  const [leaving, setLeaving] = useState(false);

    
  const [joinRequests, setJoinRequests] = useState([]);
  const [joinRequestsMessage, setJoinRequestsMessage] = useState("");
  const [battlefields, setBattlefields] = useState([]);  // [{name, id, ...}]


    // For demo (замінити на API далі!)
  useEffect(() => {
    setJoinRequests([]); // або наприклад ['Operator1']
    setBattlefields([]); // або [{name: 'Kyiv direction'}]
  }, []);

  // SignalR
  const connectionRef = useRef(null);

  const isMessagesMode = location.pathname === "/workplace/messages";

  const refreshFriendRequestCount = async () => {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/requests", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setFriendRequestCount(data.length);
    } catch (err) {
      setFriendRequestCount(0);
    }
  };

  const leaveBattlefield = async (battlefieldId) => {
    try {
      setLeaving(true);
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { battlefieldId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      const resp = await fetchWithAuth("/api/battlefields/leaving-battlefield", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      if (!resp.ok) throw new Error(await resp.text());
  
      await fetchBattlefields(); // Оновлюємо список після виходу
      setLeaveModalOpen(false);
      setLeaveTarget(null);
    } catch (err) {
      alert("Failed to leave battlefield: " + (err.message || err));
    } finally {
      setLeaving(false);
    }
  };
  

async function fetchAndDecryptCustomAvatar(userId) {
  try {
    const token = localStorage.getItem("jwt");
    const fileRes = await fetch(`/api/profile/avatar-file/${userId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!fileRes.ok) throw new Error("Cannot get avatar file");
    const fileBuffer = await fileRes.arrayBuffer();
    console.log("File buffer length:", fileBuffer.byteLength);
    const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
    const rsaKeyBase64 = await rsaKeyRes.text();
    const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

    const sessionAesKey = generateRandomBytes(16);
    const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
    const JSEncrypt = (await import("jsencrypt")).default;
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(rsaKeyPem);
    const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

    const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${userId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ encryptedSessionAesKey }),
    });
    const { iv, ciphertext } = await resp.json();

    const keyBytes = sessionAesKey;
    const ivWord = CryptoJS.enc.Base64.parse(iv);
    const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
      iv: ivWord,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    const avatarAesKeyBytes = Uint8Array.from(
      decrypted.words.flatMap(w => [
        (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
      ]).slice(0, decrypted.sigBytes)
    );

    const fileBytes = new Uint8Array(fileBuffer);
    const fileIv = fileBytes.slice(0, 16);
    const fileCipher = fileBytes.slice(16);

    const decWord = CryptoJS.AES.decrypt(
      { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
      CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
      {
        iv: CryptoJS.lib.WordArray.create(fileIv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );

    const uint8Decrypted = Uint8Array.from(
      decWord.words.flatMap(w => [
        (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
      ]).slice(0, decWord.sigBytes)
    );

    const blob = new Blob([uint8Decrypted], { type: "image/png" });
    const url = URL.createObjectURL(blob);
    console.log("Blob size", uint8Decrypted.length, "url:", url);
    return url;
  } catch (err) {
    console.error("Failed to decrypt avatar:", err);
    cb(null);
  }
}

  const refreshUnreadChatsCount = async () => {
    try {
      // Тут твій API запит який повертає масив чатів або просто count
      // Наприклад, зробимо як у FriendRequests.jsx:
      const pubKeyBase64 = await fetchWithAuth("/api/messages/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
  
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);
  
      const resp = await fetchWithAuth("/api/messages/unread-count", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setUnreadChatsCount(data.count); // або data.length, якщо це масив чатів
    } catch (err) {
      setUnreadChatsCount(0);
    }
  };
  
  useEffect(() => {
    refreshUnreadChatsCount();
  }, []);
  
  useEffect(() => {
    let connection;
    let userId;
    async function connectSignalR() {
      // ... твій код
      connection = new signalR.HubConnectionBuilder()
        .withUrl("http://localhost:5189/hubs/friends", {
          withCredentials: true,
          accessTokenFactory: () => token,
        })
        .withAutomaticReconnect()
        .build();
  
      connection.on("FriendRequestUpdated", () => refreshFriendRequestCount());
      connection.on("UnreadChatsUpdated", () => refreshUnreadChatsCount()); // <---- Додаємо
  
      // ...далі твій код
    }
    connectSignalR();
  
    return () => {
      // ...
    }
  }, []);
  

  // SignalR init
  useEffect(() => {
    let connection;
    let userId;

    async function connectSignalR() {
      const token = await getValidAccessToken();
      if (!token) return;

      // Витягуємо userId з токена (localStorage, декодер або серверна функція)
      try {
        // Припустимо, що userId лежить в JWT у claim "sub" або "nameid":
        // Якщо є util getUserIdFromToken, використай його
        userId = JSON.parse(atob(token.split('.')[1])).sub 
          || JSON.parse(atob(token.split('.')[1]))["nameid"]
          || JSON.parse(atob(token.split('.')[1])).userId
          || null;
      } catch (e) {
        userId = null;
      }

      if (!userId) return;

      // Підключення
      connection = new signalR.HubConnectionBuilder()
        .withUrl("http://localhost:5189/hubs/friends", {
          withCredentials: true,
          accessTokenFactory: () => token,
        })
        .withAutomaticReconnect()
        .build();

      connection.on("FriendRequestUpdated", () => {
        // Просто оновлюємо лічильник запитів, як тільки приходить сигнал
        refreshFriendRequestCount();
      });

      try {
        await connection.start();
        await connection.invoke("Subscribe", userId);
        connectionRef.current = connection;
      } catch (err) {
        // Якщо не вдалося підключитися, не фейли весь компонент
        console.error("[SignalR] Failed to connect", err);
      }
    }

    connectSignalR();

    return () => {
      if (connectionRef.current && userId) {
        connectionRef.current.invoke("Unsubscribe", userId).finally(() => {
          connectionRef.current.stop();
        });
      }
    };
    // eslint-disable-next-line
  }, []); // запускаємо один раз на монтування

  // Оновлюємо при першому завантаженні
  useEffect(() => {
    refreshFriendRequestCount();
  }, []);

  useEffect(() => {
    async function init() {
      const token = await getValidAccessToken();
      if (!token) {
        navigate("/");
        return;
      }
      const role = getUserRole();
      if (!role) {
        console.error("❌ Failed to extract role from token.");
        navigate("/");
        return;
      }

      let avatarProps = { avatarType: "default", avatarUrl: "/avatars/avatar1.png" };
      try {
        const res = await fetchWithAuth("/api/pages/workplace");
        if (res.ok) {
          const data = await res.json();

          let avatarProps;
          if (
            data.avatarType === "custom" ||
            (!data.avatarType && data.avatarUrl && data.avatarUrl.length > 100)
          ) {
            // custom avatar
            const fileRes = await fetchWithAuth(`/api/profile/avatar-file/${data.userId}`);
            const encryptedBlob = fileRes.ok ? await fileRes.arrayBuffer() : null;
            avatarProps = {
              avatarType: "custom",
              encryptedBlob,
              userId: data.userId,
            };
          } else {
            avatarProps = {
              avatarType: "default",
              avatarUrl: data.avatarUrl || "/avatars/avatar1.png",
            };
          }
          setAvatarProps(avatarProps);
        }
      } catch (e) {
        setAvatarProps({ avatarType: "default", avatarUrl: "/avatars/avatar1.png" });
      }

      setUserRole(role);
      setLoading(false);
    }

    init();
  }, [navigate]);

  const isOfficer = userRole === "officer";
  const isOperator = userRole === "operator";

// Додаємо у компонент Workplace
const isBattlefieldOwner = async (battlefieldId) => {
  try {
    const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
    const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
    const aesKey = generateRandomBytes(16);
    const iv = generateRandomBytes(16);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
    const payload = { battlefieldId };
    const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

    const resp = await fetchWithAuth("/api/battlefields/is-owner", {
      method: "POST",
      body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
    });
    if (!resp.ok) return false;
    const result = await resp.json();

    const ivData = CryptoJS.enc.Base64.parse(result.iv);
    const key = bytesToWordArray(aesKey);
    const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
      iv: ivData,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);

    let data;
    try {
      data = JSON.parse(jsonStr);
    } catch {
      return false;
    }
    return !!data.isOwner;
  } catch {
    return false;
  }
};

const fetchBattlefields = async () => {
  try {
    const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
    const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
    const aesKey = generateRandomBytes(16);
    const iv = generateRandomBytes(16);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
    const payload = { dummy: true };
    const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

    const resp = await fetchWithAuth("/api/battlefields/my-battlefields", {
      method: "POST",
      body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
    });
    const result = await resp.json();

    const ivData = CryptoJS.enc.Base64.parse(result.iv);
    const key = bytesToWordArray(aesKey);
    const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
      iv: ivData,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);

    let data;
    try {
      data = JSON.parse(jsonStr);
    } catch {
      setBattlefields([]);
      return;
    }

    // ---- ОНОВЛЕНО: додаємо isOwner!
    const newBattlefields = await Promise.all(
      data.map(async (bf) => {
        let previewUrl;
        if (bf.mapAvatarUrl && !bf.mapAvatarUrl.includes("defaultBattlefieldPreview.png")) {
          // Отримати превью-файл
          const aesKeyFile = generateRandomBytes(16);
          const ivFile = generateRandomBytes(16);
          const encryptedKeyFile = encryptAESKeyWithRSA_forPassword(aesKeyFile, pubKeyPem);
          const { ciphertext: ciph, iv: ivB64 } = encryptJsonWithAES_forPassword(
            { battlefieldId: bf.id },
            aesKeyFile,
            ivFile
          );

          const fileResp = await fetchWithAuth("/api/battlefields/preview-file", {
            method: "POST",
            body: JSON.stringify({ encryptedKey: encryptedKeyFile, iv: ivB64, ciphertext: ciph }),
          });

          if (fileResp.ok) {
            const blob = await fileResp.blob();
            previewUrl = URL.createObjectURL(blob);
          } else {
            previewUrl = "/battlefieldPreview/defaultBattlefieldPreview.png";
          }
        } else {
          previewUrl = bf.mapAvatarUrl || "/battlefieldPreview/defaultBattlefieldPreview.png";
        }

        // --- Ось тут перевіряємо чи є власником!
        const isOwner = await isBattlefieldOwner(bf.id);

        return {
          ...bf,
          resolvedPreviewUrl: previewUrl,
          isOwner,
        };
      })
    );

    setBattlefields(newBattlefields);
    console.log('[Workplace] setBattlefields:', newBattlefields);
  } catch (err) {
    setBattlefields([]);
  }
};

const handleBattlefieldCreated = () => {
  setShowBattlefieldModal(false);
  fetchBattlefields(); // <-- тут оновлюємо список!
};

const fetchJoinRequests = async () => {
  try {
    const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
    const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
    const aesKey = generateRandomBytes(16);
    const iv = generateRandomBytes(16);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
    const payload = { dummy: true };
    const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

    const resp = await fetchWithAuth("/api/battlefields/join-requests", {
      method: "POST",
      body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
    });
    const result = await resp.json();

    const ivData = CryptoJS.enc.Base64.parse(result.iv);
    const key = bytesToWordArray(aesKey);
    const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
      iv: ivData,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);

    let data;
    try {
      data = JSON.parse(jsonStr);
    } catch {
      setJoinRequests([]);
      setJoinRequestsMessage("Failed to parse requests");
      return;
    }

    console.log("JOIN REQUEST DATA:", data);

    if (Array.isArray(data)) {
      const avatars = { ...customAvatars };
      await Promise.all(
        data.map(async req => {
          if (
            req.sender &&
            req.sender.avatarType === "custom" &&
            req.sender.id &&
            !avatars[req.sender.id]
          ) {
            const url = await fetchAndDecryptCustomAvatar(req.sender.id);
            avatars[req.sender.id] = url;
          }
        })
      );
      setCustomAvatars(avatars);
      setJoinRequests(data);
      setJoinRequestsMessage("");
    } else if (data && data.message) {
      setJoinRequests([]);
      setJoinRequestsMessage(data.message);
    } else {
      setJoinRequests([]);
      setJoinRequestsMessage("No requests to join in battlefields");
    }
  } catch (err) {
    setJoinRequests([]);
    setJoinRequestsMessage("Failed to load requests");
  }
};

  
  useEffect(() => {
    fetchBattlefields();
    fetchJoinRequests();
  }, []);

  const deleteBattlefield = async (battlefieldId) => {
    try {
      // Отримати public key для battlefield
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      // AES session
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
  
      // Payload — лише battlefieldId
      const payload = { battlefieldId };
  
      // Шифруємо
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      // Запит на видалення
      const resp = await fetchWithAuth("/api/battlefields/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      if (!resp.ok) {
        const errText = await resp.text();
        throw new Error(errText || "Failed to delete battlefield.");
      }
  
      // Якщо все успішно, оновлюємо список
      fetchBattlefields();
    } catch (err) {
      alert("Failed to delete battlefield: " + (err.message || err));
    }
  };
  
  
  const acceptJoinRequest = async (request) => {
    try {
      // Витягуємо publicKey для battlefields
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
  
      // Формуємо payload
      const payload = {
        battlefieldId: request.battlefield.id, // це твій plaintext id
        requestId: request.requestId || request.id, // requestId має бути окремо в даних заявки
      };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
      // Відправляємо запит
      const resp = await fetchWithAuth("/api/battlefields/accept-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      if (!resp.ok) {
        const errText = await resp.text();
        throw new Error(errText || "Failed to accept request.");
      }
  
      // Оновлюємо списки після дії!
      await fetchJoinRequests();
      await fetchBattlefields();
    } catch (err) {
      alert("Failed to accept join request: " + (err.message || err));
    }
  };

  const rejectJoinRequest = async (request) => {
    try {
      // публічний ключ як для інших battlefields-запитів
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
  
      const payload = { requestId: request.requestId }; // Айді заявки
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
      const resp = await fetchWithAuth("/api/battlefields/reject-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      if (!resp.ok) throw new Error(await resp.text());
      // Оновити запити після видалення:
      await fetchJoinRequests();
    } catch (err) {
      alert("Failed to reject join request: " + (err.message || err));
    }
  };
  
  const blockUser = async (userId) => {
    try {
      setBlocking(true);
      // Отримай public key для contacts
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { userId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
      const resp = await fetchWithAuth("/api/contacts/block", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
  
      if (!resp.ok) throw new Error(await resp.text());
  
      // Онови joinRequests після блокування
      await fetchJoinRequests();
    } catch (err) {
      alert("Failed to block user: " + (err.message || err));
    } finally {
      setBlocking(false);
      setBlockModalOpen(false);
      setBlockTarget(null);
    }
  };





  if (loading) return <p>loading...</p>;


  return (
    <>
    <PreviewImageModal
      src={previewSrc}
      open={previewModalOpen}
      onClose={() => setPreviewModalOpen(false)}
    />
    <WorkplaceLayout
      avatarProps={avatarProps}
      setAvatarProps={setAvatarProps}
      isMessagesMode={isMessagesMode}
      friendRequestCount={friendRequestCount}
      refreshFriendRequestCount={refreshFriendRequestCount}
      unreadChatsCount={unreadChatsCount}
    >
      {isMessagesMode ? (
        <MessagesView onUnreadChatsCountChange={setUnreadChatsCount}/>
      ) : (
        <>
        <div className="workplace-main-section">
        <div className="workplace-main-flex">
        {/* Ліва колонка — Запити */}
        <section className="workplace-requests">
          <h3>Join Requests</h3>
          <div className="workplace-requests-list">
            {joinRequests.length === 0 ? (
              <div className="workplace-empty-text">{joinRequestsMessage || "No requests to join in battlefields"}</div>
            ) : (
              joinRequests.map((req, idx) => {
                // логіка аватарки
                let avatarSrc = "/avatars/avatar1.png";
                  if (req.sender.avatarType === "custom" && customAvatars[req.sender.id]) {
                    avatarSrc = customAvatars[req.sender.id];
                  } else if (req.sender.avatarType === "default" && req.sender.avatarUrl) {
                    avatarSrc = req.sender.avatarUrl;
                  }
                return (
                  <div key={idx} className="workplace-request-item">
                    <div className="request-info">
                      <img
                        src={avatarSrc}
                        alt="avatar"
                        style={{
                          width: 44,
                          height: 44,
                          borderRadius: "50%",
                          objectFit: "cover",
                          border: "2px solid #009999"
                        }}
                      />
                      <div>
                        <div style={{ fontWeight: 600, color: "#00e0d1", fontSize: "1.07rem" }}>
                          {req.sender.name}
                        </div>
                        <div style={{ fontSize: ".99rem", opacity: .82 }}>
                          New request to join <b>{req.battlefield.name}</b>
                        </div>
                      </div>
                    </div>
                    <div className="request-actions" style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 13,
                      marginLeft: 28,
                      minWidth: 40,
                    }}>
                      <img
                        src="/icons/acceptIcon.png"
                        alt="Accept"
                        title="Accept request"
                        className="icon-btn"
                        style={{ width: 25, height: 25, cursor: "pointer" }}
                        onClick={() => acceptJoinRequest(req)}
                      />
                      <img
                        src="/icons/rejectIcon.png"
                        alt="Reject"
                        title="Reject request"
                        className="icon-btn"
                        style={{ width: 25, height: 25, cursor: "pointer" }}
                        onClick={() => rejectJoinRequest(req)}
                      />
                      <img
                        src="/icons/blockUserIcon.png"
                        alt="Block"
                        title="Block user"
                        className="icon-btn"
                        style={{ width: 25, height: 25, cursor: "pointer" }}
                        onClick={() => setBlockTarget(req.sender)}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
        {/* Права колонка — Battlefields */}
        <section className="workplace-battlefields">
  <h3>Battlefields</h3>
  <div className="workplace-battlefields-list">
    {battlefields.length === 0 ? (
      <div className="workplace-empty-text">
        {isOfficer
          ? "Here you can set a battlefield, add people and work together"
          : "It seems you are not joined to any battlefield"}
      </div>
    ) : (
      battlefields.map((bf, idx) => (
        <div
          key={bf.id || idx}
          className="workplace-bf-card"
          onClick={() => navigate(`/workplace/battlefield/${bf.id}`, { state: { battlefield: bf } })}
          style={{ cursor: "pointer" }}
        >
          <img
            src={bf.resolvedPreviewUrl}
            alt="Preview"
            className="battlefield-preview-img"
            style={{ width: "80px", height: "80px", borderRadius: "12px", objectFit: "cover", marginRight: 16, cursor: "pointer" }}
            onClick={(e) => {
              e.stopPropagation();
              setPreviewSrc(bf.resolvedPreviewUrl);
              setPreviewModalOpen(true);
            }}
          />
          <div className="battlefield-info-block">
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <h4 className="battlefield-title" style={{ margin: 0 }}>
                {bf.name}
              </h4>
            </div>
            {bf.about && (
              <div className="battlefield-about">{bf.about}</div>
            )}
          </div>
          {bf.isOwner ? (
          <div className="battlefield-owner-icons" style={{ display: "flex", gap: "12px" }}>
            <img
              src="/icons/editBattlefieldInfoIcon.png"
              alt="Edit"
              title="Edit battlefield"
              className="battlefield-action-icon"
              style={{ cursor: "pointer", width: "28px", height: "28px" }}
              onClick={(e) => { 
                e.stopPropagation();
                setBattlefieldToEdit(bf);
                setEditModalOpen(true);
              }}
            />
            <img
              src="/icons/deleteBattlefieldIcon.png"
              alt="Delete"
              title="Delete battlefield"
              className="battlefield-action-icon"
              style={{ cursor: "pointer", width: "28px", height: "28px" }}
              onClick={(e) => {
                e.stopPropagation();
                setDeleteTarget({ id: bf.id, name: bf.name });
              }}
            />
          </div>
        ) : (
          <div className="battlefield-owner-icons" style={{ display: "flex", gap: "12px" }}>
            <img
              src="/icons/rejectIcon.png"
              alt="Leave battlefield"
              title="Leave this battlefield"
              className="battlefield-action-icon"
              style={{ cursor: "pointer", width: "20px", height: "20px" }}
              onClick={e => {
                e.stopPropagation();
                setLeaveTarget(bf);
                setLeaveModalOpen(true);
              }}
            />
          </div>
          )}
           {bf.isOwner && (
                <span className="owner-label">owner</span>
              )}
        </div>
      ))
    )}
  </div>
</section>

        </div>
      {isOfficer && (
        <div className="workplace-new-bf-center">
          <button className="new-battlefield-btn" onClick={() => setShowBattlefieldModal(true)}>
            Set a New Battlefield
          </button>
          <BattlefieldModal
            open={showBattlefieldModal}
            onClose={() => setShowBattlefieldModal(false)}
            onCreated={handleBattlefieldCreated}
          />
        </div>
      )}
      </div>
      {/* Окремо! */}
      <div className="map-float-button">
        <button className="work-map-btn" onClick={() => navigate("/workplace/map")}>
          Work with Map
        </button>
      </div>
      <div className="logout-icon-wrapper" title="Log Out">
        <img
          src="/icons/logOutIcon.png"
          alt="Log out"
          className="logout-icon"
          onClick={async () => {
            try {
              await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
            } catch (err) {}
            localStorage.clear();
            navigate("/");
          }}
        />
      </div>
    </>
  )}
</WorkplaceLayout>
<DeleteBattlefieldModal
  open={!!deleteTarget}
  onClose={() => setDeleteTarget(null)}
  onDelete={async () => {
    if (deleteTarget?.id) {
      setDeleting(true);
      await deleteBattlefield(deleteTarget.id);
      setDeleting(false);
    }
    setDeleteTarget(null);
  }}
  battlefieldName={deleteTarget?.name}
  deleting={deleting} // ← Ось так!
/>
<BlockUserFromBattlefieldModal
  open={!!blockTarget}
  onClose={() => { setBlockModalOpen(false); setBlockTarget(null); }}
  onBlock={async () => {
    if (blockTarget?.id) {
      await blockUser(blockTarget.id);
    }
  }}
  userName={blockTarget?.name}
/>
<EditBattlefieldModal
  open={editModalOpen}
  onClose={() => setEditModalOpen(false)}
  battlefield={battlefieldToEdit}
  onEdit={() => {
    setEditModalOpen(false);
    setBattlefieldToEdit(null);
    fetchBattlefields(); // Щоб оновити список після редагування (реалізуєш пізніше)
  }}
/>
<LeaveBattlefieldConfirmModal
  open={leaveModalOpen}
  battlefield={leaveTarget}
  onLeave={() => leaveBattlefield(leaveTarget?.id)}
  onCancel={() => { setLeaveModalOpen(false); setLeaveTarget(null); }}
  leaving={leaving}
/>


</>
  );
}
