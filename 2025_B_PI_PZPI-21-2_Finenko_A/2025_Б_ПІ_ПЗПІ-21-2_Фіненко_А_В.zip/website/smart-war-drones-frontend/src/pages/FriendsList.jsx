import { useEffect, useState, useRef } from "react";
import { fetchWithAuth } from "../utils/tokenManager";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import BlockUserModal from "../components/BlockUserModal";

export default function FriendsList({ searchQuery = "" }) {
  const [friends, setFriends] = useState([]);
  const [loading, setLoading] = useState(true);
  

  // Remove friend
  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [removeUserId, setRemoveUserId] = useState(null);
  const [removing, setRemoving] = useState(false);
  const removeModalRef = useRef();

  // Block user
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [blockUserId, setBlockUserId] = useState(null);

  const filteredFriends = searchQuery
  ? friends.filter(f =>
      (f.name || "")
        .toLowerCase()
        .includes(searchQuery.toLowerCase())
    )
  : friends;

  useEffect(() => {
    friends.forEach(async (friend, idx) => {
      if (friend.avatarType === "custom" && !friend.avatarUrl && friend.id) {
        try {
          const token = localStorage.getItem("jwt");
          const fileRes = await fetch(`/api/profile/avatar-file/${friend.id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (!fileRes.ok) throw new Error("Cannot get avatar file");
          const fileBuffer = await fileRes.arrayBuffer();
  
          const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
          const rsaKeyBase64 = await rsaKeyRes.text();
          const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
          const sessionAesKey = generateRandomBytes(16);
          const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
          const encryptor = new JSEncrypt();
          encryptor.setPublicKey(rsaKeyPem);
          const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);
  
          const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${friend.id}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ encryptedSessionAesKey }),
          });
          const { iv, ciphertext } = await resp.json();
  
          const keyBytes = sessionAesKey;
          const ivWord = CryptoJS.enc.Base64.parse(iv);
          const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
            iv: ivWord,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          });
  
          const avatarAesKeyBytes = Uint8Array.from(
            decrypted.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decrypted.sigBytes)
          );
  
          const fileBytes = new Uint8Array(fileBuffer);
          const fileIv = fileBytes.slice(0, 16);
          const fileCipher = fileBytes.slice(16);
  
          const decWord = CryptoJS.AES.decrypt(
            { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
            CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
            {
              iv: CryptoJS.lib.WordArray.create(fileIv),
              mode: CryptoJS.mode.CBC,
              padding: CryptoJS.pad.Pkcs7,
            }
          );
  
          const uint8Decrypted = Uint8Array.from(
            decWord.words.flatMap(w => [
              (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
            ]).slice(0, decWord.sigBytes)
          );
  
          const blob = new Blob([uint8Decrypted], { type: "image/png" });
          const url = URL.createObjectURL(blob);
  
          setFriends(prev =>
            prev.map((f, i) => i === idx ? { ...f, avatarUrl: url } : f)
          );
        } catch (err) {
          console.error("❌ Failed to fetch/decrypt custom avatar (friend):", err);
        }
      }
    });
    // eslint-disable-next-line
  }, [friends.length]);

  useEffect(() => { loadFriends(); }, []);

  async function loadFriends() {
    setLoading(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/friends", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setFriends(data);
      setLoading(false);
    } catch (err) {
      console.error("❌ Failed to load friends", err);
      setLoading(false);
    }
  }

  function getFirstTwoLines(text) {
    if (!text) return "";
    const lines = text.split('\n');
    if (lines.length <= 2) return text;
    return lines.slice(0, 2).join('\n') + '…';
  }

  async function handleRemoveFriend(userId) {
    setRemoving(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);

      const payload = { userId };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      await fetchWithAuth("/api/contacts/remove-friend", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });

      setShowRemoveModal(false);
      setRemoveUserId(null);
      loadFriends();
    } catch (err) {
      alert("Failed to remove friend: " + err?.message);
    }
    setRemoving(false);
  }

  if (loading) return <div className="loading-text">Loading friends...</div>;
  if (!filteredFriends || filteredFriends.length === 0) return <div className="empty-text">No users found</div>;

  return (
    <div className="requests-list">
      {filteredFriends.map((friend, idx) => (
        <div key={friend.id} className="request-item">
          <img
            src={
              friend.avatarType === "custom"
                ? (friend.avatarUrl || "/avatars/avatar1.png")
                : (friend.avatarUrl || "/avatars/avatar1.png")
            }
            alt="avatar"
            className="avatar-preview"
          />
          <div className="info">
            <div className="name">{friend.name}</div>
            <div className="role">{friend.role}</div>
            <div className="bio">{getFirstTwoLines(friend.bio)}</div>
          </div>
          <div className="actions">
            <button
              className="icon-action-btn"
              title="Remove friend"
              onClick={() => {
                setRemoveUserId(friend.id);
                setShowRemoveModal(true);
              }}
            >
              <img src="/icons/rejectIcon.png" alt="Remove friend" />
            </button>
            <button
              className="icon-action-btn"
              title="Block user"
              onClick={() => {
                setBlockUserId(friend.id);
                setShowBlockModal(true);
              }}
            >
              <img src="/icons/blockUserIcon.png" alt="Block user" />
            </button>
          </div>
        </div>
      ))}

      {showRemoveModal && (
        <div className="confirm-modal">
          <div className="confirm-box" ref={removeModalRef}>
            <p>Do you want to remove the friend?</p>
            <div className="confirm-actions">
              <button
                style={{ background: "#e16171" }}
                disabled={removing}
                onClick={() => handleRemoveFriend(removeUserId)}
              >
                Remove
              </button>
              <button
                style={{ background: "#293750" }}
                disabled={removing}
                onClick={() => {
                  setShowRemoveModal(false);
                  setRemoveUserId(null);
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <BlockUserModal
        open={showBlockModal}
        userId={blockUserId}
        onBlock={loadFriends}
        onClose={() => {
          setShowBlockModal(false);
          setBlockUserId(null);
        }}
      />
    </div>
  );
}
