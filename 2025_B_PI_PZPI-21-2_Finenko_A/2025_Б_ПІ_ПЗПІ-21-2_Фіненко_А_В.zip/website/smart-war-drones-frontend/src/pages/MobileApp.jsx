import PageWrapper from "../components/PageWrapper";
import "../styles/pages/_mobileApp.scss";

export default function MobileApp() {
  return (
    <PageWrapper>
      <div className="mobile-app-container">
        <h1>Mobile App</h1>
      </div>
    </PageWrapper>
  );
}
