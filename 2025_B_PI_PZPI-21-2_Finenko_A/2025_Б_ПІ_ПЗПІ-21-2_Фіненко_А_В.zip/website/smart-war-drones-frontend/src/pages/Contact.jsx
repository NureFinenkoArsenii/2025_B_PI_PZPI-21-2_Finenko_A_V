import { useState, useEffect } from "react";
import PageWrapper from "../components/PageWrapper";
import "../styles/pages/_contact.scss";
import {
  generateRandomBytes,
  encryptDataAES,
  encryptAESKeyWithRSA,
} from "../utils/crypto";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [rsaPublicKey, setRsaPublicKey] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const [response, setResponse] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5189/api/contact/public-key")
      .then((res) => res.text())
      .then((base64) => {
        const formattedPem = formatToPEM(base64);
        setRsaPublicKey(formattedPem);
      })
      .catch(console.error);
  }, []);

  function formatToPEM(base64) {
    const lines = base64.match(/.{1,64}/g).join("\n");
    return `-----BEGIN PUBLIC KEY-----\n${lines}\n-----END PUBLIC KEY-----`;
  }

  const isEmailValid = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  const isFormValid =
    formData.name.trim() &&
    isEmailValid(formData.email) &&
    formData.subject.trim() &&
    formData.message.trim();

  const isFormDirty =
    formData.name || formData.email || formData.subject || formData.message;

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleClear = () =>
    setFormData({ name: "", email: "", subject: "", message: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid || isSending || !rsaPublicKey) return;

    setIsSending(true);
    setResponse(null);

    try {
      const aesKey = generateRandomBytes(16); // 128-біт AES ключ
      const iv = generateRandomBytes(16);     // 128-біт IV

      const encrypted = encryptDataAES(formData, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA(aesKey, rsaPublicKey);

      if (!encryptedKey) {
        setResponse({ type: "error", message: "RSA encryption failed." });
        return;
      }

      const payload = {
        encryptedKey,
        iv: encrypted.iv,
        ciphertext: encrypted.ciphertext,
      };

      const res = await fetch("http://localhost:5189/api/contact/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setResponse({ type: "success", message: "Message sent successfully!" });
        handleClear();
      } else {
        const errText = await res.text();
        setResponse({ type: "error", message: errText || "Unexpected error." });
      }
    } catch (err) {
      setResponse({ type: "error", message: "Encryption or server error." });
      console.error(err);
    } finally {
      setIsSending(false);
    }
  };

  useEffect(() => {
    if (response) {
      const timer = setTimeout(() => setResponse(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [response]);

  return (
    <PageWrapper>
      <div className="contact-container">
        <h1>Get in Touch</h1>
        <form onSubmit={handleSubmit} className="contact-form">
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            className="input-name"
          />
          <div className="email-wrapper">
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              className="input-email"
            />
            <span
              className={`email-feedback ${
                formData.email
                  ? isEmailValid(formData.email)
                    ? "valid"
                    : "invalid"
                  : ""
              }`}
            >
              {formData.email &&
                (isEmailValid(formData.email)
                  ? "Valid email"
                  : "Invalid email format")}
            </span>
          </div>
          <input
            type="text"
            name="subject"
            placeholder="Subject"
            value={formData.subject}
            onChange={handleChange}
            className="input-subject"
          />
          <textarea
            name="message"
            placeholder="Your Message"
            rows="6"
            value={formData.message}
            onChange={handleChange}
          ></textarea>
          <div className="form-actions">
            <div className="action-left">
              <button type="submit" disabled={!isFormValid || isSending}>
                {isSending ? "Sending..." : "Send"}
              </button>
              {response && (
                <div className={`form-response-inline ${response.type}`}>
                  {response.message}
                </div>
              )}
            </div>
            <span
              className={`clear-all ${isFormDirty ? "active" : ""}`}
              onClick={isFormDirty ? handleClear : undefined}
            >
              Clear All
            </span>
          </div>
        </form>
      </div>
    </PageWrapper>
  );
}
