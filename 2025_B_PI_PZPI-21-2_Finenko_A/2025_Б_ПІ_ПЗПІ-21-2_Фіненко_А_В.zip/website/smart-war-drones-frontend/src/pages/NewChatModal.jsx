import { useEffect, useRef, useState } from "react";
import ReactDOM from "react-dom";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import { fetchWithAuth } from "../utils/tokenManager";
import MessageConfirmModal from "../components/MessageConfirmModal"; // Додай цей імпорт!
import "../styles/pages/_messages.scss";


const IDENTIFIER_LENGTH = 6;

export default function NewChatModal({ open, onClose, onStartChat }) {
  const [identifier, setIdentifier] = useState("");
  const [foundUser, setFoundUser] = useState(null);
  const [customAvatarUrl, setCustomAvatarUrl] = useState(null);
  const [status, setStatus] = useState("idle");
  const [searchQuery, setSearchQuery] = useState("");
  const [friends, setFriends] = useState([]);
  const [friendsAvatars, setFriendsAvatars] = useState({});
  const [loadingFriends, setLoadingFriends] = useState(true);
  const modalRef = useRef();
  const [blockedList, setBlockedList] = useState([]);

  // --- Додаємо state для модалки підтвердження ---
  const [showMessageConfirmModal, setShowMessageConfirmModal] = useState(false);
  const [selectedUserForChat, setSelectedUserForChat] = useState(null);

  async function startChatWithUser(user) {
    // 1. Отримуємо публічний RSA ключ
    const pubKeyBase64 = await fetchWithAuth("/api/messages/public-key").then(r => r.text());
    const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
    // 2. Генеруємо AES-ключ і IV
    const aesKey = generateRandomBytes(16);
    const iv = generateRandomBytes(16);
  
    // 3. Шифруємо AES-ключ RSA-ключем
    const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
  
    // 4. Готуємо payload
    const payload = { friendId: user.id };
    const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
  
    // 5. Відправляємо запит на новий endpoint
    const resp = await fetchWithAuth("/api/messages/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
    });
    if (!resp.ok) {
      alert("Failed to start or open chat.");
      return null;
    }
    const respJson = await resp.json();
  
    // 6. Дешифруємо відповідь
    const respIv = CryptoJS.enc.Base64.parse(respJson.iv);
    const key = bytesToWordArray(aesKey);
    const decrypted = CryptoJS.AES.decrypt(respJson.ciphertext, key, {
      iv: respIv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    const chatInfo = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
    return chatInfo;
  }
  
  
  async function handleMessageConfirm() {
  setShowMessageConfirmModal(false);
  onClose && onClose();

  if (onStartChat && selectedUserForChat) {
    // Тут іде запит на сервер і передача результату у MessagesView
    const chatData = await startChatWithUser(selectedUserForChat);
    if (chatData) {
      console.log("[NewChatModal] onStartChat will send:", chatData);
      onStartChat(chatData); // тільки chatData!
    }
  }
}

  // ---- CODE BELOW = не змінюється ----
  async function loadBlocked() {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/blocked", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const blocked = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
      setBlockedList(blocked.map(b => String(b.id)));
    } catch (err) {
      setBlockedList([]);
    }
  }

  useEffect(() => {
    if (!open) return;
    setIdentifier("");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setStatus("idle");
    setSearchQuery("");
    setFriendsAvatars({});
    loadFriends();
    loadBlocked();
  }, [open]);

  useEffect(() => {
    if (!open || showMessageConfirmModal) return; // <--- додаємо showMessageConfirmModal
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open, showMessageConfirmModal, onClose]);

  async function handleFindUser(identifier) {
    setStatus("loading");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const payload = { identifier };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/find", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
      });
      if (!resp.ok) {
        setStatus("error");
        setFoundUser(null);
        setCustomAvatarUrl(null);
        return;
      }

      const respText = await resp.text();
      let data;
      try { data = JSON.parse(respText); } catch (e) { setStatus("error"); return; }
      const ivData = CryptoJS.enc.Base64.parse(data.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(data.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      let user;
      try { user = JSON.parse(jsonStr); } catch (e) { setStatus("error"); return; }
      if (user.youAreBlocked) {
        setStatus("found");
        setFoundUser(user);
        setCustomAvatarUrl(null);
        return;
      }
      setStatus("found");
      setFoundUser(user);

      if (user.avatarType === "custom" && !user.avatarUrl) {
        fetchAndDecryptCustomAvatar(user.id, setCustomAvatarUrl);
      }
    } catch {
      setStatus("error");
      setCustomAvatarUrl(null);
    }
  }

  async function loadFriends() {
    setLoadingFriends(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/friends", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setFriends(data);
      setLoadingFriends(false);

      data.forEach(f => {
        if (f.avatarType === "custom" && !f.avatarUrl && f.id) {
          fetchAndDecryptCustomAvatar(f.id, url =>
            setFriendsAvatars(prev => ({ ...prev, [f.id]: url }))
          );
        }
      });
    } catch (err) {
      setFriends([]);
      setLoadingFriends(false);
    }
  }

  async function fetchAndDecryptCustomAvatar(userId, cb) {
    try {
      const token = localStorage.getItem("jwt");
      const fileRes = await fetch(`/api/profile/avatar-file/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!fileRes.ok) throw new Error("Cannot get avatar file");
      const fileBuffer = await fileRes.arrayBuffer();

      const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
      const rsaKeyBase64 = await rsaKeyRes.text();
      const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const sessionAesKey = generateRandomBytes(16);
      const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(rsaKeyPem);
      const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

      const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedSessionAesKey }),
      });
      const { iv, ciphertext } = await resp.json();

      const keyBytes = sessionAesKey;
      const ivWord = CryptoJS.enc.Base64.parse(iv);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
        iv: ivWord,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const avatarAesKeyBytes = Uint8Array.from(
        decrypted.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decrypted.sigBytes)
      );

      const fileBytes = new Uint8Array(fileBuffer);
      const fileIv = fileBytes.slice(0, 16);
      const fileCipher = fileBytes.slice(16);

      const decWord = CryptoJS.AES.decrypt(
        { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
        CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
        {
          iv: CryptoJS.lib.WordArray.create(fileIv),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );

      const uint8Decrypted = Uint8Array.from(
        decWord.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decWord.sigBytes)
      );

      const blob = new Blob([uint8Decrypted], { type: "image/png" });
      const url = URL.createObjectURL(blob);

      cb(url);
    } catch (err) {
      cb(null);
    }
  }

  useEffect(() => {
    if (foundUser && foundUser.avatarType === "custom" && !foundUser.avatarUrl) {
      fetchAndDecryptCustomAvatar(foundUser.id, setCustomAvatarUrl);
    }
  }, [foundUser && foundUser.id, foundUser && foundUser.avatarType]);

  const filteredFriends = searchQuery.length > 0
    ? friends.filter(f => (f.name || "").toLowerCase().includes(searchQuery.toLowerCase()))
    : friends;

  function handleIdentifierChange(e) {
    let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, IDENTIFIER_LENGTH);
    setIdentifier(v);
    setStatus("idle");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    if (v.length === IDENTIFIER_LENGTH) handleFindUser(v);
  }

  function handleCancelSearch() {
    setIdentifier("");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setStatus("idle");
  }

  const activeKey = status === "found" && foundUser ? "found" : "default";

  // --- HANDLERS for open modal (for user found or for friend) ---
  function handleStartChatWithUser(user) {
    setSelectedUserForChat(user);
    setShowMessageConfirmModal(true);
  }

  return ReactDOM.createPortal(
    <>
    <div className="contacts-overlay">
      <div className="contacts-modal new-chat-modal-form" ref={modalRef}>
        <button className="close-btn-contacts" onClick={onClose}>×</button>
        <div className="contacts-header">
        <img src="/icons/messageIcon.png" alt="Contacts" className="contacts-header-icon" />
        <span>Start New Chat</span>
        </div>
        <hr className="divider" />
        <AnimatedHeightWrapper activeKey={activeKey}>
          <div className="new-chat-modal-inner">
            {/* Input IDENTIFIER */}
            <div className="input-title">Input friend's identifier here</div>
            <div className={`identifier-input-wrapper${status === "error" ? " error" : ""}`}>
              <input
                className="contacts-search-input"
                maxLength={IDENTIFIER_LENGTH}
                style={{ fontSize: "2.0rem", letterSpacing: "0.19em" }}
                placeholder="ABC123"
                value={identifier}
                onChange={handleIdentifierChange}
                disabled={status === "found"}
              />
            </div>
            {/* Status/Error */}
            {status === "loading" && <div className="loading-text">Searching...</div>}
            {status === "error" && <div className="error-text">User not found</div>}

            {status === "found" && foundUser && (
            <div className="found-user-block">
                <div className="found-user">
                <img
                    src={foundUser.avatarType === "custom"
                    ? (customAvatarUrl || "/avatars/avatar1.png")
                    : (foundUser.avatarUrl || "/avatars/avatar1.png")}
                    alt="avatar"
                    className="avatar-preview"
                />
                <div className="user-info">
                    <div className="found-name">{foundUser.name}</div>
                    <div className="found-role">{foundUser.role}</div>
                    <div className="found-bio">{foundUser.bio}</div>
                </div>
                {/* Кнопки і статуси - тільки якщо не заблокований */}
                {!foundUser.youAreBlocked && (
                    blockedList.includes(String(foundUser.id)) ? (
                    <div className="self-info blocked" style={{ color: "#ff5555", background: "#251819", marginTop: 12 }}>
                        Blocked
                    </div>
                    ) : (
                    <div className="action-icons-row">
                        <img
                          src="/icons/messageIcon.png"
                          className="icon-btn"
                          alt="msg"
                          onClick={() => handleStartChatWithUser({
                            ...foundUser,
                            avatarUrl: foundUser.avatarType === "custom"
                              ? (customAvatarUrl || "/avatars/avatar1.png")
                              : (foundUser.avatarUrl || "/avatars/avatar1.png"),
                          })}
                        />
                    </div>
                    )
                )}
                </div>
                <button
                className="contacts-cancel-btn"
                type="button"
                style={{ marginTop: 20 }}
                onClick={handleCancelSearch}
                >
                Cancel
                </button>
            </div>
            )}

            {/* Friends list, якщо не знайдено юзера */}
            {!(status === "found" && foundUser) && (
              <>
                <hr className="divider" />
                <div className="input-title" style={{ marginBottom: 8, textAlign: "center" }}>Friends:</div>
                <div className="requests-list" style={{ maxHeight: 170 }}>
                  {loadingFriends
                    ? <div className="loading-text">Loading friends...</div>
                    : filteredFriends.length === 0
                      ? <div className="empty-text">You have no friends yet.</div>
                      : filteredFriends.map(friend => (
                        <div key={friend.id} className="request-item friend-card">
                          <img
                            src={
                              friend.avatarType === "custom"
                                ? (friendsAvatars[friend.id] || "/avatars/avatar1.png")
                                : (friend.avatarUrl || "/avatars/avatar1.png")
                            }
                            alt="avatar"
                            className={
                              "avatar-preview" +
                              (blockedList.includes(String(friend.id)) ? " blocked" : "")
                            }
                          />
                          <div className="info">
                            <div className="name">{friend.name}</div>
                            <div className="role">{friend.role}</div>
                          </div>
                          <div className="actions">
                            <button
                              className="icon-action-btn"
                              title="Start chat"
                              onClick={() => handleStartChatWithUser({
                                ...friend,
                                avatarUrl: friend.avatarType === "custom"
                                  ? (friendsAvatars[friend.id] || "/avatars/avatar1.png")
                                  : (friend.avatarUrl || "/avatars/avatar1.png"),
                              })}
                            >
                              <img src="/icons/messageIcon.png" alt="Message" />
                            </button>
                          </div>
                        </div>
                      ))}
                </div>
                <input
                  className="contacts-search-input"
                  type="text"
                  placeholder="Find friend"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
                {searchQuery.length > 0 && (
                <div className="centered-cancel-btn">
                    <button
                    className="contacts-cancel-btn"
                    type="button"
                    onClick={() => setSearchQuery("")}
                    >
                    Cancel
                    </button>
                </div>
                )}
              </>
            )}
          </div>
        </AnimatedHeightWrapper>
      </div>
    </div>
    <MessageConfirmModal
      open={showMessageConfirmModal}
      user={selectedUserForChat}
      onConfirm={handleMessageConfirm}
      onCancel={() => setShowMessageConfirmModal(false)}
    />
    </>,
    document.getElementById("modal-root")
  );
}
