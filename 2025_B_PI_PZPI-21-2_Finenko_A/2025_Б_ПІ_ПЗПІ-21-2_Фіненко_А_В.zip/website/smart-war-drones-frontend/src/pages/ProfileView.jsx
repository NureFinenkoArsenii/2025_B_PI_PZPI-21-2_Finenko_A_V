import { useEffect, useState, useRef } from "react";
import { getUserIdFromToken, fetchWithAuth } from "../utils/tokenManager";
import "../styles/pages/_profile.scss";
import {
  generateRandomBytes,
  encryptJsonWithAES_forPassword,
  encryptAESKeyWithRSA_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import { motion } from "framer-motion";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import AvatarSelector from "../components/AvatarSelector";
import JSEncrypt from 'jsencrypt';
import CryptoJS from "crypto-js";

export default function ProfileView({ onBack, onAvatarChanged }) {
  const [profile, setProfile] = useState(null);
  const [bio, setBio] = useState("");
  const [originalBio, setOriginalBio] = useState("");
  const [loading, setLoading] = useState(true);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [identifierChanged, setIdentifierChanged] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [showAvatarForm, setShowAvatarForm] = useState(false);
  const isLoadingProfile = useRef(false);
  const modalRef = useRef(null);
  const previousIdentifier = useRef("");
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [passwordData, setPasswordData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [changeResponse, setChangeResponse] = useState(null);
  const bioUpdateInProgress = useRef(false);

  // Helper
  function formatToPEM(base64) {
    return `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  }

  const handleAvatarClick = async () => {
    if (showAvatarForm) {
      // Якщо форма аватарки відкрита, то закрити її і відновити профіль
      await maybeUpdateBio();  // Збереження біо перед зміною секцій
      setShowAvatarForm(false);
    } else {
      // Якщо форма аватарки закрита, то відкрити її та приховати решту секцій
      setShowAvatarForm(true);
      setShowPasswordForm(false);
    }
  };

  const handleChangePasswordClick = async () => {
    // Збережемо опис, якщо він був змінений
    if (bio !== originalBio) {
      await maybeUpdateBio(); // Зберігаємо біо перед зміною паролю
    }
  
    // Тепер переключимо видимість форми для зміни паролю
    setShowPasswordForm((prev) => !prev);
    setShowAvatarForm(false); // Приховуємо форму аватара, якщо вона відкрита
    setChangeResponse(null); // Очищаємо попередні відповіді
    setPasswordData({ oldPassword: "", newPassword: "", confirmPassword: "" });
  };

  // LOAD PROFILE (unchanged, but with avatarType)
  async function loadProfile() {
    const userId = getUserIdFromToken();
    if (!userId) return;

    try {
      const publicKeyBase64 = await fetchWithAuth("/api/profile/public-key").then(res => {
        if (!res.ok) throw new Error("Failed to get public key");
        return res.text();
      });
      const publicKeyPem = formatToPEM(publicKeyBase64);

      const aesKey = generateRandomBytes(16);
      const aesKeyBase64 = btoa(String.fromCharCode(...aesKey));
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(publicKeyPem);
      const encryptedAesKey = encryptor.encrypt(aesKeyBase64);
      if (!encryptedAesKey) throw new Error("RSA encryption of AES key failed");

      const resProfile = await fetchWithAuth(`/api/profile/${userId}`, {
        method: "GET",
        headers: {
          "X-Client-AES-Key": encryptedAesKey,
        },
      });

      if (!resProfile.ok) {
        const errText = await resProfile.text();
        throw new Error(`Server error: ${errText}`);
      }

      // Тут повертається рядок json, парсимо двічі
      let encryptedProfile;
      try {
        const raw = await resProfile.text();
        encryptedProfile = JSON.parse(raw);
      } catch {
        encryptedProfile = await resProfile.json();
      }

      const iv = CryptoJS.enc.Base64.parse(encryptedProfile.Iv);
      const ciphertext = encryptedProfile.Ciphertext;

      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, key, {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      if (!jsonStr) throw new Error("AES decryption failed");

      const parsed = JSON.parse(jsonStr);

      setProfile(parsed);
      setAvatarUrl(parsed.avatarUrl);
      try {
        const bioObj = JSON.parse(parsed.bio || '{}');
        setBio(bioObj.bio || '');
        setOriginalBio(bioObj.bio || '');
      } catch {
        setBio(parsed.bio || '');
        setOriginalBio(parsed.bio || '');
      }
      previousIdentifier.current = parsed.identifier;

      // Таймер ідентифікатора
      const lastUpdate = new Date(parsed.lastIdentifierUpdate).getTime();
      updateCountdown(lastUpdate);
      const interval = setInterval(() => updateCountdown(lastUpdate), 1000);
      return () => clearInterval(interval);
    } catch (err) {
      console.error("❌ Failed to load profile:", err);
    } finally {
      setLoading(false);
    }
  }

  // Декодування кастомної аватарки (protected-avatars)
  useEffect(() => {
    if (!profile) return;
    if (profile.avatarType !== "custom") return;

    (async () => {
      try {
        const token = localStorage.getItem("jwt");
        // 1. Забираємо файл-аватарку
        const fileRes = await fetch(`/api/profile/avatar-file/${getUserIdFromToken()}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!fileRes.ok) throw new Error("Cannot get avatar file");
        const fileBuffer = await fileRes.arrayBuffer();

        // 2. Отримуємо публічний RSA для avatar-image
        const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
        const rsaKeyBase64 = await rsaKeyRes.text();
        const rsaKeyPem = formatToPEM(rsaKeyBase64);

        // 3. Генеруємо session AES ключ
        const sessionAesKey = generateRandomBytes(16);
        const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
        const encryptor = new JSEncrypt();
        encryptor.setPublicKey(rsaKeyPem);
        const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

        // 4. Отримуємо AES-ключ для аватарок (по ланцюгу)
        const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${getUserIdFromToken()}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedSessionAesKey }),
        });
        const { iv, ciphertext } = await resp.json();

        // 5. Декодуємо AES-ключ для protected-avatars
        const keyBytes = sessionAesKey;
        const ivWord = CryptoJS.enc.Base64.parse(iv);
        const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
          iv: ivWord,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });

        // отримати справжні байти ключа
        const avatarAesKeyBytes = Uint8Array.from(
          decrypted.words.flatMap(w => [
            (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
          ]).slice(0, decrypted.sigBytes)
        );

        // 6. Дешифруємо файл-аватарку: файл = IV(16) + encrypted
        const fileBytes = new Uint8Array(fileBuffer);
        const fileIv = fileBytes.slice(0, 16);
        const fileCipher = fileBytes.slice(16);

        const decWord = CryptoJS.AES.decrypt(
          { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
          CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
          {
            iv: CryptoJS.lib.WordArray.create(fileIv),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          }
        );
        const uint8Decrypted = Uint8Array.from(
          decWord.words.flatMap(w => [
            (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
          ]).slice(0, decWord.sigBytes)
        );
        const blob = new Blob([uint8Decrypted], { type: "image/png" });
        const url = URL.createObjectURL(blob);
        setAvatarUrl(url);
      } catch (err) {
        console.error("❌ Failed to fetch/decrypt custom avatar:", err);
        setAvatarUrl(""); // fallback
      }
    })();
  }, [profile]);

  useEffect(() => {
    loadProfile();
  }, []);
  
  async function handleChangePassword() {
    const { oldPassword, newPassword, confirmPassword } = passwordData;
    if (!oldPassword || !newPassword || !confirmPassword) {
      setChangeResponse("❌ Please fill all fields.");
      return;
    }

    try {
      const res = await fetchWithAuth(
        "/api/profile/public-key/change-password"
      );
      const base64 = await res.text();
      if (!base64 || !base64.match) {
        setChangeResponse("❌ Invalid public key from server.");
        return;
      }

      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64
        .match(/.{1,64}/g)
        .join("\n")}\n-----END PUBLIC KEY-----`;

      const payload = { oldPassword, newPassword, confirmPassword };
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(
        payload,
        aesKey,
        iv
      );
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

      if (!encryptedKey) {
        setChangeResponse("❌ RSA encryption failed.");
        return;
      }

      const message = { encryptedKey, iv: ivBase64, ciphertext };

      const response = await fetchWithAuth(
        "/api/profile/change-password",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(message),
        }
      );

      if (response.ok) {
        setChangeResponse("✅ Password changed successfully.");
        setPasswordData({ oldPassword: "", newPassword: "", confirmPassword: "" });
        setTimeout(() => {
          setShowPasswordForm(false);
          setChangeResponse(null);
        }, 3000);
      } else {
        const text = await response.text();
        setChangeResponse(`❌ ${text}`);
      }
    } catch (err) {
      console.error(err);
      setChangeResponse("❌ Encryption or server error.");
    }
  }

  async function reloadProfile() {
    if (isLoadingProfile.current) return;
    isLoadingProfile.current = true;

    try {
      const userId = getUserIdFromToken();
      if (!userId) return;

      // Отримуємо публічний ключ
      const publicKeyBase64 = await fetchWithAuth("/api/profile/public-key").then(res => {
        if (!res.ok) throw new Error("Failed to get public key");
        return res.text();
      });
      const publicKeyPem = formatToPEM(publicKeyBase64);

      // Генеруємо AES ключ
      const aesKey = generateRandomBytes(16);
      const aesKeyBase64 = btoa(String.fromCharCode(...aesKey));

      // Шифруємо AES ключ
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(publicKeyPem);
      const encryptedAesKey = encryptor.encrypt(aesKeyBase64);
      if (!encryptedAesKey) throw new Error("RSA encryption failed");

      // Запит профілю
      const resProfile = await fetchWithAuth(`/api/profile/${userId}`, {
        method: "GET",
        headers: { "X-Client-AES-Key": encryptedAesKey },
      });

      if (!resProfile.ok) {
        const errText = await resProfile.text();
        throw new Error(`Server error: ${errText}`);
      }

      const encryptedProfile = await resProfile.json();

      const iv = CryptoJS.enc.Base64.parse(encryptedProfile.Iv);
      const ciphertext = encryptedProfile.Ciphertext;

      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, key, {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      if (!jsonStr) throw new Error("AES decryption failed");

      const parsed = JSON.parse(jsonStr);

      if (parsed.identifier !== previousIdentifier.current) {
        setIdentifierChanged(true);
        setTimeout(() => setIdentifierChanged(false), 600);
        previousIdentifier.current = parsed.identifier;
      }

      setProfile(parsed);
      setAvatarUrl(parsed.avatarUrl);
      try {
        const bioObj = JSON.parse(parsed.bio || '{}');
        setBio(bioObj.bio || '');
        setOriginalBio(bioObj.bio || '');
      } catch {
        // Якщо парсинг не вдався, ставимо як є (рядок)
        setBio(parsed.bio || '');
        setOriginalBio(parsed.bio || '');
      }
    } catch (err) {
      console.error("❌ Failed to reload profile:", err);
    } finally {
      isLoadingProfile.current = false;
    }
  }

  async function updateCountdown(lastUpdate) {
    const now = Date.now();
    const secondsSince = Math.floor((now - lastUpdate) / 1000);
    const remaining = 300 - (secondsSince % 300);
    setSecondsLeft(remaining);
  
    if (remaining === 5) {
      await maybeUpdateBio();
    }
  
    if (remaining === 300) {
      await new Promise((resolve) => setTimeout(resolve, 300)); // дати час БД оновитись
      await reloadProfile();
    }
  }

  useEffect(() => {
    const handleClickOutside = async (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        await maybeUpdateBio();
        onBack();
      }
    };
    window.addEventListener("beforeunload", maybeUpdateBio);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("beforeunload", maybeUpdateBio);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [bio]);

  async function maybeUpdateBio() {
    if (bio === originalBio) return; 

    try {
      bioUpdateInProgress.current = true;

      const res = await fetchWithAuth("/api/profile/public-key/update-bio");
      const base64 = await res.text();
      const publicKeyPem = `-----BEGIN PUBLIC KEY-----\n${base64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      // Логування перед шифруванням

      const payload = { bio };
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

      const message = { encryptedKey, iv: ivBase64, ciphertext };

      // Логування після шифрування

      await fetchWithAuth("/api/profile/update-bio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message),
      });

      setOriginalBio(bio); 
    } catch (err) {
      console.error("❌ Failed to update bio:", err);
    } finally {
      bioUpdateInProgress.current = false;
    }
  }
  
  async function handleAvatarSelection(src) {
    try {
      // Якщо src — шлях з public avatars (default), як раніше
      if (!src.startsWith("/protected-avatars/")) {
        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword({ path: src }, aesKey, iv);

        const res = await fetchWithAuth("/api/profile/public-key/upload-avatar");
        const publicKeyPem = formatToPEM(await res.text());
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

        const message = { encryptedKey, iv: ivBase64, ciphertext };

        const uploadRes = await fetchWithAuth("/api/profile/upload-avatar-encrypted", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(message),
        });

        if (uploadRes.ok) {
          await reloadProfile();
          setShowAvatarForm(false);
          if (onAvatarChanged) onAvatarChanged();
        }
        return;
      }

      // Якщо src — шлях до protected-avatars (кастомна аватарка)
      // (Ми отримали шлях з upload-avatar-file, тож тепер треба його зашифрувати і на сервер)
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword({ path: src }, aesKey, iv);

      const res = await fetchWithAuth("/api/profile/public-key/upload-avatar");
      const publicKeyPem = formatToPEM(await res.text());
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, publicKeyPem);

      const message = { encryptedKey, iv: ivBase64, ciphertext };

      const uploadRes = await fetchWithAuth("/api/profile/upload-avatar-encrypted", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message),
      });

      if (uploadRes.ok) {
        await reloadProfile();
        setShowAvatarForm(false);
        // викликаємо оновлення аватарки в navbar
        if (onAvatarChanged) onAvatarChanged();
      }
    } catch (err) {
      console.error("❌ Failed to update avatar:", err);
    }
  }

  async function handleUploadCustom(blob) {
    try {
      const formData = new FormData();
      formData.append("file", blob, "avatar.png");
      const token = localStorage.getItem("jwt");
      const res = await fetch("/api/profile/upload-avatar-file", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      if (!res.ok) {
        alert("Failed to upload avatar file");
        return;
      }
      const { avatarUrl } = await res.json();
      await handleAvatarSelection(avatarUrl);
    } catch (err) {
      console.error("❌ Failed to upload custom avatar file:", err);
    }
    if (onAvatarChanged) onAvatarChanged();
  }

  const handleBioChange = (e) => setBio(e.target.value);
  const remainingChars = bio.length;
  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${minutes}:${seconds.toString().padStart(2, "0")}`;

  if (loading) {
    return (
      <div className="profile-overlay">
        <div className="profile-modal">Loading profile...</div>
      </div>
    );
  }

  const isOperator = profile?.role?.toLowerCase() === "operator";
  const isOfficer = profile?.role?.toLowerCase() === "officer";


  return (
    <div className="profile-overlay">
      <motion.div
        className="profile-modal"
        ref={modalRef}
        layout
        transition={{ layout: { duration: 0.4, ease: "easeInOut" } }}
      >
        <button className="close-btn" onClick={onBack}>×</button>

        <div className="profile-section profile-top">
          <div
            className="avatar-container"
            onClick={handleAvatarClick}
          >
            <img className="avatar" src={avatarUrl} alt="Avatar" />
          </div>
          <div className="username">{profile.name}</div>
          {isOperator && <span className="role-badge operator">operator</span>}
          {isOfficer && <span className="role-badge officer">officer</span>}
        </div>

        <hr className="divider" />

        <AnimatedHeightWrapper activeKey={
          showPasswordForm ? "form" :
            showAvatarForm ? "avatar" :
              "bio"
        }>
          {showPasswordForm ? (
            <div className="profile-section">
              <div className="password-form">
                <input type="password" name="oldPassword" placeholder="Old Password"
                  value={passwordData.oldPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, [e.target.name]: e.target.value })}
                />
                <input type="password" name="newPassword" placeholder="New Password"
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, [e.target.name]: e.target.value })}
                />
                <input type="password" name="confirmPassword" placeholder="Repeat New Password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, [e.target.name]: e.target.value })}
                />
                <div className="form-actions">
                  <button onClick={handleChangePassword}>Submit</button>
                  <button
                    onClick={() => {
                      setShowPasswordForm(false);
                      setChangeResponse(null);
                      setPasswordData({ oldPassword: "", newPassword: "", confirmPassword: "" });
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          ) : showAvatarForm ? (
            <div className="profile-section">
              <AvatarSelector
                selected={avatarUrl}
                onSelect={handleAvatarSelection}
                onUploadCustom={handleUploadCustom}
              />
            </div>
          ) : (
            <>
              <div className="profile-section">
                <div className="identifier-label">Identifier for friends</div>
                <div className={`identifier-boxes ${identifierChanged ? "fade-in" : ""}`}>
                  {profile.identifier.split("").map((char, idx) => (
                    <span key={idx} className="id-char">{char}</span>
                  ))}
                </div>
                <div className="identifier-timer">
                  ⏱ Next update in <strong>{formattedTime}</strong>
                </div>
              </div>

              <hr className="divider" />

              <div className="profile-section">
                <div className="bio-label">Bio</div>
                <textarea
                  className="bio-textarea"
                  placeholder="Write here anything you want."
                  value={bio}
                  onChange={handleBioChange}
                  maxLength={100}
                />
                <div className="char-count">{remainingChars}/100</div>
              </div>

              <hr className="divider" />
            </>
          )}
        </AnimatedHeightWrapper>

        {!showAvatarForm && (
          <AnimatedHeightWrapper activeKey={`${showPasswordForm}-${changeResponse}`}>
            <div className="profile-section">
              <button
                className="change-password-btn"
                onClick={handleChangePasswordClick}
              >
                <img src="/icons/changePasswordIcon.png" alt="Change" className="change-icon" />
                Change Password
              </button>
              {changeResponse && (
                <div className="form-response-wrapper">
                  <div
                    className={`form-response ${changeResponse.startsWith("✅") ? "success" : "error"
                      }`}
                  >
                    {changeResponse}
                  </div>
                </div>
              )}
            </div>
          </AnimatedHeightWrapper>
        )}
      </motion.div>
    </div>
  );
}
