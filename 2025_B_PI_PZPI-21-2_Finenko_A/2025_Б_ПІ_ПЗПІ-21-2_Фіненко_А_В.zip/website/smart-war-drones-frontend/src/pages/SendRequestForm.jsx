import { useState, useRef, useEffect } from "react";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import JSEncrypt from 'jsencrypt';
import CryptoJS from "crypto-js";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword
} from "../utils/passwordCrypto";
import "../styles/pages/_sendRequestForm.scss";
import { fetchWithAuth, getUserIdFromToken } from "../utils/tokenManager";
import BlockUserModal from "../components/BlockUserModal";

const IDENTIFIER_LENGTH = 6;

function toIdentifierFormat(str) {
  return str.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, IDENTIFIER_LENGTH);
}

function aesKeyToCryptoJSWordArray(aesKeyBytes) {
    const base64Key = btoa(String.fromCharCode(...aesKeyBytes));
    return CryptoJS.enc.Base64.parse(base64Key);
}

export default function SendRequestForm({ onBack }) {
  const [value, setValue] = useState("");
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const inputRef = useRef();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [sendingStatus, setSendingStatus] = useState("idle");
  const [sendError, setSendError] = useState("");
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [friendsList, setFriendsList] = useState([]);
  const [blockedList, setBlockedList] = useState([]);
  const [customAvatarUrl, setCustomAvatarUrl] = useState(null);

  useEffect(() => {
    console.log('[DEBUG] friendsList:', friendsList, 'blockedList:', blockedList, 'result.id:', result?.id);
  }, [friendsList, blockedList, result?.id]);

  useEffect(() => {
    loadFriendsAndBlocked();
  }, []);

  async function loadFriendsAndBlocked() {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      // Friends
      const friendsResp = await fetchWithAuth("/api/contacts/friends", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const friendsResult = await friendsResp.json();
      const ivDataF = CryptoJS.enc.Base64.parse(friendsResult.iv);
      const keyF = bytesToWordArray(aesKey);
      const decryptedF = CryptoJS.AES.decrypt(friendsResult.ciphertext, keyF, {
        iv: ivDataF,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const friends = JSON.parse(decryptedF.toString(CryptoJS.enc.Utf8));
      console.log('[API] Friends raw response:', friends);
      setFriendsList(friends.map(f => String(f.id)));

      // Blocked
      const aesKeyB = generateRandomBytes(16);
      const ivB = generateRandomBytes(16);
      const encryptedKeyB = encryptAESKeyWithRSA_forPassword(aesKeyB, pubKeyPem);
      const { ciphertext: ciphertextB, iv: ivBase64B } = encryptJsonWithAES_forPassword(dummyPayload, aesKeyB, ivB);
      const blockedResp = await fetchWithAuth("/api/contacts/blocked", {
        method: "POST",
        body: JSON.stringify({ encryptedKey: encryptedKeyB, iv: ivBase64B, ciphertext: ciphertextB })
      });
      const blockedResult = await blockedResp.json();
      const ivDataB = CryptoJS.enc.Base64.parse(blockedResult.iv);
      const keyB = bytesToWordArray(aesKeyB);
      const decryptedB = CryptoJS.AES.decrypt(blockedResult.ciphertext, keyB, {
        iv: ivDataB,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const blocked = JSON.parse(decryptedB.toString(CryptoJS.enc.Utf8));
      console.log('[API] Blocked raw response:', blocked);
      setBlockedList(blocked.map(b => String(b.id)));
    } catch (e) {
      console.error('[API] Failed to load friends/blocked:', e);
      setFriendsList([]);
      setBlockedList([]);
    }
  }

  useEffect(() => {
    if (!result || result.avatarType !== "custom") {
      setCustomAvatarUrl(null);
      return;
    }
    (async () => {
      try {
        const token = localStorage.getItem("jwt");
        const fileRes = await fetch(`/api/profile/avatar-file/${result.id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!fileRes.ok) throw new Error("Cannot get avatar file");
        const fileBuffer = await fileRes.arrayBuffer();
  
        const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
        const rsaKeyBase64 = await rsaKeyRes.text();
        const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
        const sessionAesKey = generateRandomBytes(16);
        const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
        const encryptor = new JSEncrypt();
        encryptor.setPublicKey(rsaKeyPem);
        const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);
  
        const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${result.id}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedSessionAesKey }),
        });
        const { iv, ciphertext } = await resp.json();
  
        const keyBytes = sessionAesKey;
        const ivWord = CryptoJS.enc.Base64.parse(iv);
        const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
          iv: ivWord,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
  
        const avatarAesKeyBytes = Uint8Array.from(
          decrypted.words.flatMap(w => [
            (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
          ]).slice(0, decrypted.sigBytes)
        );
  
        const fileBytes = new Uint8Array(fileBuffer);
        const fileIv = fileBytes.slice(0, 16);
        const fileCipher = fileBytes.slice(16);
  
        const decWord = CryptoJS.AES.decrypt(
          { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
          CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
          {
            iv: CryptoJS.lib.WordArray.create(fileIv),
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
          }
        );
  
        const uint8Decrypted = Uint8Array.from(
          decWord.words.flatMap(w => [
            (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
          ]).slice(0, decWord.sigBytes)
        );
  
        const blob = new Blob([uint8Decrypted], { type: "image/png" });
        const url = URL.createObjectURL(blob);
  
        setCustomAvatarUrl(url);
      } catch (err) {
        setCustomAvatarUrl(null);
        console.error("❌ Failed to fetch/decrypt custom avatar:", err);
      }
    })();
  }, [result && result.id, result && result.avatarType]);

  const handleChange = (e) => {
    let v = toIdentifierFormat(e.target.value);
    setValue(v);
    setError("");
    setStatus("idle");
    if (v.length === IDENTIFIER_LENGTH) {
      handleFindUser(v);
    }
  };

  async function handleSendRequest() {
    try {
      setSendingStatus("sending");
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const encryptedAesKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      if (!encryptedAesKey) throw new Error("Failed to encrypt AES key");
      const iv = generateRandomBytes(16);
      const payload = { userId: result.id };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          encryptedKey: encryptedAesKey,
          iv: ivBase64,
          ciphertext,
        }),
      });

      if (!resp.ok) {
        const msg = await resp.text();
        throw new Error(msg);
      }

      setSendingStatus("success");
      setTimeout(() => {
        setShowConfirmModal(false);
        setSendingStatus("idle");
      }, 2000);
    } catch (err) {
      setSendingStatus("error");
      setSendError(err.message || "Unknown error");
    }
  }

  async function handleFindUser(identifier) {
    setStatus("loading");
    setError("");
    setResult(null);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const encryptedAesKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      if (!encryptedAesKey) throw new Error("RSA encryption failed");
      const iv = generateRandomBytes(16);
      const payload = { identifier };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/find", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey: encryptedAesKey, iv: ivBase64, ciphertext }),
      });

      if (!resp.ok) {
        setStatus("error");
        setError("Wrong identifier");
        setTimeout(() => {
          setValue("");
          setError("");
          setStatus("idle");
        }, 900);
        return;
      }

      const respText = await resp.text();
      let data;
      try { data = JSON.parse(respText); } catch (e) {
        setError("Backend response error");
        setStatus("error");
        return;
      }
      const ivData = CryptoJS.enc.Base64.parse(data.iv);
      const key = aesKeyToCryptoJSWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(data.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      let user;
      try { user = JSON.parse(jsonStr); } catch (e) {
        setStatus("error");
        setError("Decrypt error");
        return;
      }
        if (user.youAreBlocked) {
          console.log('Current user is in blocked list of found user');
          setResult(user);
          setStatus("found");
          setCustomAvatarUrl(null);
          return;
        }

      setResult(user);
      setStatus("found");
    } catch (err) {
      setStatus("error");
      setError("Wrong identifier");
      setTimeout(() => {
        setValue("");
        setError("");
        setStatus("idle");
      }, 1000);
    }
  }

  return (
    <AnimatedHeightWrapper activeKey={status + (result ? "_result" : "")}>
      <div className="send-request-form">
        <div className="input-title">Input friend's identifier here</div>
        <div className={`identifier-input-wrapper ${status === "error" ? "error" : ""}`}>
          <input
            ref={inputRef}
            autoFocus
            maxLength={IDENTIFIER_LENGTH}
            value={value}
            onChange={handleChange}
            placeholder="ABC123"
            inputMode="text"
            style={{ textTransform: "uppercase", letterSpacing: "0.18em" }}
            disabled={status === "loading" || status === "found"}
          />
        </div>

        {status === "error" && <div className="error-text">Wrong identifier</div>}
        {status === "loading" && <div className="loading-text">Searching...</div>}

        {status === "found" && result && (
         <div className={`found-user${blockedList.includes(String(result.id)) ? " blocked" : ""}`}>
           <img
              className={
                "avatar-preview" +
                (blockedList.includes(String(result.id)) ? " blocked" : "")
              }
              src={result.avatarType === "custom" ? customAvatarUrl : (result.avatarUrl || "/avatars/avatar1.png")}
              alt="avatar"
            />

            <div className="user-info">
              <div className="found-name">{result.name}</div>
              <div className="found-role">{result.role}</div>
              <div className="found-bio">{result.bio}</div>
            </div>
            {showConfirmModal && (
              <div
                className="confirm-modal"
                onClick={(e) => {
                  if (e.target.classList.contains("confirm-modal")) {
                    setShowConfirmModal(false);
                    setSendingStatus("idle");
                    setSendError("");
                  }
                }}
              >
                <div className="confirm-box">
                  <p>Do you want to send friend request to <strong>{result.name}</strong>?</p>
                  {sendingStatus === "idle" && (
                    <div className="confirm-actions">
                      <button onClick={handleSendRequest}>Yes</button>
                      <button onClick={() => setShowConfirmModal(false)}>Cancel</button>
                    </div>
                  )}
                  {sendingStatus === "sending" && <p>Sending request...</p>}
                  {sendingStatus === "success" && (
                    <p className="confirm-success">Friend request sent!</p>
                  )}
                  {sendingStatus === "error" && (
                    <>
                      <p className="confirm-error">
                        {sendError === "Request already exists." ? (
                          "Request already exists."
                        ) : (
                          `Failed to send: ${sendError}`
                        )}
                      </p>
                      <button
                        className="retry-btn"
                        onClick={() => {
                          setSendingStatus("idle");
                          setSendError("");
                          setShowConfirmModal(
                            sendError === "Request already exists." ? false : true
                          );
                        }}
                      >
                        {sendError === "Request already exists." ? "Ok" : "Try again"}
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
            {!result.youAreBlocked && (
            getUserIdFromToken() === String(result.id) ? (
              <div className="self-info">It is you</div>
            ) : blockedList.includes(String(result.id)) ? (
              <div className="self-info blocked" style={{ color: "#ff5555", background: "#251819" }}>Blocked</div>
            ) : friendsList.includes(String(result.id)) ? (
              <div className="self-info friend" style={{ color: "#00e0d1", background: "#1a2929" }}>Friend</div>
            ) : (
              <div className="action-icons-row">
                <img
                  src="/icons/addFriendIcon.png"
                  className="icon-btn"
                  alt="add"
                  onClick={() => setShowConfirmModal(true)}
                />
                <img
                  src="/icons/blockUserIcon.png"
                  className="icon-btn"
                  alt="block"
                  onClick={() => setShowBlockModal(true)}
                />
              </div>
            )
          )}
        </div>
      )}
        <div style={{ marginTop: 16 }}>
          <button className="cancel-btn" onClick={onBack}>Cancel</button>
        </div>
      </div>
      <BlockUserModal
        open={showBlockModal}
        userId={result && result.id}
        onBlock={() => {
          setResult(null);
          loadFriendsAndBlocked(); // <--- Додати для оновлення списків
        }}
        onClose={() => setShowBlockModal(false)}
      />
    </AnimatedHeightWrapper>
  );
}

function bytesToWordArray(bytes) {
  return CryptoJS.lib.WordArray.create(bytes);
}
