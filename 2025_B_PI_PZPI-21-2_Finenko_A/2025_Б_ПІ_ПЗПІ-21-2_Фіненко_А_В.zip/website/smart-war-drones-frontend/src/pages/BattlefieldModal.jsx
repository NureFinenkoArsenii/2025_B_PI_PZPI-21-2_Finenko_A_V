import React, { useRef, useEffect, useState, useCallback } from "react";
import ReactDOM from "react-dom";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import ChooseFocusAndScale from "../battlefields/ChooseFocusAndScale";
import "../styles/pages/_battlefieldModal.scss";
import CryptoJS from "crypto-js";
import JSEncrypt from "jsencrypt";
import {
  generateRandomBytes,
  encryptAESKeyWithRSA_forPassword,
  encryptJsonWithAES_forPassword,
  bytesToWordArray,
} from "../utils/passwordCrypto";
import { fetchWithAuth } from "../utils/tokenManager";

const getLayerName = (url) => {
  if (!url) return "";
  if (url.includes("openstreetmap")) return "OpenStreetMap";
  if (url.includes("stadiamaps")) return "Stadia";
  if (url.includes("cartocdn")) return "CartoDBVoyager";
  if (url.includes("dark-v10")) return "MapboxDark";
  if (url.includes("satellite-streets-v11")) return "MapboxSatellite";
  if (url.includes("traffic-day-v2")) return "MapboxTraffic";
  return url.slice(0, 32) + "...";
};

const IDENTIFIER_LENGTH = 6;

export default function BattlefieldModal({ open, onClose, onCreated }) {
  const modalRef = useRef(null);
  const [mode, setMode] = useState("setting"); // "setting" | "focus" | "addmembers"
  const [name, setName] = useState("");
  const [about, setAbout] = useState("");
  const [showMapModal, setShowMapModal] = useState(false);
  const [focusInfo, setFocusInfo] = useState(null);

  // --- Add Members State ---
  const [identifier, setIdentifier] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | found | error
  const [foundUser, setFoundUser] = useState(null);
  const [customAvatarUrl, setCustomAvatarUrl] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [friends, setFriends] = useState([]);
  const [friendsAvatars, setFriendsAvatars] = useState({});
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [blockedList, setBlockedList] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]); // айді для запиту на приєднання

  // --- Закриття по кліку поза модалкою та Esc
  const handleClickOutside = useCallback(
    (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    },
    [onClose]
  );

  const handleEsc = useCallback(
    (e) => {
      if (e.key === "Escape") onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (focusInfo) {
      console.log("focusInfo after choose:", focusInfo);
    }
  }, [focusInfo]);
  

  // --- Скидання всіх станів при закритті модалки
  useEffect(() => {
    if (!open) {
      setMode("setting");
      setName("");
      setAbout("");
      setShowMapModal(false);
      setFocusInfo(null);

      setIdentifier("");
      setStatus("idle");
      setFoundUser(null);
      setCustomAvatarUrl(null);
      setSearchQuery("");
      setFriends([]);
      setFriendsAvatars({});
      setLoadingFriends(false);
      setBlockedList([]);
      setSelectedIds([]); // очищення вибраних
    }
  }, [open]);

  // --- Універсальна зміна режиму з очисткою полів
  const handleSetMode = (newMode) => {
    setMode(newMode);
    setIdentifier("");
    setStatus("idle");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setSearchQuery("");
  };

  // --- Додаємо та видаляємо евенти для закриття по кліку/esc
  useEffect(() => {
    if (!open) return;
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [handleClickOutside, handleEsc, open]);

  // --- Завантаження друзів і blocked
  useEffect(() => {
    if (mode !== "addmembers" || !open) return;
    loadFriends();
    loadBlocked();
  }, [mode, open]);

  function fileToArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  }
  

  // --- Завантаження кастом-аватарки знайденого користувача
  useEffect(() => {
    if (foundUser && foundUser.avatarType === "custom" && !foundUser.avatarUrl) {
      fetchAndDecryptCustomAvatar(foundUser.id, setCustomAvatarUrl);
    }
  }, [foundUser && foundUser.id, foundUser && foundUser.avatarType]);

  // --- Пошук користувача за ідентифікатором
  const handleIdentifierChange = async (e) => {
    let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, IDENTIFIER_LENGTH);
    setIdentifier(v);
    setStatus("idle");
    setFoundUser(null);
    setCustomAvatarUrl(null);

    if (v.length === IDENTIFIER_LENGTH) {
      setStatus("loading");
      try {
        const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
        const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

        const aesKey = generateRandomBytes(16);
        const iv = generateRandomBytes(16);
        const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
        const payload = { identifier: v };
        const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(payload, aesKey, iv);

        const resp = await fetchWithAuth("/api/contacts/find", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext }),
        });
        if (!resp.ok) {
          setStatus("error");
          setFoundUser(null);
          setCustomAvatarUrl(null);
          return;
        }

        const respText = await resp.text();
        let data;
        try { data = JSON.parse(respText); } catch (e) { setStatus("error"); return; }
        const ivData = CryptoJS.enc.Base64.parse(data.iv);
        const key = bytesToWordArray(aesKey);
        const decrypted = CryptoJS.AES.decrypt(data.ciphertext, key, {
          iv: ivData,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        });
        const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
        let user;
        try { user = JSON.parse(jsonStr); } catch (e) { setStatus("error"); return; }

        setStatus("found");
        setFoundUser(user);

        // Аватар завантажуємо окремо
        if (user.avatarType === "custom" && !user.avatarUrl) {
          fetchAndDecryptCustomAvatar(user.id, setCustomAvatarUrl);
        }
      } catch {
        setStatus("error");
        setCustomAvatarUrl(null);
      }
    }
  };

  const handleCancelSearch = () => {
    setIdentifier("");
    setFoundUser(null);
    setCustomAvatarUrl(null);
    setStatus("idle");
  };

  const filteredFriends = searchQuery.length > 0
    ? friends.filter(f => (f.name || "").toLowerCase().includes(searchQuery.toLowerCase()))
    : friends;

  // --- Додаємо/знімаємо обраного користувача ---
  const toggleSelected = (id) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // --- Завантаження аватарки друга (якщо кастом)
  async function fetchAndDecryptCustomAvatar(userId, cb) {
    try {
      const token = localStorage.getItem("jwt");
      const fileRes = await fetch(`/api/profile/avatar-file/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!fileRes.ok) throw new Error("Cannot get avatar file");
      const fileBuffer = await fileRes.arrayBuffer();

      const rsaKeyRes = await fetchWithAuth("/api/profile/public-key/avatar-image");
      const rsaKeyBase64 = await rsaKeyRes.text();
      const rsaKeyPem = `-----BEGIN PUBLIC KEY-----\n${rsaKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;

      const sessionAesKey = generateRandomBytes(16);
      const sessionAesKeyBase64 = btoa(String.fromCharCode(...sessionAesKey));
      const encryptor = new JSEncrypt();
      encryptor.setPublicKey(rsaKeyPem);
      const encryptedSessionAesKey = encryptor.encrypt(sessionAesKeyBase64);

      const resp = await fetchWithAuth(`/api/profile/get-avatar-image-key/${userId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedSessionAesKey }),
      });
      const { iv, ciphertext } = await resp.json();

      const keyBytes = sessionAesKey;
      const ivWord = CryptoJS.enc.Base64.parse(iv);
      const decrypted = CryptoJS.AES.decrypt(ciphertext, CryptoJS.lib.WordArray.create(keyBytes), {
        iv: ivWord,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      const avatarAesKeyBytes = Uint8Array.from(
        decrypted.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decrypted.sigBytes)
      );

      const fileBytes = new Uint8Array(fileBuffer);
      const fileIv = fileBytes.slice(0, 16);
      const fileCipher = fileBytes.slice(16);

      const decWord = CryptoJS.AES.decrypt(
        { ciphertext: CryptoJS.lib.WordArray.create(fileCipher) },
        CryptoJS.lib.WordArray.create(avatarAesKeyBytes),
        {
          iv: CryptoJS.lib.WordArray.create(fileIv),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );

      const uint8Decrypted = Uint8Array.from(
        decWord.words.flatMap(w => [
          (w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF
        ]).slice(0, decWord.sigBytes)
      );

      const blob = new Blob([uint8Decrypted], { type: "image/png" });
      const url = URL.createObjectURL(blob);

      cb(url);
    } catch (err) {
      cb(null);
    }
  }

  async function loadFriends() {
    setLoadingFriends(true);
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/friends", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const jsonStr = decrypted.toString(CryptoJS.enc.Utf8);
      const data = JSON.parse(jsonStr);
      setFriends(data);
      setLoadingFriends(false);

      data.forEach(f => {
        if (f.avatarType === "custom" && !f.avatarUrl && f.id) {
          fetchAndDecryptCustomAvatar(f.id, url =>
            setFriendsAvatars(prev => ({ ...prev, [f.id]: url }))
          );
        }
      });
    } catch (err) {
      setFriends([]);
      setLoadingFriends(false);
    }
  }

  async function loadBlocked() {
    try {
      const pubKeyBase64 = await fetchWithAuth("/api/contacts/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
      const aesKey = generateRandomBytes(16);
      const iv = generateRandomBytes(16);
      const encryptedKey = encryptAESKeyWithRSA_forPassword(aesKey, pubKeyPem);
      const dummyPayload = { dummy: true };
      const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dummyPayload, aesKey, iv);

      const resp = await fetchWithAuth("/api/contacts/blocked", {
        method: "POST",
        body: JSON.stringify({ encryptedKey, iv: ivBase64, ciphertext })
      });
      const result = await resp.json();
      const ivData = CryptoJS.enc.Base64.parse(result.iv);
      const key = bytesToWordArray(aesKey);
      const decrypted = CryptoJS.AES.decrypt(result.ciphertext, key, {
        iv: ivData,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      const blocked = JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
      setBlockedList(blocked.map(b => String(b.id)));
    } catch (err) {
      setBlockedList([]);
    }
  }

  function encryptArrayBufferWithAES(buffer, keyBytes, ivBytes) {
    // Перетворити ArrayBuffer -> WordArray
    const wordArray = CryptoJS.lib.WordArray.create(buffer);
  
    // Зашифрувати
    const encrypted = CryptoJS.AES.encrypt(wordArray, CryptoJS.lib.WordArray.create(keyBytes), {
      iv: CryptoJS.lib.WordArray.create(ivBytes),
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    // Отримати base64-строку, декодувати у Uint8Array
    const base64 = encrypted.ciphertext.toString(CryptoJS.enc.Base64);
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; ++i) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  async function handleSetBattlefield() {
    // --- Валідація ім'я
    if (!name.trim()) {
      alert("No name! Please set battlefield name.");
      return;
    }
  
    // --- Збираємо DTO з дефолтами
    const dto = {
      Name: name,
      About: about || "",
      MapFocus: focusInfo?.center ? JSON.stringify(focusInfo.center) : "[48.3794,31.1656]",
      MapSize: focusInfo?.zoom?.toString() || "6",
      MapStyle: focusInfo?.tileLayer || "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      MapAvatarUrl: "", // (заповнимо далі, якщо НЕ файл)
      DronesIds: [],
    };
  
    // --- Аватарка (файл або шлях)
    let previewFile = null;
    let avatarUrl = "";
  
    if (focusInfo && focusInfo.croppedFile) {
        previewFile = focusInfo.croppedFile;
      } else {
        avatarUrl = "/battlefieldPreview/defaultBattlefieldPreview.png";
        dto.MapAvatarUrl = avatarUrl;
      }
  
    // --- Шифрування DTO сесійним AES (як і завжди)
    const battlefieldPubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
    const battlefieldPubKeyPem = `-----BEGIN PUBLIC KEY-----\n${battlefieldPubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
    const sessionAesKey = generateRandomBytes(16);
    const sessionIv = generateRandomBytes(16);
    const encryptedKey = encryptAESKeyWithRSA_forPassword(sessionAesKey, battlefieldPubKeyPem);
  
    const { ciphertext, iv: ivBase64 } = encryptJsonWithAES_forPassword(dto, sessionAesKey, sessionIv);
  
    // --- Готуємо FormData
    const formData = new FormData();
    formData.append("encrypted", JSON.stringify({
        EncryptedKey: encryptedKey,
        Iv: ivBase64,
        Ciphertext: ciphertext,
      }));
      
  
      if (previewFile) {
        const arrayBuffer = await fileToArrayBuffer(previewFile);
      
        // Зашифруй перед відправкою!
        const encryptedBuffer = encryptArrayBufferWithAES(
          arrayBuffer,
          sessionAesKey,
          sessionIv
        );
      
        // Blob (типу .png, це ок)
        formData.append("preview", new Blob([encryptedBuffer]), previewFile.name);
      }
      
      
    // Якщо ні - сервер візьме шлях із MapAvatarUrl
    console.log("Battlefield: encrypted payload", {
        encryptedKey,
        iv: ivBase64,
        ciphertext,
        previewFile,
        dto,
      });
      
    // --- Відправляємо
    const resp = await fetchWithAuth("/api/battlefields/add", {
        method: "POST",
        body: formData,
      });
      
      if (!resp.ok) {
        const errText = await resp.text(); // <--- покажи що відповідає сервер!
        alert("Failed to create battlefield\n" + errText); // Або вивести в консоль
        return;
      }
  
    // --- Розшифровуємо повернуте encryptedId
    const respData = await resp.json();
    const { encryptedId } = respData;
    if (!encryptedId) {
      alert("Server did not return battlefield ID.");
      return;
    }
  
    // --- Дешифруємо id напрямку сесійним AES та IV
    const decryptedId = (() => {
      const cipherWord = CryptoJS.enc.Base64.parse(encryptedId);
      const keyWord = bytesToWordArray(sessionAesKey);
      const ivWord = bytesToWordArray(sessionIv);
      const decrypted = CryptoJS.AES.decrypt(
        { ciphertext: cipherWord },
        keyWord,
        { iv: ivWord, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
      );
      return decrypted.toString(CryptoJS.enc.Utf8);
    })();
  
    // --- Якщо є selectedIds, шлемо заявки
    if (selectedIds.length > 0) {
      const pubKeyBase64 = await fetchWithAuth("/api/battlefields/public-key").then(r => r.text());
      const pubKeyPem = `-----BEGIN PUBLIC KEY-----\n${pubKeyBase64.match(/.{1,64}/g).join("\n")}\n-----END PUBLIC KEY-----`;
  
      const sessionAesKeyReq = generateRandomBytes(16);
      const sessionIvReq = generateRandomBytes(16);
      const encryptedKeyReq = encryptAESKeyWithRSA_forPassword(sessionAesKeyReq, pubKeyPem);
  
      const payload = {
        battlefieldId: decryptedId,
        receivers: selectedIds,
      };
      const { ciphertext: ciph, iv: ivb64 } = encryptJsonWithAES_forPassword(payload, sessionAesKeyReq, sessionIvReq);
  
      await fetchWithAuth("/api/battlefields/add-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ encryptedKey: encryptedKeyReq, iv: ivb64, ciphertext: ciph }),
      });
    }
  
    // --- Закриваємо модалку
    if (onCreated) onCreated(); // це оновить список і закриє модалку у батьківському компоненті
    else onClose();
  }
  

  // --- Render ---
  if (!open) return null;

  return ReactDOM.createPortal(
    <div className="battlefield-overlay">
      <div className="battlefield-modal" ref={modalRef} tabIndex={-1}>
        <button className="close-btn" onClick={onClose}>×</button>
        <AnimatedHeightWrapper activeKey={mode}>
          {/* HEADER */}
          <div className="battlefield-header-row" style={{ marginBottom: 14 }}>
            <img
              src="/icons/battlefieldsIcon.png"
              alt="battlefield icon"
              className="battlefield-header-icon"
            />
            <div className="battlefield-header" style={{ fontSize: "1.5rem" }}>
              {mode === "setting" && "Setting the Battlefield"}
              {mode === "focus" && "Focusing and Scaling"}
              {mode === "addmembers" && "Send Request to Join In"}
            </div>
          </div>
          <hr className="divider" />

          {/* --- SETTING --- */}
          {mode === "setting" && (
            <div className="battlefield-section">
              <input
                type="text"
                className="battlefield-input"
                placeholder="Name your battlefield"
                value={name}
                onChange={e => setName(e.target.value)}
                autoFocus
                maxLength={36}
                style={{ marginBottom: 12 }}
              />
              <textarea
                className="battlefield-textarea"
                placeholder="Purpose of the battlefield (About)"
                value={about}
                onChange={e => setAbout(e.target.value)}
                rows={3}
              />
              <hr className="divider" />
              <button
                className="battlefield-add-btn"
                type="button"
                style={{ fontWeight: 600, fontSize: "1.08rem" }}
                onClick={() => handleSetMode("focus")}
              >
                <img src="/icons/mapIcon.png" alt="Map" className="battlefield-btn-icon" />
                Map Focus and Scale
              </button>
              <hr className="divider" />
              <button
                className="battlefield-add-btn battlefield-addmembers-btn"
                type="button"
                style={{ fontWeight: 600, fontSize: "1.08rem" }}
                onClick={() => handleSetMode("addmembers")}
              >
                <img src="/icons/contactsIcon.png" alt="Add Members" className="battlefield-btn-icon" />
                Add Members
              </button>
              <hr className="divider" />
              <div className="battlefield-actions-row">
              <button
                className="battlefield-add-btn battlefield-primary-btn"
                style={{ width: "100%" }}
                onClick={handleSetBattlefield}
                >
                Set the Battlefield
                </button>
              </div>
            </div>
          )}

          {/* --- FOCUS --- */}
          {mode === "focus" && (
            <div className="battlefield-section">
              <div className="battlefield-explanation" style={{ marginBottom: 18, color: "#eee", fontSize: "1.14rem", fontWeight: 500 }}>
                Choose typical position on the map when the battlefield opened:
              </div>
              <button
                className="battlefield-add-btn"
                type="button"
                style={{ width: "60%", fontWeight: 600, fontSize: "1.08rem", marginBottom: 16 }}
                onClick={() => setShowMapModal(true)}
              >
                <img src="/icons/mapIcon.png" alt="Map" className="battlefield-btn-icons" />
                Choose on the map
              </button>
              <div className="battlefield-avatar-tip" style={{
                fontSize: "0.96rem",
                color: "#80fff0",
                fontStyle: "italic",
                marginBottom: 16,
                textAlign: "center",
              }}>
                An avatar for the battlefield will be selected automatically*
              </div>
              {focusInfo && (
                <>
                  <hr className="divider" />
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 16 }}>
                    <img
                      src={focusInfo.previewUrl}
                      alt="Battlefield Avatar"
                      style={{
                        width: 116,
                        height: 116,
                        objectFit: "cover",
                        borderRadius: 18,
                        marginBottom: 14,
                        border: "3px solid #313741",
                        boxShadow: "0 2px 16px #000b",
                        background: "#252b33"
                      }}
                    />
                    <div style={{ color: "#90f3e6", marginBottom: 4, fontSize: "0.98rem" }}>
                    <b>Coordinates: </b>
                    {focusInfo.center && Array.isArray(focusInfo.center)
                    ? `${Number(focusInfo.center[0]).toFixed(5)}, ${Number(focusInfo.center[1]).toFixed(5)}`
                    : '—'}
                    </div>
                    <div style={{ color: "#d0edff", marginBottom: 4, fontSize: "0.98rem" }}>
                      <b>Zoom:</b> {focusInfo.zoom}
                    </div>
                    <div style={{ color: "#ffd590", fontSize: "0.98rem" }}>
                      <b>Map style:</b> {getLayerName(focusInfo.tileLayer)}
                    </div>
                  </div>
                </>
              )}
              <button
                className="battlefield-add-btn battlefield-back-btn"
                type="button"
                style={{
                  width: "100%",
                  background: "#232932",
                  color: "#fff",
                  fontWeight: 600,
                  fontSize: "1.02rem",
                  marginTop: 24
                }}
                onClick={() => handleSetMode("setting")}
              >
                Back to Setting
              </button>
            </div>
          )}

          {/* --- ADD MEMBERS --- */}
          {mode === "addmembers" && (
            <div className="battlefield-section battlefield-addmembers-section">
              <div className="input-title" style={{ marginBottom: 8 }}>Find future member by identifier:</div>
              <div className={`identifier-input-wrapper${status === "error" ? " error" : ""}`}>
                <input
                  className="battlefield-contacts-search-input"
                  maxLength={IDENTIFIER_LENGTH}
                  style={{ fontSize: "2.0rem", letterSpacing: "0.19em" }}
                  placeholder="ABC123"
                  value={identifier}
                  onChange={handleIdentifierChange}
                  disabled={status === "found"}
                />
              </div>
              {status === "loading" && <div className="loading-text">Searching...</div>}
              {status === "error" && <div className="error-text">User not found</div>}
              {status === "found" && foundUser && (
                <div className="found-user-block">
                  <div className="found-user">
                    <img
                      src={foundUser.avatarType === "custom"
                        ? (customAvatarUrl || "/avatars/avatar1.png")
                        : (foundUser.avatarUrl || "/avatars/avatar1.png")}
                      alt="avatar"
                      className="avatar-preview"
                    />
                    <div className="user-info">
                      <div className="found-name">{foundUser.name}</div>
                      <div className="found-role">{foundUser.role}</div>
                      {/* bio */}
                    </div>
                    {/* Лейба Blocked або кнопка надсилання запиту */}
                    {!foundUser.youAreBlocked ? (
                      blockedList.includes(String(foundUser.id)) ? (
                        <div className="self-info blocked" style={{
                          color: "#ff5555",
                          background: "#251819",
                          marginTop: 12,
                          borderRadius: 9,
                          fontWeight: 600,
                          padding: "4px 16px"
                        }}>
                          Blocked
                        </div>
                      ) : (
                        <div className="action-icons-row">
                          <img
                            src={
                              selectedIds.includes(foundUser.id)
                                ? "/icons/acceptIcon.png"
                                : "/icons/addMemberIcon.png"
                            }
                            className="icon-btn"
                            alt={
                              selectedIds.includes(foundUser.id)
                                ? "Selected"
                                : "Send request"
                            }
                            title={
                              selectedIds.includes(foundUser.id)
                                ? "Remove from selection"
                                : "Send request to join"
                            }
                            style={
                              selectedIds.includes(foundUser.id)
                                ? {
                                    border: "2.2px solid #4ff495",
                                    borderRadius: "50%",
                                    background: "#262",
                                    padding: 2,
                                    filter: "none",
                                    cursor: "pointer"
                                  }
                                : {
                                    filter: "invert(48%) sepia(86%) saturate(2287%) hue-rotate(136deg) brightness(99%) contrast(101%)",
                                    cursor: "pointer"
                                  }
                            }
                            onClick={() => toggleSelected(foundUser.id)}
                          />
                        </div>
                      )
                    ) : null}
                  </div>
                  <button
                    className="contacts-cancel-btn"
                    type="button"
                    style={{ marginTop: 20 }}
                    onClick={handleCancelSearch}
                  >
                    Cancel
                  </button>
                </div>
              )}
              {!(status === "found" && foundUser) && (
                <>
                  <hr className="divider" />
                  <div className="input-title" style={{ marginBottom: 8, textAlign: "center" }}>Send requests to your friends:</div>
                  <input
                    className="battlefield-contacts-search-input"
                    type="text"
                    placeholder="Find friend"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    style={{ marginBottom: 10, marginTop: 0 }}
                  />
                  {searchQuery.length > 0 && (
                    <div className="centered-cancel-btn">
                      <button
                        className="contacts-cancel-btn"
                        type="button"
                        onClick={() => setSearchQuery("")}
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                  <div className="requests-list" style={{ maxHeight: 170 }}>
                    {loadingFriends
                      ? <div className="loading-text">Loading friends...</div>
                      : filteredFriends.length === 0
                        ? <div className="empty-text">You have no friends yet.</div>
                        : filteredFriends
                          .filter(friend => friend && friend.id && friend.name && friend.role)
                          .map(friend => (
                            <div key={friend.id} className="request-item friend-card">
                              <img
                                src={
                                  friend.avatarType === "custom"
                                    ? (friendsAvatars[friend.id] || "/avatars/avatar1.png")
                                    : (friend.avatarUrl || "/avatars/avatar1.png")
                                }
                                alt="avatar"
                                className="avatar-preview"
                              />
                              <div className="info">
                                <div className="name">{friend.name}</div>
                                <div className="role">{friend.role}</div>
                              </div>
                              <div className="actions">
                                {blockedList.includes(String(friend.id)) ? (
                                  <span className="self-info blocked" style={{
                                    color: "#ff5555",
                                    background: "#251819",
                                    borderRadius: 9,
                                    fontWeight: 600,
                                    padding: "4px 10px"
                                  }}>
                                    Blocked
                                  </span>
                                ) : (
                                  <button
                                    className="icon-action-btn"
                                    title={
                                      selectedIds.includes(friend.id)
                                        ? "Remove from selection"
                                        : "Send Request"
                                    }
                                    style={{
                                      background: "none",
                                      border: "none",
                                      cursor: "pointer"
                                    }}
                                    onClick={() => toggleSelected(friend.id)}
                                  >
                                    <img
                                      src={
                                        selectedIds.includes(friend.id)
                                          ? "/icons/acceptIcon.png"
                                          : "/icons/addMemberIcon.png"
                                      }
                                      alt={
                                        selectedIds.includes(friend.id)
                                          ? "Selected"
                                          : "Add member"
                                      }
                                      style={
                                        selectedIds.includes(friend.id)
                                          ? {
                                              border: "2.2px solid #4ff495",
                                              borderRadius: "50%",
                                              background: "#262",
                                              padding: 2,
                                              filter: "none"
                                            }
                                          : {
                                              filter: "invert(48%) sepia(86%) saturate(2287%) hue-rotate(136deg) brightness(99%) contrast(101%)"
                                            }
                                      }
                                    />
                                  </button>
                                )}
                              </div>
                            </div>
                          ))
                    }
                  </div>
                </>
              )}
              <button
                className="battlefield-add-btn battlefield-back-btn"
                type="button"
                style={{
                  background: "#232932",
                  color: "#fff",
                  fontWeight: 600,
                  fontSize: "1.02rem",
                  marginTop: 24
                }}
                onClick={() => handleSetMode("setting")}
              >
                Back to Setting
              </button>
            </div>
          )}

        </AnimatedHeightWrapper>

        {showMapModal && (
          <ChooseFocusAndScale
          onDone={info => {
            console.log("CHOOSE FOCUS INFO:", info); // <----- додай цю стрічку!
            setFocusInfo(info);
            setShowMapModal(false);
          }}
          onCancel={() => setShowMapModal(false)}
        />
        )}
      </div>
    </div>,
    document.getElementById("modal-root")
  );
}
