import { useState, useRef, useEffect } from "react";
import AnimatedHeightWrapper from "../components/AnimatedHeightWrapper";
import "../styles/pages/_contacts.scss";
import ReactDOM from "react-dom";
import SendRequestForm from "./SendRequestForm";
import FriendRequests from "./FriendRequests";
import FriendsList from "./FriendsList";
import BlockedList from "./BlockedList";

const TAB_REQUESTS = "requests";
const TAB_FRIENDS = "friends";
const TAB_BLOCKED = "blocked";

export default function ContactsModal({ open, onClose, refreshFriendRequestCount }) {
  if (!open) return null;
  const [activeTab, setActiveTab] = useState(TAB_REQUESTS);
  const modalRef = useRef();
  const [showSendRequestForm, setShowSendRequestForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (open) refreshFriendRequestCount && refreshFriendRequestCount();
  }, [open, refreshFriendRequestCount]);

  useEffect(() => {
    function handleClickOutside(e) {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);

  return ReactDOM.createPortal(
    (
      <div className="contacts-overlay">
        <div className="contacts-modal" ref={modalRef}>
          <button className="close-btn-contacts" onClick={onClose}>×</button>
          <div className="contacts-header">
            <img src="/icons/contactsIcon.png" alt="Contacts" className="contacts-header-icon"/>
            <span>Contacts</span>
          </div>
          <hr className="divider" />

          {showSendRequestForm ? (
            <SendRequestForm onBack={() => setShowSendRequestForm(false)} />
          ) : (
            <>
              <div className="contacts-tabs">
                <button className={activeTab === TAB_REQUESTS ? "active" : ""} onClick={() => setActiveTab(TAB_REQUESTS)}>
                  Requests
                </button>
                <button className={activeTab === TAB_FRIENDS ? "active" : ""} onClick={() => setActiveTab(TAB_FRIENDS)}>
                  Friends
                </button>
                <button
                  className={activeTab === TAB_BLOCKED ? "active blocked-active" : ""}
                  onClick={() => setActiveTab(TAB_BLOCKED)}
                >
                  Blocked
                </button>
              </div>
              <AnimatedHeightWrapper activeKey={activeTab}>
                {activeTab === TAB_REQUESTS && (
                  <div className="tab-content">
                    <FriendRequests refreshFriendRequestCount={refreshFriendRequestCount} />
                  </div>
                )}
                {activeTab === TAB_FRIENDS && (
                  <div className="tab-content">
                    <FriendsList searchQuery={searchQuery} />
                  </div>
                )}
                {activeTab === TAB_BLOCKED && (
                  <div className="tab-content blocked-tab">
                    <BlockedList searchQuery={searchQuery} />
                  </div>
                )}
              </AnimatedHeightWrapper>
              <hr className="divider" />
              <div className="contacts-bottom-btn-row" style={{ flexDirection: 'column', alignItems: 'center' }}>
                {activeTab === TAB_REQUESTS && (
                  <button className="main-action-btn" onClick={() => setShowSendRequestForm(true)}>
                    Send Request
                  </button>
                )}
                {(activeTab === TAB_FRIENDS || activeTab === TAB_BLOCKED) && (
                  <>
                    <input
                      className="contacts-search-input"
                      type="text"
                      placeholder="Find"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                    {searchQuery.length > 0 && (
                      <button
                        className="contacts-cancel-btn"
                        type="button"
                        onClick={() => setSearchQuery("")}
                      >
                        Cancel
                      </button>
                    )}
                  </>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    ),
    document.getElementById("modal-root")
  );
}
